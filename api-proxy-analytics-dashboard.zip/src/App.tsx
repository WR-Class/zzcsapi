import { useEffect, useMemo, useState } from "react";
import { Activity, Coins, Gauge, KeyRound, Moon, Server, Settings2, ShieldCheck, Sun, Zap } from "lucide-react";
import {
  API_KEYS,
  GROUPS,
  HOUR_PROFILE,
  MODELS,
  RECORDS,
  TODAY,
  addDays,
  dateRange,
  daysBetween,
  filterRecords,
  groupBy,
  sumRecords,
  type Filters,
} from "./lib/data";
import { fmtCurrency, fmtDateCN, fmtLatency, fmtNumber, fmtPercent, fmtShortDate } from "./lib/format";
import { useTheme } from "./hooks/useTheme";
import { useLocalStorage } from "./hooks/useLocalStorage";
import { FilterBar } from "./components/FilterBar";
import { KpiCard } from "./components/KpiCard";
import { TrendChart, type TrendMetric, type TrendPoint } from "./components/charts/TrendChart";
import { CostBarChart, type StackDim, type StackedPoint } from "./components/charts/CostBarChart";
import { ModelDonut, type DonutMetric } from "./components/charts/ModelDonut";
import { HourlyBar } from "./components/charts/HourlyBar";
import { ChannelHealth } from "./components/ChannelHealth";
import { DataTable, type KeyRow } from "./components/DataTable";
import { DEFAULT_PREFS, PersonalizePanel, type Prefs } from "./components/PersonalizePanel";
import { cn } from "./utils/cn";

const INITIAL_FILTERS: Filters = { start: addDays(TODAY, -29), end: TODAY, groups: [], models: [], channels: [] };

export default function App() {
  const { isDark, toggle } = useTheme();
  const [prefs, setPrefs] = useLocalStorage<Prefs>("relay-prefs-v1", DEFAULT_PREFS);
  const [filters, setFilters] = useState<Filters>(INITIAL_FILTERS);
  const [panelOpen, setPanelOpen] = useState(false);
  const [trendMetric, setTrendMetric] = useState<TrendMetric>("requests");
  const [stackDim, setStackDim] = useState<StackDim>("channel");
  const [donutMetric, setDonutMetric] = useState<DonutMetric>("requests");
  const [clock, setClock] = useState(() => new Date());

  useEffect(() => {
    const id = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  // ---------- Core aggregations ----------
  const span = daysBetween(filters.start, filters.end);
  const prevFilters = useMemo<Filters>(() => ({ ...filters, start: addDays(filters.start, -span), end: addDays(filters.start, -1) }), [filters, span]);

  const current = useMemo(() => filterRecords(RECORDS, filters), [filters]);
  const previous = useMemo(() => filterRecords(RECORDS, prevFilters), [prevFilters]);
  const totals = useMemo(() => sumRecords(current), [current]);
  const prevTotals = useMemo(() => sumRecords(previous), [previous]);

  const delta = (a: number, b: number) => (b === 0 ? (a === 0 ? 0 : Infinity) : (a - b) / b);

  // Daily series (current + previous aligned by offset)
  const trendData = useMemo<TrendPoint[]>(() => {
    const cur = groupBy(current, (r) => r.date);
    const prev = groupBy(previous, (r) => r.date);
    return dateRange(filters.start, filters.end).map((date) => {
      const c = sumRecords(cur.get(date) ?? []);
      const prevDate = addDays(date, -span);
      const p = sumRecords(prev.get(prevDate) ?? []);
      return { date, prevDate, requests: c.requests, tokens: c.tokens, cost: c.cost, prevRequests: p.requests, prevTokens: p.tokens, prevCost: p.cost };
    });
  }, [current, previous, filters.start, filters.end, span]);

  const sparks = useMemo(() => {
    const dailyKeys = groupBy(current, (r) => r.date);
    const sr: number[] = [];
    const lat: number[] = [];
    const keys: number[] = [];
    for (const d of trendData) {
      const t = sumRecords(dailyKeys.get(d.date) ?? []);
      sr.push(t.successRate * 100);
      lat.push(t.avgLatency);
      keys.push(t.activeKeys);
    }
    return {
      requests: trendData.map((d) => d.requests),
      tokens: trendData.map((d) => d.tokens),
      cost: trendData.map((d) => d.cost),
      successRate: sr,
      latency: lat,
      activeKeys: keys,
    };
  }, [current, trendData]);

  // Stacked bar (by day, or by week for long ranges)
  const weekly = span > 31;
  const stacked = useMemo(() => {
    const dimOf = (r: (typeof current)[number]) => (stackDim === "channel" ? r.channel : r.group);
    const seriesTotals = new Map<string, number>();
    const buckets = new Map<string, StackedPoint>();
    const days = dateRange(filters.start, filters.end);
    const bucketOf = (date: string) => {
      if (!weekly) return fmtShortDate(date);
      const idx = days.indexOf(date);
      return fmtShortDate(days[Math.floor(idx / 7) * 7]);
    };
    for (const d of days) {
      const key = bucketOf(d);
      if (!buckets.has(key)) buckets.set(key, { label: key, total: 0 });
    }
    for (const r of current) {
      const b = buckets.get(bucketOf(r.date))!;
      const k = dimOf(r);
      b[k] = ((b[k] as number) ?? 0) + r.cost;
      b.total += r.cost;
      seriesTotals.set(k, (seriesTotals.get(k) ?? 0) + r.cost);
    }
    const series = [...seriesTotals.entries()].sort((a, b) => b[1] - a[1]).map(([k]) => k);
    const data = [...buckets.values()].map((b) => {
      for (const s of series) if (b[s] == null) b[s] = 0;
      return b;
    });
    return { data, series };
  }, [current, stackDim, filters.start, filters.end, weekly]);

  // Donut by model
  const donut = useMemo(() => {
    const byModel = groupBy(current, (r) => r.model);
    const arr = [...byModel.entries()]
      .map(([id, recs]) => {
        const t = sumRecords(recs);
        return { id, value: t[donutMetric], color: MODELS.find((m) => m.id === id)?.color ?? "#94a3b8" };
      })
      .filter((d) => d.value > 0)
      .sort((a, b) => b.value - a.value);
    if (arr.length > 7) {
      const rest = arr.slice(6).reduce((s, d) => s + d.value, 0);
      return [...arr.slice(0, 6), { id: "其他", value: rest, color: isDark ? "#475569" : "#cbd5e1" }];
    }
    return arr;
  }, [current, donutMetric, isDark]);

  // Hourly distribution (daily average)
  const hourly = useMemo(() => {
    const hours = Array.from({ length: 24 }, () => 0);
    for (const r of current) {
      const profile = HOUR_PROFILE[r.group];
      const sum = profile.reduce((s, v) => s + v, 0);
      for (let h = 0; h < 24; h++) hours[h] += (r.requests * profile[h]) / sum;
    }
    const jitter = [1.03, 0.97, 1.01, 0.99, 1.02, 0.98, 1.04, 0.96, 1.0, 1.02, 0.98, 1.01, 0.99, 1.03, 0.97, 1.0, 1.02, 0.98, 1.01, 0.99, 1.03, 0.97, 1.0, 1.02];
    return hours.map((v, hour) => ({ hour, requests: Math.round((v / span) * jitter[hour]) }));
  }, [current, span]);

  // Channel health
  const channels = useMemo(
    () =>
      [...groupBy(current, (r) => r.channel).entries()]
        .map(([channel, recs]) => {
          const t = sumRecords(recs);
          return { channel, requests: t.requests, successRate: t.successRate, avgLatency: t.avgLatency };
        })
        .sort((a, b) => b.requests - a.requests),
    [current],
  );

  // Table rows
  const rows = useMemo<KeyRow[]>(() => {
    const byKey = groupBy(current, (r) => r.keyId);
    const totalCost = totals.cost || 1;
    return [...byKey.entries()].map(([id, recs]) => {
      const key = API_KEYS.find((k) => k.id === id)!;
      const t = sumRecords(recs);
      const lastUsed = recs.reduce((m, r) => (r.date > m ? r.date : m), recs[0].date);
      const models = [...new Set(recs.map((r) => r.model))];
      return { id, name: key.name, owner: key.owner, group: key.group, models, requests: t.requests, tokens: t.tokens, cost: t.cost, successRate: t.successRate, avgLatency: t.avgLatency, lastUsed, share: t.cost / totalCost };
    });
  }, [current, totals.cost]);

  const currency = prefs.currency;
  const compact = prefs.density === "compact";
  const degraded = channels.filter((c) => c.successRate < 0.985).length;

  const kpis = [
    { id: "requests" as const, label: "总请求数", value: fmtNumber(totals.requests), delta: delta(totals.requests, prevTotals.requests), hint: `日均 ${fmtNumber(totals.requests / span)} 次`, icon: Activity, accent: "#6366f1", spark: sparks.requests },
    { id: "tokens" as const, label: "Token 消耗", value: fmtNumber(totals.tokens), delta: delta(totals.tokens, prevTotals.tokens), hint: `输入 ${fmtNumber(totals.promptTokens)} · 输出 ${fmtNumber(totals.completionTokens)}`, icon: Zap, accent: "#06b6d4", spark: sparks.tokens },
    { id: "cost" as const, label: "总费用", value: fmtCurrency(totals.cost, currency, totals.cost >= 100000), delta: delta(totals.cost, prevTotals.cost), hint: `每千次请求 ${fmtCurrency(totals.requests ? (totals.cost / totals.requests) * 1000 : 0, currency)}`, icon: Coins, accent: "#f59e0b", spark: sparks.cost, invert: true },
    { id: "successRate" as const, label: "成功率", value: fmtPercent(totals.successRate, 2), delta: delta(totals.successRate, prevTotals.successRate), hint: `${fmtNumber(totals.errors)} 次失败请求`, icon: ShieldCheck, accent: "#10b981", spark: sparks.successRate },
    { id: "latency" as const, label: "平均延迟", value: fmtLatency(totals.avgLatency), delta: delta(totals.avgLatency, prevTotals.avgLatency), hint: "首字节到完成的平均耗时", icon: Gauge, accent: "#ec4899", spark: sparks.latency, invert: true },
    { id: "activeKeys" as const, label: "活跃令牌", value: String(totals.activeKeys), delta: delta(totals.activeKeys, prevTotals.activeKeys), hint: `共 ${API_KEYS.length} 个令牌 · ${GROUPS.length} 个分组`, icon: KeyRound, accent: "#8b5cf6", spark: sparks.activeKeys },
  ].filter((k) => prefs.kpis[k.id]);

  const gap = compact ? "gap-3" : "gap-4 lg:gap-5";

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-slate-200/70 bg-white/80 backdrop-blur-lg dark:border-slate-800 dark:bg-slate-950/80">
        <div className="mx-auto flex max-w-[1500px] items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 text-white shadow-lg shadow-indigo-500/30">
              <Server className="h-4.5 w-4.5" />
            </div>
            <div className="min-w-0">
              <h1 className="truncate text-base font-semibold tracking-tight text-slate-900 sm:text-lg dark:text-white">{prefs.displayName || "运营看板"}</h1>
              <p className="hidden truncate text-[11px] text-slate-500 sm:block dark:text-slate-400">
                API 中转站 · 个性化分析看板 · {fmtDateCN(filters.start)} — {fmtDateCN(filters.end)}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div
              className={cn(
                "hidden items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium md:flex",
                degraded === 0
                  ? "border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300"
                  : "border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-300",
              )}
            >
              <span className={cn("h-1.5 w-1.5 rounded-full", degraded === 0 ? "bg-emerald-500" : "animate-pulse-soft bg-amber-500")} />
              {degraded === 0 ? "全部渠道正常" : `${degraded} 个渠道需关注`}
            </div>
            <span className="hidden font-mono text-[11px] tabular-nums text-slate-400 lg:inline">
              {clock.toLocaleTimeString("zh-CN", { hour12: false })}
            </span>
            <button
              onClick={() => setPanelOpen(true)}
              className="flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 text-xs font-medium text-slate-700 shadow-sm transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <Settings2 className="h-4 w-4" />
              <span className="hidden sm:inline">个性化</span>
            </button>
            <button
              onClick={toggle}
              aria-label="切换主题"
              className="relative flex h-9 w-9 items-center justify-center overflow-hidden rounded-lg border border-slate-200 bg-white text-slate-700 shadow-sm transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <Sun className={cn("absolute h-4 w-4 transition-all duration-300", isDark ? "rotate-90 scale-0 opacity-0" : "rotate-0 scale-100 opacity-100")} />
              <Moon className={cn("absolute h-4 w-4 transition-all duration-300", isDark ? "rotate-0 scale-100 opacity-100" : "-rotate-90 scale-0 opacity-0")} />
            </button>
          </div>
        </div>
      </header>

      <main className={cn("mx-auto max-w-[1500px] space-y-4 px-4 py-4 sm:px-6 sm:py-6", compact ? "space-y-3" : "lg:space-y-5")}>
        <FilterBar filters={filters} onChange={setFilters} />

        {/* KPI cards */}
        {kpis.length > 0 && (
          <div className={cn("grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3", kpis.length >= 6 && "2xl:grid-cols-6", kpis.length === 5 && "2xl:grid-cols-5", kpis.length === 4 && "2xl:grid-cols-4", gap)}>
            {kpis.map((k, i) => (
              <KpiCard key={k.id} index={i} {...k} />
            ))}
          </div>
        )}

        {/* Row 1: trend + donut */}
        {(prefs.widgets.trend || prefs.widgets.donut) && (
          <div className={cn("grid grid-cols-1", prefs.widgets.trend && prefs.widgets.donut && "xl:grid-cols-5", gap)}>
            {prefs.widgets.trend && (
              <div className={cn(prefs.widgets.donut && "xl:col-span-3")}>
                <TrendChart data={trendData} metric={trendMetric} onMetricChange={setTrendMetric} currency={currency} isDark={isDark} showPrev={prefs.comparePrev} />
              </div>
            )}
            {prefs.widgets.donut && (
              <div className={cn(prefs.widgets.trend && "xl:col-span-2")}>
                <ModelDonut data={donut} metric={donutMetric} onMetricChange={setDonutMetric} currency={currency} isDark={isDark} />
              </div>
            )}
          </div>
        )}

        {/* Row 2: cost bars + hourly + channels */}
        {(prefs.widgets.cost || prefs.widgets.hourly || prefs.widgets.channels) && (
          <div className={cn("grid grid-cols-1 xl:grid-cols-5", gap)}>
            {prefs.widgets.cost && (
              <div className={cn(prefs.widgets.hourly || prefs.widgets.channels ? "xl:col-span-3" : "xl:col-span-5")}>
                <CostBarChart data={stacked.data} series={stacked.series} dim={stackDim} onDimChange={setStackDim} currency={currency} isDark={isDark} bucketLabel={weekly ? "周" : "日"} />
              </div>
            )}
            {(prefs.widgets.hourly || prefs.widgets.channels) && (
              <div className={cn("grid grid-cols-1", prefs.widgets.cost ? "xl:col-span-2" : "xl:col-span-5 md:grid-cols-2", gap)}>
                {prefs.widgets.hourly && <HourlyBar data={hourly} isDark={isDark} />}
                {prefs.widgets.channels && <ChannelHealth data={channels} />}
              </div>
            )}
          </div>
        )}

        {prefs.widgets.table && <DataTable rows={rows} currency={currency} />}

        {kpis.length === 0 && !Object.values(prefs.widgets).some(Boolean) && (
          <div className="rounded-2xl border border-dashed border-slate-300 py-20 text-center text-sm text-slate-400 dark:border-slate-700">
            所有模块均已隐藏，点击右上角「个性化」重新启用。
          </div>
        )}

        <footer className="flex flex-col items-center justify-between gap-2 pt-2 pb-6 text-[11px] text-slate-400 sm:flex-row">
          <span>数据为模拟样本 · {RECORDS.length.toLocaleString()} 条用量记录 · {MODELS.length} 个模型 · {channels.length || 0} 个活跃渠道</span>
          <span>上一周期：{fmtDateCN(prevFilters.start)} — {fmtDateCN(prevFilters.end)}</span>
        </footer>
      </main>

      <PersonalizePanel open={panelOpen} onClose={() => setPanelOpen(false)} prefs={prefs} onChange={setPrefs} />
    </div>
  );
}
