import { Card } from "./ui/Card";
import { fmtLatency, fmtNumber, fmtPercent } from "../lib/format";
import { CHANNEL_COLORS } from "../lib/data";
import { cn } from "../utils/cn";

export interface ChannelStat {
  channel: string;
  requests: number;
  successRate: number;
  avgLatency: number;
}

export function ChannelHealth({ data }: { data: ChannelStat[] }) {
  const maxLatency = Math.max(...data.map((d) => d.avgLatency), 1);
  return (
    <Card title="渠道健康度" subtitle="成功率与平均延迟 · 按请求量排序">
      <ul className="space-y-3">
        {data.map((c) => {
          const status = c.successRate >= 0.985 ? "healthy" : c.successRate >= 0.95 ? "degraded" : "down";
          return (
            <li key={c.channel} className="group">
              <div className="mb-1 flex items-center justify-between text-xs">
                <span className="flex items-center gap-2 font-medium text-slate-700 dark:text-slate-200">
                  <span
                    className={cn(
                      "h-2 w-2 rounded-full",
                      status === "healthy" && "bg-emerald-500 shadow-[0_0_0_3px_rgba(16,185,129,0.18)]",
                      status === "degraded" && "animate-pulse-soft bg-amber-500 shadow-[0_0_0_3px_rgba(245,158,11,0.2)]",
                      status === "down" && "animate-pulse-soft bg-rose-500 shadow-[0_0_0_3px_rgba(244,63,94,0.2)]",
                    )}
                  />
                  {c.channel}
                </span>
                <span className="flex items-center gap-3 tabular-nums text-slate-500 dark:text-slate-400">
                  <span className="hidden sm:inline">{fmtNumber(c.requests)} 次</span>
                  <span>{fmtLatency(c.avgLatency)}</span>
                  <span
                    className={cn(
                      "w-14 text-right font-semibold",
                      status === "healthy" && "text-emerald-600 dark:text-emerald-400",
                      status === "degraded" && "text-amber-600 dark:text-amber-400",
                      status === "down" && "text-rose-600 dark:text-rose-400",
                    )}
                  >
                    {fmtPercent(c.successRate, 2)}
                  </span>
                </span>
              </div>
              <div className="flex gap-1.5">
                <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800" title="成功率">
                  <div
                    className="h-full rounded-full transition-all duration-700 ease-out"
                    style={{ width: `${Math.max(2, (c.successRate - 0.9) / 0.1 * 100)}%`, background: CHANNEL_COLORS[c.channel] ?? "#94a3b8" }}
                  />
                </div>
                <div className="h-1.5 w-1/3 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800" title="相对延迟">
                  <div
                    className="h-full rounded-full bg-slate-400/70 transition-all duration-700 ease-out dark:bg-slate-500"
                    style={{ width: `${(c.avgLatency / maxLatency) * 100}%` }}
                  />
                </div>
              </div>
            </li>
          );
        })}
        {data.length === 0 && <li className="py-8 text-center text-xs text-slate-400">暂无数据</li>}
      </ul>
      <div className="mt-3 flex items-center gap-4 text-[10px] text-slate-400">
        <span className="flex items-center gap-1"><span className="h-1.5 w-4 rounded-full bg-indigo-400" />成功率 (90%–100%)</span>
        <span className="flex items-center gap-1"><span className="h-1.5 w-4 rounded-full bg-slate-400" />相对延迟</span>
      </div>
    </Card>
  );
}
