import { Eye, EyeOff, RotateCcw, X } from "lucide-react";
import type { Currency } from "../lib/format";
import { cn } from "../utils/cn";
import { SegmentedControl } from "./ui/Card";

export type KpiId = "requests" | "tokens" | "cost" | "successRate" | "latency" | "activeKeys";
export type WidgetId = "trend" | "cost" | "donut" | "hourly" | "channels" | "table";

export interface Prefs {
  kpis: Record<KpiId, boolean>;
  widgets: Record<WidgetId, boolean>;
  currency: Currency;
  comparePrev: boolean;
  density: "comfortable" | "compact";
  displayName: string;
}

export const DEFAULT_PREFS: Prefs = {
  kpis: { requests: true, tokens: true, cost: true, successRate: true, latency: true, activeKeys: true },
  widgets: { trend: true, cost: true, donut: true, hourly: true, channels: true, table: true },
  currency: "USD",
  comparePrev: true,
  density: "comfortable",
  displayName: "运营看板",
};

export const KPI_LABELS: Record<KpiId, string> = {
  requests: "总请求数",
  tokens: "Token 消耗",
  cost: "总费用",
  successRate: "成功率",
  latency: "平均延迟",
  activeKeys: "活跃令牌",
};

export const WIDGET_LABELS: Record<WidgetId, string> = {
  trend: "用量趋势图",
  cost: "费用构成柱状图",
  donut: "模型分布环形图",
  hourly: "24 小时分布",
  channels: "渠道健康度",
  table: "令牌用量明细表",
};

function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button onClick={() => onChange(!on)} className="flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-left text-xs hover:bg-slate-50 dark:hover:bg-slate-800/60">
      <span className={cn("flex items-center gap-2", on ? "text-slate-800 dark:text-slate-100" : "text-slate-400")}>
        {on ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}
        {label}
      </span>
      <span className={cn("relative h-5 w-9 rounded-full transition-colors", on ? "bg-indigo-600" : "bg-slate-200 dark:bg-slate-700")}>
        <span className={cn("absolute top-0.5 left-0.5 h-4 w-4 rounded-full bg-white shadow transition-transform", on && "translate-x-4")} />
      </span>
    </button>
  );
}

export function PersonalizePanel({ open, onClose, prefs, onChange }: { open: boolean; onClose: () => void; prefs: Prefs; onChange: (p: Prefs) => void }) {
  return (
    <>
      <div onClick={onClose} className={cn("fixed inset-0 z-40 bg-slate-900/30 backdrop-blur-[2px] transition-opacity dark:bg-black/50", open ? "opacity-100" : "pointer-events-none opacity-0")} />
      <aside
        className={cn(
          "fixed top-0 right-0 z-50 flex h-full w-full max-w-sm flex-col border-l border-slate-200 bg-white shadow-2xl transition-transform duration-300 ease-out dark:border-slate-800 dark:bg-slate-900",
          open ? "translate-x-0" : "translate-x-full",
        )}
      >
        <header className="flex items-center justify-between border-b border-slate-100 px-5 py-4 dark:border-slate-800">
          <div>
            <h2 className="text-sm font-semibold text-slate-900 dark:text-white">个性化显示</h2>
            <p className="text-[11px] text-slate-400">自定义看板布局，设置会自动保存在本地</p>
          </div>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800">
            <X className="h-4 w-4" />
          </button>
        </header>

        <div className="flex-1 space-y-6 overflow-y-auto px-5 py-5">
          <section>
            <label className="mb-1.5 block text-[11px] font-semibold tracking-wide text-slate-400 uppercase">看板名称</label>
            <input
              value={prefs.displayName}
              onChange={(e) => onChange({ ...prefs, displayName: e.target.value })}
              className="h-9 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm text-slate-800 outline-none focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
            />
          </section>

          <section>
            <label className="mb-1.5 block text-[11px] font-semibold tracking-wide text-slate-400 uppercase">显示偏好</label>
            <div className="space-y-2.5 rounded-xl border border-slate-100 p-3 dark:border-slate-800">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-700 dark:text-slate-200">计价货币</span>
                <SegmentedControl
                  value={prefs.currency}
                  onChange={(currency) => onChange({ ...prefs, currency })}
                  options={[
                    { value: "USD", label: "$ USD" },
                    { value: "CNY", label: "¥ CNY" },
                  ]}
                />
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-700 dark:text-slate-200">布局密度</span>
                <SegmentedControl
                  value={prefs.density}
                  onChange={(density) => onChange({ ...prefs, density })}
                  options={[
                    { value: "comfortable", label: "舒适" },
                    { value: "compact", label: "紧凑" },
                  ]}
                />
              </div>
              <div className="-mx-2.5">
                <Toggle on={prefs.comparePrev} onChange={(comparePrev) => onChange({ ...prefs, comparePrev })} label="趋势图显示上一周期对比" />
              </div>
            </div>
          </section>

          <section>
            <label className="mb-1.5 block text-[11px] font-semibold tracking-wide text-slate-400 uppercase">KPI 指标卡</label>
            <div className="rounded-xl border border-slate-100 p-1 dark:border-slate-800">
              {(Object.keys(KPI_LABELS) as KpiId[]).map((k) => (
                <Toggle key={k} on={prefs.kpis[k]} onChange={(v) => onChange({ ...prefs, kpis: { ...prefs.kpis, [k]: v } })} label={KPI_LABELS[k]} />
              ))}
            </div>
          </section>

          <section>
            <label className="mb-1.5 block text-[11px] font-semibold tracking-wide text-slate-400 uppercase">图表模块</label>
            <div className="rounded-xl border border-slate-100 p-1 dark:border-slate-800">
              {(Object.keys(WIDGET_LABELS) as WidgetId[]).map((k) => (
                <Toggle key={k} on={prefs.widgets[k]} onChange={(v) => onChange({ ...prefs, widgets: { ...prefs.widgets, [k]: v } })} label={WIDGET_LABELS[k]} />
              ))}
            </div>
          </section>
        </div>

        <footer className="border-t border-slate-100 px-5 py-3 dark:border-slate-800">
          <button onClick={() => onChange(DEFAULT_PREFS)} className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100">
            <RotateCcw className="h-3.5 w-3.5" /> 恢复默认设置
          </button>
        </footer>
      </aside>
    </>
  );
}
