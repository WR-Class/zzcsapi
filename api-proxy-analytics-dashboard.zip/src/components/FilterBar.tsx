import { useEffect, useRef, useState } from "react";
import { Calendar, Check, ChevronDown, RotateCcw, X } from "lucide-react";
import { CHANNELS, FIRST_DAY, GROUPS, MODELS, TODAY, addDays, daysBetween, type Filters, type Group } from "../lib/data";
import { cn } from "../utils/cn";

const PRESETS = [
  { label: "近 7 天", days: 7 },
  { label: "近 14 天", days: 14 },
  { label: "近 30 天", days: 30 },
  { label: "近 90 天", days: 90 },
];

function MultiSelect<T extends string>({
  label,
  options,
  value,
  onChange,
}: {
  label: string;
  options: { value: T; label: string; color?: string }[];
  value: T[];
  onChange: (v: T[]) => void;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);

  const toggle = (v: T) => onChange(value.includes(v) ? value.filter((x) => x !== v) : [...value, v]);
  const active = value.length > 0;

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        className={cn(
          "flex h-9 items-center gap-1.5 rounded-lg border px-3 text-xs font-medium transition-colors",
          active
            ? "border-indigo-300 bg-indigo-50 text-indigo-700 dark:border-indigo-500/40 dark:bg-indigo-500/10 dark:text-indigo-300"
            : "border-slate-200 bg-white text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800",
        )}
      >
        {label}
        {active && <span className="rounded-full bg-indigo-600 px-1.5 text-[10px] text-white dark:bg-indigo-500">{value.length}</span>}
        <ChevronDown className={cn("h-3.5 w-3.5 transition-transform", open && "rotate-180")} />
      </button>
      {open && (
        <div className="absolute left-0 z-30 mt-1.5 max-h-72 w-56 overflow-auto rounded-xl border border-slate-200 bg-white p-1.5 shadow-xl shadow-slate-900/10 dark:border-slate-700 dark:bg-slate-900 dark:shadow-black/40">
          {options.map((o) => {
            const checked = value.includes(o.value);
            return (
              <button
                key={o.value}
                onClick={() => toggle(o.value)}
                className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-xs text-slate-700 hover:bg-slate-50 dark:text-slate-200 dark:hover:bg-slate-800"
              >
                <span
                  className={cn(
                    "flex h-4 w-4 items-center justify-center rounded border transition-colors",
                    checked ? "border-indigo-600 bg-indigo-600 text-white" : "border-slate-300 dark:border-slate-600",
                  )}
                >
                  {checked && <Check className="h-3 w-3" />}
                </span>
                {o.color && <span className="h-2 w-2 rounded-full" style={{ background: o.color }} />}
                <span className="truncate">{o.label}</span>
              </button>
            );
          })}
          {active && (
            <button onClick={() => onChange([])} className="mt-1 w-full rounded-lg border-t border-slate-100 px-2 py-1.5 text-left text-[11px] text-slate-400 hover:text-slate-700 dark:border-slate-800 dark:hover:text-slate-200">
              清除选择
            </button>
          )}
        </div>
      )}
    </div>
  );
}

export function FilterBar({ filters, onChange }: { filters: Filters; onChange: (f: Filters) => void }) {
  const span = daysBetween(filters.start, filters.end);
  const activePreset = filters.end === TODAY ? PRESETS.find((p) => p.days === span)?.days : undefined;
  const setPreset = (days: number) => onChange({ ...filters, start: addDays(TODAY, -(days - 1)), end: TODAY });
  const hasSegments = filters.groups.length + filters.models.length + filters.channels.length > 0;
  const reset = () => onChange({ start: addDays(TODAY, -29), end: TODAY, groups: [], models: [], channels: [] });

  const chips: { label: string; onRemove: () => void }[] = [
    ...filters.groups.map((g) => ({ label: GROUPS.find((x) => x.id === g)?.label ?? g, onRemove: () => onChange({ ...filters, groups: filters.groups.filter((x) => x !== g) }) })),
    ...filters.models.map((m) => ({ label: m, onRemove: () => onChange({ ...filters, models: filters.models.filter((x) => x !== m) }) })),
    ...filters.channels.map((c) => ({ label: c, onRemove: () => onChange({ ...filters, channels: filters.channels.filter((x) => x !== c) }) })),
  ];

  return (
    <div className="animate-fade-up rounded-2xl border border-slate-200/80 bg-white p-3 shadow-sm shadow-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:shadow-none">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        {/* Date range */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex rounded-lg bg-slate-100 p-0.5 dark:bg-slate-800">
            {PRESETS.map((p) => (
              <button
                key={p.days}
                onClick={() => setPreset(p.days)}
                className={cn(
                  "rounded-md px-2.5 py-1.5 text-xs font-medium whitespace-nowrap transition-all",
                  activePreset === p.days ? "bg-white text-slate-900 shadow-sm dark:bg-slate-700 dark:text-white" : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200",
                )}
              >
                {p.label}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2 dark:border-slate-700 dark:bg-slate-900">
            <Calendar className="h-3.5 w-3.5 text-slate-400" />
            <input
              type="date"
              value={filters.start}
              min={FIRST_DAY}
              max={filters.end}
              onChange={(e) => e.target.value && onChange({ ...filters, start: e.target.value })}
              className="h-8 w-[7.5rem] bg-transparent text-xs text-slate-700 outline-none dark:text-slate-200"
            />
            <span className="text-slate-300 dark:text-slate-600">–</span>
            <input
              type="date"
              value={filters.end}
              min={filters.start}
              max={TODAY}
              onChange={(e) => e.target.value && onChange({ ...filters, end: e.target.value })}
              className="h-8 w-[7.5rem] bg-transparent text-xs text-slate-700 outline-none dark:text-slate-200"
            />
          </div>
          <span className="text-[11px] text-slate-400">共 {span} 天</span>
        </div>

        {/* Segments */}
        <div className="flex flex-wrap items-center gap-2">
          <MultiSelect<Group> label="用户分组" options={GROUPS.map((g) => ({ value: g.id, label: g.label, color: g.color }))} value={filters.groups} onChange={(groups) => onChange({ ...filters, groups })} />
          <MultiSelect label="模型" options={MODELS.map((m) => ({ value: m.id, label: m.id, color: m.color }))} value={filters.models} onChange={(models) => onChange({ ...filters, models })} />
          <MultiSelect label="渠道" options={CHANNELS.map((c) => ({ value: c, label: c }))} value={filters.channels} onChange={(channels) => onChange({ ...filters, channels })} />
          {(hasSegments || activePreset !== 30) && (
            <button onClick={reset} className="flex h-9 items-center gap-1 rounded-lg px-2.5 text-xs text-slate-500 hover:bg-slate-100 hover:text-slate-800 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-slate-200">
              <RotateCcw className="h-3.5 w-3.5" /> 重置
            </button>
          )}
        </div>
      </div>

      {chips.length > 0 && (
        <div className="mt-2.5 flex flex-wrap items-center gap-1.5 border-t border-slate-100 pt-2.5 dark:border-slate-800">
          <span className="text-[11px] text-slate-400">已筛选：</span>
          {chips.map((c) => (
            <button
              key={c.label}
              onClick={c.onRemove}
              className="group flex items-center gap-1 rounded-full border border-slate-200 bg-slate-50 px-2 py-0.5 text-[11px] text-slate-600 transition-colors hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:border-rose-500/40 dark:hover:bg-rose-500/10 dark:hover:text-rose-300"
            >
              {c.label}
              <X className="h-3 w-3 opacity-60 group-hover:opacity-100" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
