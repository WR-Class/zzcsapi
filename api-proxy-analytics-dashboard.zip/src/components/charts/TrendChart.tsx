import { Area, CartesianGrid, ComposedChart, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Card, SegmentedControl } from "../ui/Card";
import { TooltipShell, axisStyle, gridStroke } from "./ChartTooltip";
import { fmtCurrency, fmtFull, fmtNumber, fmtShortDate, type Currency } from "../../lib/format";

export type TrendMetric = "requests" | "tokens" | "cost";

export interface TrendPoint {
  date: string;
  prevDate: string;
  requests: number;
  tokens: number;
  cost: number;
  prevRequests: number;
  prevTokens: number;
  prevCost: number;
}

const META: Record<TrendMetric, { label: string; color: string }> = {
  requests: { label: "请求数", color: "#6366f1" },
  tokens: { label: "Tokens", color: "#06b6d4" },
  cost: { label: "费用", color: "#f59e0b" },
};

export function TrendChart({
  data,
  metric,
  onMetricChange,
  currency,
  isDark,
  showPrev,
}: {
  data: TrendPoint[];
  metric: TrendMetric;
  onMetricChange: (m: TrendMetric) => void;
  currency: Currency;
  isDark: boolean;
  showPrev: boolean;
}) {
  const { label, color } = META[metric];
  const prevKey = `prev${metric[0].toUpperCase()}${metric.slice(1)}` as keyof TrendPoint;
  const fmt = (v: number) => (metric === "cost" ? fmtCurrency(v, currency, true) : fmtNumber(v));
  const fmtFullV = (v: number) => (metric === "cost" ? fmtCurrency(v, currency) : fmtFull(v));

  return (
    <Card
      title="用量趋势"
      subtitle={`每日${label}${showPrev ? " · 虚线为上一周期同比" : ""}`}
      action={
        <SegmentedControl
          value={metric}
          onChange={onMetricChange}
          options={[
            { value: "requests", label: "请求" },
            { value: "tokens", label: "Tokens" },
            { value: "cost", label: "费用" },
          ]}
        />
      }
    >
      <div className="h-64 sm:h-72">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 10, right: 6, bottom: 0, left: -8 }}>
            <defs>
              <linearGradient id="trendFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={color} stopOpacity={0.32} />
                <stop offset="100%" stopColor={color} stopOpacity={0.02} />
              </linearGradient>
            </defs>
            <CartesianGrid vertical={false} stroke={gridStroke(isDark)} />
            <XAxis dataKey="date" tickFormatter={fmtShortDate} tick={axisStyle(isDark)} axisLine={false} tickLine={false} minTickGap={28} dy={6} />
            <YAxis tickFormatter={fmt} tick={axisStyle(isDark)} axisLine={false} tickLine={false} width={64} />
            <Tooltip
              cursor={{ stroke: isDark ? "#475569" : "#cbd5e1", strokeDasharray: "3 3" }}
              content={({ active, payload }) => {
                if (!active || !payload?.length) return null;
                const p = payload[0].payload as TrendPoint;
                const items = [{ name: label, value: fmtFullV(p[metric]), color }];
                if (showPrev) {
                  const prev = p[prevKey] as number;
                  const delta = prev ? (p[metric] - prev) / prev : 0;
                  items.push({ name: `上期 (${fmtShortDate(p.prevDate)})`, value: fmtFullV(prev), color: isDark ? "#64748b" : "#94a3b8" });
                  items.push({ name: "同比", value: `${delta >= 0 ? "+" : ""}${(delta * 100).toFixed(1)}%`, color: delta >= 0 ? "#10b981" : "#f43f5e" });
                }
                return <TooltipShell title={p.date} items={items} />;
              }}
            />
            {showPrev && (
              <Line
                type="monotone"
                dataKey={prevKey}
                stroke={isDark ? "#475569" : "#cbd5e1"}
                strokeWidth={1.5}
                strokeDasharray="4 4"
                dot={false}
                isAnimationActive
                animationDuration={800}
              />
            )}
            <Area
              type="monotone"
              dataKey={metric}
              stroke={color}
              strokeWidth={2.25}
              fill="url(#trendFill)"
              dot={false}
              activeDot={{ r: 5, strokeWidth: 2, stroke: isDark ? "#0f172a" : "#fff" }}
              isAnimationActive
              animationDuration={800}
              animationEasing="ease-out"
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}
