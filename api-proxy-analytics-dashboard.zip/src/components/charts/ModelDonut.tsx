import { useState } from "react";
import { Cell, Pie, PieChart, ResponsiveContainer, Sector, Tooltip } from "recharts";
import { Card, SegmentedControl } from "../ui/Card";
import { TooltipShell } from "./ChartTooltip";
import { fmtCurrency, fmtFull, fmtNumber, fmtPercent, type Currency } from "../../lib/format";

export type DonutMetric = "requests" | "tokens" | "cost";

export interface DonutSlice {
  id: string;
  value: number;
  color: string;
}

const LABEL: Record<DonutMetric, string> = { requests: "请求数", tokens: "Tokens", cost: "费用" };

export function ModelDonut({
  data,
  metric,
  onMetricChange,
  currency,
  isDark,
}: {
  data: DonutSlice[];
  metric: DonutMetric;
  onMetricChange: (m: DonutMetric) => void;
  currency: Currency;
  isDark: boolean;
}) {
  const [active, setActive] = useState<number | null>(null);
  const total = data.reduce((s, d) => s + d.value, 0);
  const fmt = (v: number) => (metric === "cost" ? fmtCurrency(v, currency, true) : fmtNumber(v));
  const fmtF = (v: number) => (metric === "cost" ? fmtCurrency(v, currency) : fmtFull(v));
  const shown = active != null && data[active] ? data[active] : null;

  return (
    <Card
      title="模型分布"
      subtitle={`按${LABEL[metric]}占比`}
      action={
        <SegmentedControl
          size="xs"
          value={metric}
          onChange={onMetricChange}
          options={[
            { value: "requests", label: "请求" },
            { value: "tokens", label: "Tokens" },
            { value: "cost", label: "费用" },
          ]}
        />
      }
    >
      <div className="flex flex-col items-center gap-4 sm:flex-row">
        <div className="relative h-52 w-52 shrink-0">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                dataKey="value"
                nameKey="id"
                cx="50%"
                cy="50%"
                innerRadius={62}
                outerRadius={88}
                paddingAngle={2}
                cornerRadius={4}
                stroke="none"
                isAnimationActive
                animationDuration={800}
                animationEasing="ease-out"
                activeShape={(props: any) => <Sector {...props} outerRadius={props.outerRadius + 6} />}
                onMouseEnter={(_, i) => setActive(i)}
                onMouseLeave={() => setActive(null)}
              >
                {data.map((d, i) => (
                  <Cell key={d.id} fill={d.color} fillOpacity={active != null && active !== i ? 0.35 : 1} style={{ transition: "fill-opacity .25s" }} />
                ))}
              </Pie>
              <Tooltip
                content={({ active: a, payload }) => {
                  if (!a || !payload?.length) return null;
                  const p = payload[0].payload as DonutSlice;
                  return <TooltipShell title={p.id} items={[{ name: LABEL[metric], value: fmtF(p.value), color: p.color }, { name: "占比", value: fmtPercent(p.value / total) }]} />;
                }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center">
            <span className="text-[11px] text-slate-400 dark:text-slate-500">{shown ? shown.id : `总${LABEL[metric]}`}</span>
            <span className="text-xl font-bold tabular-nums text-slate-900 dark:text-white">{shown ? fmtPercent(shown.value / total) : fmt(total)}</span>
            {shown && <span className="text-[11px] text-slate-400">{fmt(shown.value)}</span>}
          </div>
        </div>
        <ul className="w-full min-w-0 flex-1 space-y-1.5">
          {data.map((d, i) => (
            <li
              key={d.id}
              onMouseEnter={() => setActive(i)}
              onMouseLeave={() => setActive(null)}
              className="flex cursor-default items-center gap-2 rounded-lg px-2 py-1 text-xs transition-colors hover:bg-slate-50 dark:hover:bg-slate-800/60"
              style={{ opacity: active != null && active !== i ? 0.5 : 1 }}
            >
              <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: d.color }} />
              <span className="min-w-0 flex-1 truncate font-medium text-slate-700 dark:text-slate-300">{d.id}</span>
              <span className="tabular-nums text-slate-500 dark:text-slate-400">{fmt(d.value)}</span>
              <span className="w-12 text-right tabular-nums text-slate-400 dark:text-slate-500">{fmtPercent(d.value / total)}</span>
            </li>
          ))}
          {data.length === 0 && <li className="py-6 text-center text-xs text-slate-400">{isDark ? "暂无数据" : "暂无数据"}</li>}
        </ul>
      </div>
    </Card>
  );
}
