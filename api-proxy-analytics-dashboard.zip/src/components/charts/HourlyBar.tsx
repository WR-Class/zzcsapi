import { Bar, BarChart, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Card } from "../ui/Card";
import { TooltipShell, axisStyle, cursorFill } from "./ChartTooltip";
import { fmtFull, fmtNumber, fmtPercent } from "../../lib/format";

export interface HourPoint {
  hour: number;
  requests: number;
}

export function HourlyBar({ data, isDark }: { data: HourPoint[]; isDark: boolean }) {
  const max = Math.max(...data.map((d) => d.requests), 1);
  const total = data.reduce((s, d) => s + d.requests, 0);
  const peak = data.reduce((a, b) => (b.requests > a.requests ? b : a), data[0]);

  return (
    <Card title="24 小时请求分布" subtitle={`峰值时段 ${String(peak?.hour ?? 0).padStart(2, "0")}:00 · 日均请求量`}>
      <div className="h-44">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 6, right: 0, bottom: 0, left: -20 }} barCategoryGap="22%">
            <XAxis dataKey="hour" tickFormatter={(h) => `${String(h).padStart(2, "0")}`} tick={axisStyle(isDark)} axisLine={false} tickLine={false} interval={2} dy={4} />
            <YAxis tickFormatter={(v) => fmtNumber(v, 0)} tick={axisStyle(isDark)} axisLine={false} tickLine={false} width={48} />
            <Tooltip
              cursor={{ fill: cursorFill(isDark) }}
              content={({ active, payload }) => {
                if (!active || !payload?.length) return null;
                const p = payload[0].payload as HourPoint;
                return (
                  <TooltipShell
                    title={`${String(p.hour).padStart(2, "0")}:00 – ${String((p.hour + 1) % 24).padStart(2, "0")}:00`}
                    items={[
                      { name: "日均请求", value: fmtFull(p.requests), color: "#8b5cf6" },
                      { name: "占全天", value: fmtPercent(total ? p.requests / total : 0) },
                    ]}
                  />
                );
              }}
            />
            <Bar dataKey="requests" radius={[4, 4, 0, 0]} isAnimationActive animationDuration={700}>
              {data.map((d) => {
                const t = d.requests / max;
                return <Cell key={d.hour} fill="#8b5cf6" fillOpacity={0.35 + t * 0.65} />;
              })}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}
