interface Item {
  name: string;
  value: string;
  color?: string;
}

export function TooltipShell({ title, items, footer }: { title?: string; items: Item[]; footer?: string }) {
  return (
    <div className="min-w-[160px] rounded-xl border border-slate-200/80 bg-white/95 px-3.5 py-2.5 text-xs shadow-xl shadow-slate-900/10 backdrop-blur-md dark:border-slate-700 dark:bg-slate-900/95 dark:shadow-black/40">
      {title && <div className="mb-1.5 font-semibold text-slate-800 dark:text-slate-100">{title}</div>}
      <ul className="space-y-1">
        {items.map((it) => (
          <li key={it.name} className="flex items-center justify-between gap-4">
            <span className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400">
              {it.color && <span className="h-2 w-2 rounded-full" style={{ background: it.color }} />}
              {it.name}
            </span>
            <span className="font-medium tabular-nums text-slate-900 dark:text-slate-100">{it.value}</span>
          </li>
        ))}
      </ul>
      {footer && <div className="mt-1.5 border-t border-slate-100 pt-1.5 text-[11px] text-slate-400 dark:border-slate-800">{footer}</div>}
    </div>
  );
}

export const axisStyle = (isDark: boolean) => ({
  fontSize: 11,
  fill: isDark ? "#64748b" : "#94a3b8",
});

export const gridStroke = (isDark: boolean) => (isDark ? "#1e293b" : "#f1f5f9");
export const cursorFill = (isDark: boolean) => (isDark ? "rgba(148,163,184,0.08)" : "rgba(15,23,42,0.04)");
