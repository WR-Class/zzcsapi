import { useState } from "react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Card, SegmentedControl } from "../ui/Card";
import { TooltipShell, axisStyle, cursorFill, gridStroke } from "./ChartTooltip";
import { fmtCurrency, type Currency } from "../../lib/format";
import { CHANNEL_COLORS, GROUPS } from "../../lib/data";

export type StackDim = "channel" | "group";

export interface StackedPoint {
  label: string;
  total: number;
  [series: string]: number | string;
}

export function CostBarChart({
  data,
  series,
  dim,
  onDimChange,
  currency,
  isDark,
  bucketLabel,
}: {
  data: StackedPoint[];
  series: string[];
  dim: StackDim;
  onDimChange: (d: StackDim) => void;
  currency: Currency;
  isDark: boolean;
  bucketLabel: string;
}) {
  const [hovered, setHovered] = useState<string | null>(null);
  const colorOf = (s: string) => (dim === "channel" ? CHANNEL_COLORS[s] ?? "#94a3b8" : GROUPS.find((g) => g.id === s)?.color ?? "#94a3b8");
  const nameOf = (s: string) => (dim === "channel" ? s : GROUPS.find((g) => g.id === s)?.label ?? s);

  return (
    <Card
      title="费用构成"
      subtitle={`按${bucketLabel}统计 · ${dim === "channel" ? "按渠道" : "按用户分组"}堆叠`}
      action={
        <SegmentedControl
          value={dim}
          onChange={onDimChange}
          options={[
            { value: "channel", label: "渠道" },
            { value: "group", label: "分组" },
          ]}
        />
      }
    >
      <div className="h-64 sm:h-72">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 10, right: 6, bottom: 0, left: -8 }} barCategoryGap="28%">
            <CartesianGrid vertical={false} stroke={gridStroke(isDark)} />
            <XAxis dataKey="label" tick={axisStyle(isDark)} axisLine={false} tickLine={false} minTickGap={24} dy={6} />
            <YAxis tickFormatter={(v) => fmtCurrency(v, currency, true)} tick={axisStyle(isDark)} axisLine={false} tickLine={false} width={64} />
            <Tooltip
              cursor={{ fill: cursorFill(isDark) }}
              content={({ active, payload, label }) => {
                if (!active || !payload?.length) return null;
                const items = [...payload]
                  .reverse()
                  .filter((p) => (p.value as number) > 0)
                  .map((p) => ({ name: nameOf(String(p.dataKey)), value: fmtCurrency(p.value as number, currency), color: p.color }));
                const total = payload.reduce((s, p) => s + (p.value as number), 0);
                return <TooltipShell title={String(label)} items={items} footer={`合计 ${fmtCurrency(total, currency)}`} />;
              }}
            />
            {series.map((s, i) => (
              <Bar
                key={s}
                dataKey={s}
                stackId="cost"
                fill={colorOf(s)}
                fillOpacity={hovered && hovered !== s ? 0.3 : 1}
                radius={i === series.length - 1 ? [5, 5, 0, 0] : 0}
                isAnimationActive
                animationDuration={700}
                onMouseEnter={() => setHovered(s)}
                onMouseLeave={() => setHovered(null)}
              />
            ))}
          </BarChart>
        </ResponsiveContainer>
      </div>
      <ul className="mt-2 flex flex-wrap gap-x-4 gap-y-1.5">
        {series.map((s) => (
          <li
            key={s}
            onMouseEnter={() => setHovered(s)}
            onMouseLeave={() => setHovered(null)}
            className="flex cursor-default items-center gap-1.5 text-[11px] text-slate-500 transition-opacity dark:text-slate-400"
            style={{ opacity: hovered && hovered !== s ? 0.4 : 1 }}
          >
            <span className="h-2 w-2 rounded-sm" style={{ background: colorOf(s) }} />
            {nameOf(s)}
          </li>
        ))}
      </ul>
    </Card>
  );
}
