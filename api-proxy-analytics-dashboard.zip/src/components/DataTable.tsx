import { useMemo, useState } from "react";
import { ArrowDown, ArrowUp, ArrowUpDown, ChevronLeft, ChevronRight, Download, Search } from "lucide-react";
import { Card } from "./ui/Card";
import { GROUPS, MODELS, type Group } from "../lib/data";
import { fmtCurrency, fmtFull, fmtLatency, fmtNumber, fmtPercent, type Currency } from "../lib/format";
import { cn } from "../utils/cn";

export interface KeyRow {
  id: string;
  name: string;
  owner: string;
  group: Group;
  models: string[];
  requests: number;
  tokens: number;
  cost: number;
  successRate: number;
  avgLatency: number;
  lastUsed: string;
  share: number; // share of total cost
}

type SortKey = "name" | "group" | "requests" | "tokens" | "cost" | "successRate" | "avgLatency" | "lastUsed";
type SortDir = "asc" | "desc";

const COLS: { key: SortKey; label: string; align?: "right"; hideBelow?: string }[] = [
  { key: "name", label: "令牌 / 应用" },
  { key: "group", label: "分组", hideBelow: "md" },
  { key: "requests", label: "请求数", align: "right" },
  { key: "tokens", label: "Tokens", align: "right", hideBelow: "sm" },
  { key: "cost", label: "费用", align: "right" },
  { key: "successRate", label: "成功率", align: "right", hideBelow: "lg" },
  { key: "avgLatency", label: "平均延迟", align: "right", hideBelow: "lg" },
  { key: "lastUsed", label: "最近使用", align: "right", hideBelow: "xl" },
];

const HIDE: Record<string, string> = { sm: "hidden sm:table-cell", md: "hidden md:table-cell", lg: "hidden lg:table-cell", xl: "hidden xl:table-cell" };
const PAGE_SIZE = 8;

export function DataTable({ rows, currency }: { rows: KeyRow[]; currency: Currency }) {
  const [query, setQuery] = useState("");
  const [sortKey, setSortKey] = useState<SortKey>("cost");
  const [sortDir, setSortDir] = useState<SortDir>("desc");
  const [statusFilter, setStatusFilter] = useState<"all" | "healthy" | "warning">("all");
  const [page, setPage] = useState(0);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    let out = rows;
    if (q) out = out.filter((r) => r.name.toLowerCase().includes(q) || r.owner.toLowerCase().includes(q) || r.id.toLowerCase().includes(q) || r.models.some((m) => m.toLowerCase().includes(q)));
    if (statusFilter === "healthy") out = out.filter((r) => r.successRate >= 0.98);
    if (statusFilter === "warning") out = out.filter((r) => r.successRate < 0.98);
    const dir = sortDir === "asc" ? 1 : -1;
    return [...out].sort((a, b) => {
      const av = a[sortKey];
      const bv = b[sortKey];
      if (typeof av === "string" && typeof bv === "string") return av.localeCompare(bv, "zh-CN") * dir;
      return ((av as number) - (bv as number)) * dir;
    });
  }, [rows, query, sortKey, sortDir, statusFilter]);

  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, pageCount - 1);
  const pageRows = filtered.slice(safePage * PAGE_SIZE, safePage * PAGE_SIZE + PAGE_SIZE);
  const maxCost = Math.max(...rows.map((r) => r.cost), 1);

  const toggleSort = (k: SortKey) => {
    if (k === sortKey) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else {
      setSortKey(k);
      setSortDir(k === "name" || k === "group" ? "asc" : "desc");
    }
    setPage(0);
  };

  const exportCsv = () => {
    const head = ["令牌", "负责人", "分组", "模型", "请求数", "Tokens", "费用(USD)", "成功率", "平均延迟(ms)", "最近使用"];
    const lines = filtered.map((r) => [r.name, r.owner, r.group, r.models.join("|"), r.requests, r.tokens, r.cost.toFixed(4), (r.successRate * 100).toFixed(2), Math.round(r.avgLatency), r.lastUsed].join(","));
    const blob = new Blob(["\ufeff" + [head.join(","), ...lines].join("\n")], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "api-relay-keys.csv";
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <Card
      title="令牌用量明细"
      subtitle={`${filtered.length} 个令牌 · 点击表头排序`}
      bodyClassName="px-0 pb-3"
      action={
        <div className="flex items-center gap-2">
          <div className="hidden items-center rounded-lg bg-slate-100 p-0.5 sm:inline-flex dark:bg-slate-800">
            {(
              [
                ["all", "全部"],
                ["healthy", "健康"],
                ["warning", "需关注"],
              ] as const
            ).map(([v, l]) => (
              <button
                key={v}
                onClick={() => {
                  setStatusFilter(v);
                  setPage(0);
                }}
                className={cn("rounded-md px-2 py-1 text-[11px] font-medium transition-all", statusFilter === v ? "bg-white text-slate-900 shadow-sm dark:bg-slate-700 dark:text-white" : "text-slate-500 dark:text-slate-400")}
              >
                {l}
              </button>
            ))}
          </div>
          <div className="relative">
            <Search className="pointer-events-none absolute top-1/2 left-2.5 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
            <input
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setPage(0);
              }}
              placeholder="搜索令牌 / 负责人 / 模型"
              className="h-8 w-40 rounded-lg border border-slate-200 bg-white pr-2 pl-8 text-xs text-slate-700 outline-none placeholder:text-slate-400 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/20 sm:w-52 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
            />
          </div>
          <button onClick={exportCsv} title="导出 CSV" className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 text-slate-500 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800">
            <Download className="h-3.5 w-3.5" />
          </button>
        </div>
      }
    >
      <div className="overflow-x-auto">
        <table className="w-full min-w-[560px] text-xs">
          <thead>
            <tr className="border-y border-slate-100 bg-slate-50/60 text-[11px] text-slate-500 dark:border-slate-800 dark:bg-slate-800/40 dark:text-slate-400">
              {COLS.map((c) => (
                <th key={c.key} className={cn("px-4 py-2.5 font-medium whitespace-nowrap select-none", c.align === "right" && "text-right", c.hideBelow && HIDE[c.hideBelow])}>
                  <button onClick={() => toggleSort(c.key)} className={cn("inline-flex items-center gap-1 hover:text-slate-900 dark:hover:text-slate-100", sortKey === c.key && "text-indigo-600 dark:text-indigo-400")}>
                    {c.label}
                    {sortKey === c.key ? sortDir === "asc" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" /> : <ArrowUpDown className="h-3 w-3 opacity-40" />}
                  </button>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {pageRows.map((r) => {
              const g = GROUPS.find((x) => x.id === r.group)!;
              return (
                <tr key={r.id} className="transition-colors hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-2.5">
                      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-slate-100 to-slate-200 text-[11px] font-bold text-slate-600 dark:from-slate-800 dark:to-slate-700 dark:text-slate-300">
                        {r.name.slice(0, 1)}
                      </span>
                      <div className="min-w-0">
                        <div className="truncate font-medium text-slate-800 dark:text-slate-100">{r.name}</div>
                        <div className="flex items-center gap-1.5 truncate text-[11px] text-slate-400">
                          <span>{r.owner}</span>
                          <span className="hidden font-mono text-slate-300 sm:inline dark:text-slate-600">{r.id.slice(0, 11)}…</span>
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className={cn("px-4 py-2.5", HIDE.md)}>
                    <span className="inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[11px] font-medium" style={{ background: g.color + "1a", color: g.color }}>
                      <span className="h-1.5 w-1.5 rounded-full" style={{ background: g.color }} />
                      {g.label}
                    </span>
                    <div className="mt-1 flex flex-wrap gap-1">
                      {r.models.slice(0, 2).map((m) => (
                        <span key={m} className="rounded bg-slate-100 px-1 py-px font-mono text-[10px] text-slate-500 dark:bg-slate-800 dark:text-slate-400" style={{ borderLeft: `2px solid ${MODELS.find((x) => x.id === m)?.color}` }}>
                          {m}
                        </span>
                      ))}
                      {r.models.length > 2 && <span className="text-[10px] text-slate-400">+{r.models.length - 2}</span>}
                    </div>
                  </td>
                  <td className="px-4 py-2.5 text-right tabular-nums text-slate-700 dark:text-slate-200" title={fmtFull(r.requests)}>
                    {fmtNumber(r.requests)}
                  </td>
                  <td className={cn("px-4 py-2.5 text-right tabular-nums text-slate-700 dark:text-slate-200", HIDE.sm)} title={fmtFull(r.tokens)}>
                    {fmtNumber(r.tokens)}
                  </td>
                  <td className="px-4 py-2.5 text-right">
                    <div className="font-semibold tabular-nums text-slate-900 dark:text-white">{fmtCurrency(r.cost, currency)}</div>
                    <div className="mt-1 ml-auto h-1 w-16 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                      <div className="h-full rounded-full bg-amber-400 transition-all duration-500" style={{ width: `${(r.cost / maxCost) * 100}%` }} />
                    </div>
                  </td>
                  <td className={cn("px-4 py-2.5 text-right tabular-nums", HIDE.lg)}>
                    <span className={cn("font-medium", r.successRate >= 0.98 ? "text-emerald-600 dark:text-emerald-400" : r.successRate >= 0.95 ? "text-amber-600 dark:text-amber-400" : "text-rose-600 dark:text-rose-400")}>
                      {fmtPercent(r.successRate, 2)}
                    </span>
                  </td>
                  <td className={cn("px-4 py-2.5 text-right tabular-nums text-slate-600 dark:text-slate-300", HIDE.lg)}>{fmtLatency(r.avgLatency)}</td>
                  <td className={cn("px-4 py-2.5 text-right tabular-nums text-slate-500 dark:text-slate-400", HIDE.xl)}>{r.lastUsed}</td>
                </tr>
              );
            })}
            {pageRows.length === 0 && (
              <tr>
                <td colSpan={COLS.length} className="px-4 py-12 text-center text-slate-400">
                  没有匹配的令牌，试试调整筛选条件
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <div className="flex items-center justify-between px-5 pt-3 text-[11px] text-slate-500 dark:text-slate-400">
        <span>
          显示 {filtered.length === 0 ? 0 : safePage * PAGE_SIZE + 1}–{Math.min(filtered.length, (safePage + 1) * PAGE_SIZE)} / {filtered.length}
        </span>
        <div className="flex items-center gap-1">
          <button disabled={safePage === 0} onClick={() => setPage((p) => p - 1)} className="flex h-7 w-7 items-center justify-center rounded-md border border-slate-200 disabled:opacity-40 hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800">
            <ChevronLeft className="h-3.5 w-3.5" />
          </button>
          {Array.from({ length: pageCount }, (_, i) => i)
            .filter((i) => Math.abs(i - safePage) <= 1 || i === 0 || i === pageCount - 1)
            .reduce<(number | "…")[]>((acc, i, idx, arr) => {
              if (idx > 0 && i - (arr[idx - 1] as number) > 1) acc.push("…");
              acc.push(i);
              return acc;
            }, [])
            .map((i, idx) =>
              i === "…" ? (
                <span key={`e${idx}`} className="px-1">…</span>
              ) : (
                <button key={i} onClick={() => setPage(i)} className={cn("h-7 min-w-7 rounded-md px-1.5 tabular-nums", i === safePage ? "bg-indigo-600 font-semibold text-white" : "hover:bg-slate-100 dark:hover:bg-slate-800")}>
                  {i + 1}
                </button>
              ),
            )}
          <button disabled={safePage >= pageCount - 1} onClick={() => setPage((p) => p + 1)} className="flex h-7 w-7 items-center justify-center rounded-md border border-slate-200 disabled:opacity-40 hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800">
            <ChevronRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </Card>
  );
}
