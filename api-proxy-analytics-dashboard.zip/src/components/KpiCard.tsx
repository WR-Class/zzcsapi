import { ArrowDownRight, ArrowUpRight, Minus } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Area, AreaChart, ResponsiveContainer } from "recharts";
import { cn } from "../utils/cn";

interface KpiCardProps {
  label: string;
  value: string;
  delta: number; // fraction, e.g. 0.12
  hint: string;
  icon: LucideIcon;
  accent: string; // hex
  spark: number[];
  invert?: boolean; // when true, increase is bad (e.g. latency, cost)
  index?: number;
}

export function KpiCard({ label, value, delta, hint, icon: Icon, accent, spark, invert, index = 0 }: KpiCardProps) {
  const isFlat = !isFinite(delta) || Math.abs(delta) < 0.0005;
  const positive = delta > 0;
  const good = isFlat ? null : invert ? !positive : positive;
  const id = `spark-${label.replace(/\W/g, "")}`;

  return (
    <div
      style={{ animationDelay: `${index * 60}ms` }}
      className="group animate-fade-up relative overflow-hidden rounded-2xl border border-slate-200/80 bg-white p-4 shadow-sm shadow-slate-200/50 transition-all hover:-translate-y-0.5 hover:shadow-md dark:border-slate-800 dark:bg-slate-900 dark:shadow-none dark:hover:border-slate-700"
    >
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl" style={{ background: accent + "1a", color: accent }}>
            <Icon className="h-4.5 w-4.5" />
          </span>
          <span className="text-xs font-medium text-slate-500 dark:text-slate-400">{label}</span>
        </div>
        <span
          className={cn(
            "inline-flex items-center gap-0.5 rounded-full px-1.5 py-0.5 text-[11px] font-semibold tabular-nums",
            good === null && "bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400",
            good === true && "bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400",
            good === false && "bg-rose-50 text-rose-600 dark:bg-rose-500/10 dark:text-rose-400",
          )}
        >
          {isFlat ? <Minus className="h-3 w-3" /> : positive ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
          {isFlat ? "0.0%" : `${positive ? "+" : ""}${(delta * 100).toFixed(1)}%`}
        </span>
      </div>

      <div className="mt-3 flex items-end justify-between gap-2">
        <div className="min-w-0">
          <div className="truncate text-2xl font-bold tracking-tight tabular-nums text-slate-900 dark:text-white">{value}</div>
          <div className="mt-0.5 truncate text-[11px] text-slate-400 dark:text-slate-500">{hint}</div>
        </div>
        <div className="h-10 w-24 shrink-0 opacity-90">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={spark.map((v, i) => ({ i, v }))} margin={{ top: 2, right: 0, bottom: 0, left: 0 }}>
              <defs>
                <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={accent} stopOpacity={0.35} />
                  <stop offset="100%" stopColor={accent} stopOpacity={0} />
                </linearGradient>
              </defs>
              <Area type="monotone" dataKey="v" stroke={accent} strokeWidth={1.75} fill={`url(#${id})`} isAnimationActive animationDuration={700} dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
