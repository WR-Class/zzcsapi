export type Currency = "USD" | "CNY";
export const CNY_RATE = 7.25;

export function fmtNumber(n: number, digits = 1) {
  const abs = Math.abs(n);
  if (abs >= 1e9) return (n / 1e9).toFixed(digits) + "B";
  if (abs >= 1e6) return (n / 1e6).toFixed(digits) + "M";
  if (abs >= 1e3) return (n / 1e3).toFixed(digits) + "K";
  return Math.round(n).toLocaleString("zh-CN");
}

export function fmtFull(n: number) {
  return Math.round(n).toLocaleString("zh-CN");
}

export function fmtCurrency(usd: number, currency: Currency, compact = false) {
  const v = currency === "CNY" ? usd * CNY_RATE : usd;
  const sym = currency === "CNY" ? "¥" : "$";
  if (compact) return sym + fmtNumber(v, 1);
  return sym + v.toLocaleString("zh-CN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function fmtPercent(v: number, digits = 1) {
  return (v * 100).toFixed(digits) + "%";
}

export function fmtLatency(ms: number) {
  if (ms >= 1000) return (ms / 1000).toFixed(2) + " s";
  return Math.round(ms) + " ms";
}

export function fmtShortDate(d: string) {
  const [, m, day] = d.split("-");
  return `${Number(m)}/${Number(day)}`;
}

export function fmtDateCN(d: string) {
  const [y, m, day] = d.split("-");
  return `${y}年${Number(m)}月${Number(day)}日`;
}
