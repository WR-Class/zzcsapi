// ---------- Types ----------
export type Group = "default" | "vip" | "enterprise";

export interface ModelDef {
  id: string;
  vendor: string;
  channel: string;
  inputPrice: number; // USD per 1M tokens
  outputPrice: number; // USD per 1M tokens
  baseLatency: number; // ms
  popularity: number; // weight
  color: string;
}

export interface ApiKey {
  id: string;
  name: string;
  owner: string;
  group: Group;
  models: string[];
  weight: number;
  createdAt: string;
}

export interface UsageRecord {
  date: string; // YYYY-MM-DD
  dayIndex: number;
  keyId: string;
  group: Group;
  model: string;
  channel: string;
  requests: number;
  errors: number;
  promptTokens: number;
  completionTokens: number;
  cost: number; // USD
  latencySum: number; // requests * avg latency
}

// ---------- Static dimensions ----------
export const MODELS: ModelDef[] = [
  { id: "gpt-4o", vendor: "OpenAI", channel: "OpenAI 官方", inputPrice: 2.5, outputPrice: 10, baseLatency: 1800, popularity: 22, color: "#6366f1" },
  { id: "gpt-4o-mini", vendor: "OpenAI", channel: "Azure OpenAI", inputPrice: 0.15, outputPrice: 0.6, baseLatency: 900, popularity: 30, color: "#8b5cf6" },
  { id: "claude-3.5-sonnet", vendor: "Anthropic", channel: "Anthropic 官方", inputPrice: 3, outputPrice: 15, baseLatency: 2200, popularity: 18, color: "#f59e0b" },
  { id: "claude-3-haiku", vendor: "Anthropic", channel: "AWS Bedrock", inputPrice: 0.25, outputPrice: 1.25, baseLatency: 800, popularity: 9, color: "#fb923c" },
  { id: "deepseek-v3", vendor: "DeepSeek", channel: "DeepSeek 官方", inputPrice: 0.27, outputPrice: 1.1, baseLatency: 1500, popularity: 26, color: "#06b6d4" },
  { id: "deepseek-r1", vendor: "DeepSeek", channel: "DeepSeek 官方", inputPrice: 0.55, outputPrice: 2.19, baseLatency: 4200, popularity: 12, color: "#0ea5e9" },
  { id: "gemini-1.5-pro", vendor: "Google", channel: "Google Vertex", inputPrice: 1.25, outputPrice: 5, baseLatency: 1600, popularity: 8, color: "#10b981" },
  { id: "qwen-max", vendor: "阿里云", channel: "阿里云百炼", inputPrice: 0.33, outputPrice: 1.32, baseLatency: 1300, popularity: 10, color: "#ec4899" },
  { id: "glm-4-plus", vendor: "智谱", channel: "智谱 BigModel", inputPrice: 0.7, outputPrice: 0.7, baseLatency: 1400, popularity: 5, color: "#84cc16" },
  { id: "text-embedding-3-small", vendor: "OpenAI", channel: "Azure OpenAI", inputPrice: 0.02, outputPrice: 0, baseLatency: 220, popularity: 14, color: "#94a3b8" },
];

export const CHANNELS = Array.from(new Set(MODELS.map((m) => m.channel)));

export const GROUPS: { id: Group; label: string; color: string; multiplier: number }[] = [
  { id: "default", label: "默认分组", color: "#64748b", multiplier: 1 },
  { id: "vip", label: "VIP 用户", color: "#8b5cf6", multiplier: 0.85 },
  { id: "enterprise", label: "企业专线", color: "#0ea5e9", multiplier: 0.7 },
];

export const CHANNEL_COLORS: Record<string, string> = {
  "OpenAI 官方": "#6366f1",
  "Azure OpenAI": "#3b82f6",
  "Anthropic 官方": "#f59e0b",
  "AWS Bedrock": "#fb923c",
  "DeepSeek 官方": "#06b6d4",
  "Google Vertex": "#10b981",
  "阿里云百炼": "#ec4899",
  "智谱 BigModel": "#84cc16",
};

// ---------- Seeded RNG ----------
function mulberry32(seed: number) {
  return function () {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const rand = mulberry32(20250611);
const rnd = (min: number, max: number) => min + rand() * (max - min);
const pick = <T,>(arr: T[]) => arr[Math.floor(rand() * arr.length)];

// ---------- Helpers ----------
export const DAYS = 90;

export function toDateStr(d: Date) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function addDays(dateStr: string, n: number) {
  const d = new Date(dateStr + "T00:00:00");
  d.setDate(d.getDate() + n);
  return toDateStr(d);
}

export const TODAY = toDateStr(new Date());
export const FIRST_DAY = addDays(TODAY, -(DAYS - 1));

// ---------- API keys ----------
const OWNERS = ["林小满", "张伟", "Alice Chen", "周若曦", "王浩然", "Kevin Wu", "陈梓萱", "李思远", "Sophia Liu", "赵云飞", "黄宇航", "Emma Zhang", "吴佳琪", "郑博文", "David Li", "孙一诺"];
const KEY_NAMES = ["客服机器人", "文档翻译", "代码助手", "内容审核", "数据标注", "智能写作", "知识库问答", "会议纪要", "商品描述生成", "语音转写后处理", "SQL 生成", "简历筛选", "舆情分析", "教育答疑", "游戏 NPC", "邮件助手", "法务合同审查", "医疗问诊辅助", "电商推荐", "视频脚本", "论文润色", "多语种客服", "财报摘要", "API 测试", "Prompt 实验室", "移动端 App", "小程序后端", "Chrome 插件", "Slack Bot", "飞书机器人", "钉钉助手", "Discord Bot", "内部工具", "个人测试", "RAG 检索", "Agent 工作流"];

export const API_KEYS: ApiKey[] = Array.from({ length: 42 }, (_, i) => {
  const groupRoll = rand();
  const group: Group = groupRoll < 0.5 ? "default" : groupRoll < 0.8 ? "vip" : "enterprise";
  const modelCount = 1 + Math.floor(rand() * 3);
  const models = new Set<string>();
  while (models.size < modelCount) {
    // weighted by popularity
    const total = MODELS.reduce((s, m) => s + m.popularity, 0);
    let r = rand() * total;
    for (const m of MODELS) {
      r -= m.popularity;
      if (r <= 0) {
        models.add(m.id);
        break;
      }
    }
  }
  const weight = group === "enterprise" ? rnd(2, 6) : group === "vip" ? rnd(0.8, 2.5) : rnd(0.2, 1.2);
  return {
    id: `sk-${(i + 1).toString(36).padStart(2, "0")}${Math.floor(rand() * 0xffffff).toString(16).padStart(6, "0")}`,
    name: KEY_NAMES[i % KEY_NAMES.length] + (i >= KEY_NAMES.length ? ` v${Math.floor(i / KEY_NAMES.length) + 1}` : ""),
    owner: pick(OWNERS),
    group,
    models: Array.from(models),
    weight,
    createdAt: addDays(FIRST_DAY, -Math.floor(rand() * 200)),
  };
});

// ---------- Hourly profile ----------
export const HOUR_PROFILE: Record<Group, number[]> = {
  default: [1.2, 0.8, 0.5, 0.4, 0.4, 0.5, 0.9, 1.6, 2.8, 3.6, 4.0, 3.8, 3.0, 3.4, 4.1, 4.3, 4.0, 3.5, 3.0, 3.2, 3.6, 3.4, 2.6, 1.8],
  vip: [1.5, 1.0, 0.7, 0.5, 0.5, 0.6, 1.0, 1.8, 3.0, 3.9, 4.2, 4.0, 3.2, 3.6, 4.3, 4.5, 4.2, 3.7, 3.1, 3.3, 3.8, 3.6, 2.8, 2.0],
  enterprise: [0.6, 0.4, 0.3, 0.3, 0.3, 0.4, 1.0, 2.6, 4.8, 5.6, 5.8, 5.4, 4.0, 4.8, 5.7, 5.9, 5.5, 4.6, 3.0, 2.0, 1.4, 1.1, 0.9, 0.7],
};

// Relative reliability of each upstream channel (1 = baseline error rate)
const CHANNEL_RELIABILITY: Record<string, number> = {
  "OpenAI 官方": 0.6,
  "Azure OpenAI": 0.35,
  "Anthropic 官方": 0.9,
  "AWS Bedrock": 0.5,
  "DeepSeek 官方": 2.4,
  "Google Vertex": 0.8,
  "阿里云百炼": 1.1,
  "智谱 BigModel": 1.6,
};

// ---------- Usage generation ----------
function buildRecords(): UsageRecord[] {
  const records: UsageRecord[] = [];
  const modelMap = Object.fromEntries(MODELS.map((m) => [m.id, m]));

  // A few incident days for realism
  const incidents: Record<string, { channel: string; errorBoost: number; latencyBoost: number }> = {};
  for (let k = 0; k < 4; k++) {
    const day = Math.floor(rnd(5, DAYS - 3));
    incidents[day] = { channel: pick(CHANNELS), errorBoost: rnd(4, 9), latencyBoost: rnd(1.6, 2.6) };
  }

  for (let d = 0; d < DAYS; d++) {
    const date = addDays(FIRST_DAY, d);
    const dow = new Date(date + "T00:00:00").getDay();
    const weekend = dow === 0 || dow === 6 ? 0.62 : 1;
    const growth = 1 + (d / DAYS) * 0.55; // steady growth
    const seasonal = 1 + 0.08 * Math.sin((d / 7) * Math.PI * 2);
    const dayNoise = rnd(0.88, 1.12);

    for (const key of API_KEYS) {
      if (key.createdAt > date) continue;
      const keyDailyBase = key.weight * 320;
      for (const modelId of key.models) {
        const m = modelMap[modelId];
        const share = 1 / key.models.length;
        let requests = Math.round(keyDailyBase * share * weekend * growth * seasonal * dayNoise * rnd(0.7, 1.3) * (m.popularity / 15));
        if (requests <= 0) requests = Math.round(rnd(0, 4));
        if (requests === 0) continue;

        const isEmbedding = m.id.startsWith("text-embedding");
        const promptPer = isEmbedding ? rnd(150, 600) : rnd(400, 2600);
        const completionPer = isEmbedding ? 0 : m.id.includes("r1") ? rnd(900, 3200) : rnd(120, 900);
        const promptTokens = Math.round(requests * promptPer);
        const completionTokens = Math.round(requests * completionPer);
        const groupMult = GROUPS.find((g) => g.id === key.group)!.multiplier;
        const cost = ((promptTokens * m.inputPrice) / 1e6 + (completionTokens * m.outputPrice) / 1e6) * groupMult;

        let errorRate = rnd(0.003, 0.014) * (CHANNEL_RELIABILITY[m.channel] ?? 1);
        let latency = m.baseLatency * rnd(0.8, 1.25);
        const inc = incidents[d];
        if (inc && inc.channel === m.channel) {
          errorRate *= inc.errorBoost;
          latency *= inc.latencyBoost;
        }
        const errors = Math.round(requests * Math.min(errorRate, 0.4));

        records.push({
          date,
          dayIndex: d,
          keyId: key.id,
          group: key.group,
          model: m.id,
          channel: m.channel,
          requests,
          errors,
          promptTokens,
          completionTokens,
          cost,
          latencySum: latency * requests,
        });
      }
    }
  }
  return records;
}

export const RECORDS: UsageRecord[] = buildRecords();

// ---------- Aggregations ----------
export interface Filters {
  start: string;
  end: string;
  groups: Group[];
  models: string[];
  channels: string[];
}

export function filterRecords(records: UsageRecord[], f: Filters) {
  return records.filter(
    (r) =>
      r.date >= f.start &&
      r.date <= f.end &&
      (f.groups.length === 0 || f.groups.includes(r.group)) &&
      (f.models.length === 0 || f.models.includes(r.model)) &&
      (f.channels.length === 0 || f.channels.includes(r.channel)),
  );
}

export interface Totals {
  requests: number;
  errors: number;
  promptTokens: number;
  completionTokens: number;
  tokens: number;
  cost: number;
  latencySum: number;
  avgLatency: number;
  successRate: number;
  activeKeys: number;
}

export function emptyTotals(): Totals {
  return { requests: 0, errors: 0, promptTokens: 0, completionTokens: 0, tokens: 0, cost: 0, latencySum: 0, avgLatency: 0, successRate: 0, activeKeys: 0 };
}

export function sumRecords(records: UsageRecord[]): Totals {
  const t = emptyTotals();
  const keys = new Set<string>();
  for (const r of records) {
    t.requests += r.requests;
    t.errors += r.errors;
    t.promptTokens += r.promptTokens;
    t.completionTokens += r.completionTokens;
    t.cost += r.cost;
    t.latencySum += r.latencySum;
    keys.add(r.keyId);
  }
  t.tokens = t.promptTokens + t.completionTokens;
  t.avgLatency = t.requests ? t.latencySum / t.requests : 0;
  t.successRate = t.requests ? 1 - t.errors / t.requests : 0;
  t.activeKeys = keys.size;
  return t;
}

export function groupBy<K extends string>(records: UsageRecord[], keyFn: (r: UsageRecord) => K) {
  const map = new Map<K, UsageRecord[]>();
  for (const r of records) {
    const k = keyFn(r);
    const arr = map.get(k);
    if (arr) arr.push(r);
    else map.set(k, [r]);
  }
  return map;
}

export function dateRange(start: string, end: string) {
  const out: string[] = [];
  let d = start;
  while (d <= end) {
    out.push(d);
    d = addDays(d, 1);
  }
  return out;
}

export function daysBetween(start: string, end: string) {
  return Math.round((new Date(end + "T00:00:00").getTime() - new Date(start + "T00:00:00").getTime()) / 86400000) + 1;
}
