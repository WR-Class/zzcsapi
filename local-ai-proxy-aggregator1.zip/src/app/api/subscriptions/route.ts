import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { subscriptions } from "@/db/schema";
import { desc, ilike, or, eq, and } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q")?.trim() || "";
    const provider = searchParams.get("provider") || "";
    const status = searchParams.get("status") || "";
    const conditions = [];
    if (q) conditions.push(or(ilike(subscriptions.name, `%${q}%`), ilike(subscriptions.email, `%${q}%`)));
    if (provider) conditions.push(eq(subscriptions.provider, provider));
    if (status) conditions.push(eq(subscriptions.status, status));
    const rows = await db.select().from(subscriptions).where(conditions.length ? and(...conditions) : undefined).orderBy(desc(subscriptions.id));
    return NextResponse.json({ data: rows });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "获取订阅失败" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const b = await req.json();
    if (!b.name?.trim()) return NextResponse.json({ error: "订阅名称必填" }, { status: 400 });
    const [row] = await db.insert(subscriptions).values({
      name: b.name.trim(),
      provider: b.provider || "claude-pro",
      email: b.email || "",
      authType: b.authType || "oauth",
      accessToken: b.accessToken || "",
      refreshToken: b.refreshToken || "",
      expiresAt: b.expiresAt ? new Date(b.expiresAt) : null,
      quotaTotal: Number(b.quotaTotal) || 0,
      quotaUsed: Number(b.quotaUsed) || 0,
      status: b.status || "active",
      enabled: b.enabled !== false,
      channelId: b.channelId ? Number(b.channelId) : null,
      plan: b.plan || "Pro",
      renewsAt: b.renewsAt ? new Date(b.renewsAt) : null,
      remarks: b.remarks || "",
    }).returning();
    return NextResponse.json({ data: row });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "创建订阅失败" }, { status: 500 });
  }
}
