import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { subscriptions } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const rows = await db.select().from(subscriptions).where(eq(subscriptions.id, Number(id)));
  const sub = rows[0];
  if (!sub) return NextResponse.json({ error: "订阅不存在" }, { status: 404 });
  // 模拟 OAuth 刷新:延长过期时间,重置部分额度
  await new Promise((r) => setTimeout(r, 800));
  const expiresAt = new Date(Date.now() + 30 * 24 * 3600 * 1000);
  const renewsAt = new Date(Date.now() + 30 * 24 * 3600 * 1000);
  const [row] = await db.update(subscriptions).set({
    status: "active",
    expiresAt,
    renewsAt,
    lastRefreshAt: new Date(),
    updatedAt: new Date(),
  }).where(eq(subscriptions.id, sub.id)).returning();
  return NextResponse.json({ data: { ...row, message: "Token 已刷新,有效期延长 30 天" } });
}
