import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { subscriptions } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const b = await req.json();
    const patch: Record<string, unknown> = { updatedAt: new Date() };
    for (const f of ["name", "provider", "email", "authType", "accessToken", "refreshToken", "quotaTotal", "quotaUsed", "status", "enabled", "plan", "remarks"]) {
      if (b[f] !== undefined) patch[f] = b[f];
    }
    if (b.expiresAt !== undefined) patch.expiresAt = b.expiresAt ? new Date(b.expiresAt) : null;
    if (b.renewsAt !== undefined) patch.renewsAt = b.renewsAt ? new Date(b.renewsAt) : null;
    if (b.channelId !== undefined) patch.channelId = b.channelId ? Number(b.channelId) : null;
    const [row] = await db.update(subscriptions).set(patch).where(eq(subscriptions.id, Number(id))).returning();
    if (!row) return NextResponse.json({ error: "订阅不存在" }, { status: 404 });
    return NextResponse.json({ data: row });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "更新订阅失败" }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    await db.delete(subscriptions).where(eq(subscriptions.id, Number(id)));
    return NextResponse.json({ success: true });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "删除订阅失败" }, { status: 500 });
  }
}
