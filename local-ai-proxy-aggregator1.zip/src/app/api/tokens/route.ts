import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { tokens } from "@/db/schema";
import { desc, ilike, eq, and } from "drizzle-orm";

function genKey() {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let s = "";
  for (let i = 0; i < 32; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return "sk-local-" + s;
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q")?.trim() || "";
    const enabled = searchParams.get("enabled") || "";
    const conditions = [];
    if (q) conditions.push(ilike(tokens.name, `%${q}%`));
    if (enabled === "true") conditions.push(eq(tokens.enabled, true));
    if (enabled === "false") conditions.push(eq(tokens.enabled, false));
    const rows = await db.select().from(tokens).where(conditions.length ? and(...conditions) : undefined).orderBy(desc(tokens.id));
    return NextResponse.json({ data: rows });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "获取令牌失败" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const b = await req.json();
    if (!b.name?.trim()) return NextResponse.json({ error: "令牌名称必填" }, { status: 400 });
    const [row] = await db.insert(tokens).values({
      name: b.name.trim(),
      key: b.key?.trim() || genKey(),
      quota: b.unlimited ? -1 : (Number(b.quota) || -1),
      usedQuota: 0,
      modelsAllowed: Array.isArray(b.modelsAllowed) ? b.modelsAllowed : [],
      group: b.group || "default",
      enabled: b.enabled !== false,
      expiresAt: b.expiresAt ? new Date(b.expiresAt) : null,
      remarks: b.remarks || "",
    }).returning();
    return NextResponse.json({ data: row });
  } catch (e: unknown) {
    console.error(e);
    const msg = e instanceof Error && e.message.includes("unique") ? "密钥已存在,请更换" : "创建令牌失败";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
