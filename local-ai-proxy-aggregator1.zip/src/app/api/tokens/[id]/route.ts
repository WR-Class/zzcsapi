import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { tokens } from "@/db/schema";
import { eq } from "drizzle-orm";

function genKey() {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let s = "";
  for (let i = 0; i < 32; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return "sk-local-" + s;
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const b = await req.json();
    const patch: Record<string, unknown> = { updatedAt: new Date() };
    for (const f of ["name", "group", "enabled", "remarks", "modelsAllowed", "requestCount", "usedQuota"]) {
      if (b[f] !== undefined) patch[f] = b[f];
    }
    if (b.regenerate) patch.key = genKey();
    else if (b.key !== undefined) patch.key = b.key;
    if (b.unlimited !== undefined) patch.quota = b.unlimited ? -1 : (Number(b.quota) || -1);
    else if (b.quota !== undefined) patch.quota = Number(b.quota);
    if (b.expiresAt !== undefined) patch.expiresAt = b.expiresAt ? new Date(b.expiresAt) : null;
    if (b.resetUsed) patch.usedQuota = 0;
    const [row] = await db.update(tokens).set(patch).where(eq(tokens.id, Number(id))).returning();
    if (!row) return NextResponse.json({ error: "令牌不存在" }, { status: 404 });
    return NextResponse.json({ data: row });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "更新令牌失败" }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    await db.delete(tokens).where(eq(tokens.id, Number(id)));
    return NextResponse.json({ success: true });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "删除令牌失败" }, { status: 500 });
  }
}
