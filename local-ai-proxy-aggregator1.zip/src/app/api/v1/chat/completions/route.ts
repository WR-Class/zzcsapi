import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { channels, models, requestLogs, settings, tokens } from "@/db/schema";
import { eq, and } from "drizzle-orm";

async function getSetting(key: string, fallback: string) {
  const rows = await db.select().from(settings).where(eq(settings.key, key));
  return rows[0]?.value ?? fallback;
}

export async function POST(req: NextRequest) {
  const started = Date.now();
  let logCtx = { tokenId: 0, tokenName: "-", channelId: 0, channelName: "-", model: "unknown" };
  try {
    const auth = req.headers.get("authorization") || "";
    const apiKey = auth.replace(/^Bearer\s+/i, "").trim();
    if (!apiKey) return NextResponse.json({ error: { message: "缺少 API Key,请在 Authorization 头中提供 Bearer Token", type: "invalid_request_error" } }, { status: 401 });

    const tokRows = await db.select().from(tokens).where(eq(tokens.key, apiKey));
    const tok = tokRows[0];
    if (!tok || !tok.enabled) return NextResponse.json({ error: { message: "无效或已禁用的 API Key", type: "invalid_request_error" } }, { status: 401 });
    if (tok.expiresAt && new Date(tok.expiresAt) < new Date()) return NextResponse.json({ error: { message: "API Key 已过期", type: "invalid_request_error" } }, { status: 401 });

    const body = await req.json();
    const modelId: string = body.model || "";
    if (!modelId) return NextResponse.json({ error: { message: "缺少 model 参数" } }, { status: 400 });
    if (tok.modelsAllowed?.length && !tok.modelsAllowed.includes(modelId)) {
      return NextResponse.json({ error: { message: `当前 Token 无权访问模型 ${modelId}` } }, { status: 403 });
    }
    logCtx = { tokenId: tok.id, tokenName: tok.name, channelId: 0, channelName: "-", model: modelId };

    // 路由:找支持该模型的启用渠道,按 priority/weight 排序
    const allChannels = await db.select().from(channels).where(eq(channels.enabled, true));
    let candidates = allChannels.filter((c) => c.models.length === 0 || c.models.includes(modelId));
    if (!candidates.length) candidates = allChannels;
    if (!candidates.length) return NextResponse.json({ error: { message: "没有可用的上游渠道,请先在控制台添加渠道" } }, { status: 503 });
    candidates.sort((a, b) => b.priority - a.priority || b.weight - a.weight);

    const modelRows = await db.select().from(models).where(eq(models.modelId, modelId));
    const modelInfo = modelRows[0];
    const enableMock = (await getSetting("enable_mock", "true")) === "true";

    // 提取用户最后一条消息用于 mock 回复
    const messages: Array<{ role: string; content: string }> = body.messages || [];
    const lastUser = [...messages].reverse().find((m) => m.role === "user")?.content?.slice(0, 200) || "你好";

    let lastError = "";
    for (const ch of candidates) {
      logCtx.channelId = ch.id;
      logCtx.channelName = ch.name;
      const isDemo = !ch.apiKey || ch.apiKey.startsWith("sk-demo");

      // Mock 模式:demo key 直接返回模拟结果,保证本地可玩
      if (isDemo && enableMock) {
        const latency = 400 + Math.floor(Math.random() * 900);
        await new Promise((r) => setTimeout(r, Math.min(latency, 700)));
        const promptTokens = Math.max(10, Math.round(JSON.stringify(messages).length / 4));
        const completionTokens = 120 + Math.floor(Math.random() * 200);
        const cost = modelInfo ? (promptTokens / 1000) * (modelInfo.inputPrice / 1000) + (completionTokens / 1000) * (modelInfo.outputPrice / 1000) : 0.001;
        await db.insert(requestLogs).values({
          tokenId: tok.id, tokenName: tok.name, channelId: ch.id, channelName: ch.name,
          model: modelId, type: "chat", promptTokens, completionTokens, totalTokens: promptTokens + completionTokens,
          cost, latencyMs: latency, success: true, statusCode: 200, ip: req.headers.get("x-forwarded-for") || "127.0.0.1",
        });
        await db.update(tokens).set({ usedQuota: tok.usedQuota + promptTokens + completionTokens, requestCount: tok.requestCount + 1, lastUsedAt: new Date() }).where(eq(tokens.id, tok.id));
        const mockText = `【本地聚合网关 · 模拟回复】\n\n你通过渠道「${ch.name}」调用了模型 \`${modelId}\`。\n\n> 你的输入: ${typeof lastUser === "string" ? lastUser : "多模态消息"}\n\n由于该渠道当前使用的是演示 Key(\`sk-demo...\`),网关未真实请求上游,而是返回了这条模拟结果。在「渠道管理」中填入真实 API Key 后即可透传真实模型。这条调用已计入日志与统计。`;
        if (body.stream) {
          const encoder = new TextEncoder();
          const stream = new ReadableStream({
            async start(controller) {
              const chunks = mockText.match(/[\s\S]{1,24}/g) || [mockText];
              for (const c of chunks) {
                controller.enqueue(encoder.encode(`data: ${JSON.stringify({ id: "chatcmpl-mock", object: "chat.completion.chunk", created: Math.floor(Date.now() / 1000), model: modelId, choices: [{ index: 0, delta: { content: c }, finish_reason: null }] })}\n\n`));
                await new Promise((r) => setTimeout(r, 30));
              }
              controller.enqueue(encoder.encode(`data: ${JSON.stringify({ id: "chatcmpl-mock", object: "chat.completion.chunk", created: Math.floor(Date.now() / 1000), model: modelId, choices: [{ index: 0, delta: {}, finish_reason: "stop" }] })}\n\n`));
              controller.enqueue(encoder.encode("data: [DONE]\n\n"));
              controller.close();
            },
          });
          return new Response(stream, { headers: { "Content-Type": "text/event-stream", "Cache-Control": "no-cache", Connection: "keep-alive" } });
        }
        return NextResponse.json({
          id: `chatcmpl-mock-${Date.now()}`,
          object: "chat.completion",
          created: Math.floor(Date.now() / 1000),
          model: modelId,
          choices: [{ index: 0, message: { role: "assistant", content: mockText }, finish_reason: "stop" }],
          usage: { prompt_tokens: promptTokens, completion_tokens: completionTokens, total_tokens: promptTokens + completionTokens },
          _gateway: { channel: ch.name, mocked: true },
        });
      }

      // 真实转发
      try {
        const base = ch.baseUrl.replace(/\/$/, "");
        const url = `${base}/chat/completions`;
        const ctrl = new AbortController();
        const timeout = setTimeout(() => ctrl.abort(), 90000);
        const upstream = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${ch.apiKey}` },
          body: JSON.stringify(body),
          signal: ctrl.signal,
        });
        clearTimeout(timeout);
        const latency = Date.now() - started;
        if (!upstream.ok) {
          lastError = `渠道 ${ch.name} 返回 ${upstream.status}`;
          if (candidates.indexOf(ch) < candidates.length - 1) continue; // 故障转移下一个渠道
          const errText = await upstream.text().catch(() => "");
          await db.insert(requestLogs).values({
            tokenId: tok.id, tokenName: tok.name, channelId: ch.id, channelName: ch.name,
            model: modelId, type: "chat", promptTokens: 0, completionTokens: 0, totalTokens: 0,
            cost: 0, latencyMs: latency, success: false, statusCode: upstream.status, ip: "127.0.0.1", error: errText.slice(0, 500),
          });
          return NextResponse.json({ error: { message: lastError, detail: errText.slice(0, 500) } }, { status: upstream.status });
        }
        // 成功:非流式记录用量
        if (!body.stream) {
          const data = await upstream.json();
          const usage = data.usage || {};
          const pt = usage.prompt_tokens || 0, ct = usage.completion_tokens || 0;
          const cost = modelInfo ? (pt / 1000) * (modelInfo.inputPrice / 1000) + (ct / 1000) * (modelInfo.outputPrice / 1000) : 0;
          await db.insert(requestLogs).values({
            tokenId: tok.id, tokenName: tok.name, channelId: ch.id, channelName: ch.name,
            model: modelId, type: "chat", promptTokens: pt, completionTokens: ct, totalTokens: pt + ct,
            cost, latencyMs: latency, success: true, statusCode: 200, ip: "127.0.0.1",
          });
          await db.update(tokens).set({ usedQuota: tok.usedQuota + pt + ct, requestCount: tok.requestCount + 1, lastUsedAt: new Date() }).where(eq(tokens.id, tok.id));
          await db.update(channels).set({ totalRequests: ch.totalRequests + 1, totalTokens: ch.totalTokens + pt + ct, status: "ok", latencyMs: latency }).where(eq(channels.id, ch.id));
          return NextResponse.json(data);
        }
        // 流式透传
        return new Response(upstream.body, {
          status: 200,
          headers: { "Content-Type": "text/event-stream", "Cache-Control": "no-cache", Connection: "keep-alive" },
        });
      } catch (e) {
        lastError = e instanceof Error ? e.message : "上游连接失败";
        if (candidates.indexOf(ch) < candidates.length - 1) continue;
      }
    }
    const latency = Date.now() - started;
    await db.insert(requestLogs).values({
      tokenId: logCtx.tokenId, tokenName: logCtx.tokenName, channelId: logCtx.channelId, channelName: logCtx.channelName,
      model: logCtx.model, type: "chat", promptTokens: 0, completionTokens: 0, totalTokens: 0,
      cost: 0, latencyMs: latency, success: false, statusCode: 502, ip: "127.0.0.1", error: lastError.slice(0, 500),
    });
    return NextResponse.json({ error: { message: "所有上游渠道均失败: " + lastError } }, { status: 502 });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: { message: "网关内部错误" } }, { status: 500 });
  }
}
