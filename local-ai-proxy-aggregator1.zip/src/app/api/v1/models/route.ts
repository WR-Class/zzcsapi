import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { models, tokens } from "@/db/schema";
import { eq } from "drizzle-orm";

async function authToken(req: NextRequest) {
  const auth = req.headers.get("authorization") || "";
  const key = auth.replace(/^Bearer\s+/i, "").trim();
  if (!key) return null;
  const rows = await db.select().from(tokens).where(eq(tokens.key, key));
  const t = rows[0];
  if (!t || !t.enabled) return null;
  if (t.expiresAt && new Date(t.expiresAt) < new Date()) return null;
  return t;
}

export async function GET(req: NextRequest) {
  const t = await authToken(req);
  if (!t) return NextResponse.json({ error: { message: "无效的 API Key", type: "invalid_request_error", code: "invalid_api_key" } }, { status: 401 });
  const rows = await db.select().from(models).where(eq(models.enabled, true));
  const allowed = t.modelsAllowed?.length ? rows.filter((m) => t.modelsAllowed.includes(m.modelId)) : rows;
  return NextResponse.json({
    object: "list",
    data: allowed.map((m) => ({ id: m.modelId, object: "model", created: Math.floor(new Date(m.createdAt).getTime() / 1000), owned_by: m.provider })),
  });
}
