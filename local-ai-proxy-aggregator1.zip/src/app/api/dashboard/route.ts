import { NextResponse } from "next/server";
import { db } from "@/db";
import { channels, models, requestLogs, subscriptions, tokens } from "@/db/schema";
import { sql, desc, eq } from "drizzle-orm";

export async function GET() {
  try {
    const [totals] = await db.select({
      totalRequests: sql<number>`count(*)::int`,
      totalTokens: sql<number>`coalesce(sum(${requestLogs.totalTokens}),0)::int`,
      totalCost: sql<number>`coalesce(sum(${requestLogs.cost}),0)::float`,
      successCount: sql<number>`sum(case when ${requestLogs.success} then 1 else 0 end)::int`,
      avgLatency: sql<number>`coalesce(avg(${requestLogs.latencyMs}),0)::int`,
    }).from(requestLogs);

    const [chStats] = await db.select({
      total: sql<number>`count(*)::int`,
      enabled: sql<number>`sum(case when ${channels.enabled} then 1 else 0 end)::int`,
      ok: sql<number>`sum(case when ${channels.status}='ok' then 1 else 0 end)::int`,
    }).from(channels);

    const [tokStats] = await db.select({
      total: sql<number>`count(*)::int`,
      enabled: sql<number>`sum(case when ${tokens.enabled} then 1 else 0 end)::int`,
    }).from(tokens);

    const [subStats] = await db.select({
      total: sql<number>`count(*)::int`,
      active: sql<number>`sum(case when ${subscriptions.status}='active' then 1 else 0 end)::int`,
    }).from(subscriptions);

    const [modelCount] = await db.select({ total: sql<number>`count(*)::int` }).from(models);

    // 近7天
    const daily = await db.execute(sql`
      select to_char(created_at,'MM-DD') as date,
        count(*)::int as requests,
        coalesce(sum(total_tokens),0)::int as tokens,
        coalesce(sum(cost),0)::float as cost,
        sum(case when success then 1 else 0 end)::int as success,
        sum(case when not success then 1 else 0 end)::int as failed
      from request_logs
      where created_at >= now() - interval '7 days'
      group by 1 order by 1
    `);

    // 模型分布 top8
    const modelDist = await db.select({
      model: requestLogs.model,
      count: sql<number>`count(*)::int`,
      tokens: sql<number>`coalesce(sum(${requestLogs.totalTokens}),0)::int`,
      cost: sql<number>`coalesce(sum(${requestLogs.cost}),0)::float`,
    }).from(requestLogs).groupBy(requestLogs.model).orderBy(desc(sql`count(*)`)).limit(8);

    // 渠道健康
    const channelList = await db.select({
      id: channels.id,
      name: channels.name,
      type: channels.type,
      status: channels.status,
      enabled: channels.enabled,
      latencyMs: channels.latencyMs,
      successRate: channels.successRate,
      totalRequests: channels.totalRequests,
    }).from(channels).orderBy(desc(channels.priority)).limit(10);

    // 今日
    const [today] = await db.select({
      requests: sql<number>`count(*)::int`,
      tokens: sql<number>`coalesce(sum(${requestLogs.totalTokens}),0)::int`,
      cost: sql<number>`coalesce(sum(${requestLogs.cost}),0)::float`,
    }).from(requestLogs).where(sql`created_at >= current_date`);

    const recent = await db.select().from(requestLogs).orderBy(desc(requestLogs.id)).limit(6);

    // 小时分布(今日24h)
    const hourly = await db.execute(sql`
      select to_char(created_at,'HH24') as hour, count(*)::int as requests
      from request_logs where created_at >= current_date
      group by 1 order by 1
    `);

    return NextResponse.json({
      data: {
        totals: {
          totalRequests: totals?.totalRequests || 0,
          totalTokens: totals?.totalTokens || 0,
          totalCost: totals?.totalCost || 0,
          successRate: totals?.totalRequests ? ((totals.successCount || 0) / totals.totalRequests) * 100 : 100,
          avgLatency: totals?.avgLatency || 0,
        },
        today: today || { requests: 0, tokens: 0, cost: 0 },
        channels: chStats || { total: 0, enabled: 0, ok: 0 },
        tokens: tokStats || { total: 0, enabled: 0 },
        subs: subStats || { total: 0, active: 0 },
        modelCount: modelCount?.total || 0,
        daily: daily.rows,
        hourly: hourly.rows,
        modelDist,
        channelList,
        recent,
      },
    });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "获取统计失败" }, { status: 500 });
  }
}
