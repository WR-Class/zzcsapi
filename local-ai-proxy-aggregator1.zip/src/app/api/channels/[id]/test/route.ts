import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { channels } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const rows = await db.select().from(channels).where(eq(channels.id, Number(id)));
  const ch = rows[0];
  if (!ch) return NextResponse.json({ error: "渠道不存在" }, { status: 404 });

  const started = Date.now();
  // Demo key 或本地 mock -> 模拟测试
  const isDemo = !ch.apiKey || ch.apiKey.startsWith("sk-demo") || ch.apiKey === "ollama";
  if (isDemo) {
    const latency = 200 + Math.floor(Math.random() * 1200);
    await new Promise((r) => setTimeout(r, Math.min(latency, 900)));
    const ok = ch.status !== "error" || Math.random() > 0.3;
    await db.update(channels).set({
      status: ok ? "ok" : "error",
      latencyMs: latency,
      lastCheckAt: new Date(),
      lastError: ok ? "" : "模拟拨测:上游连接超时 (demo key)",
      updatedAt: new Date(),
    }).where(eq(channels.id, ch.id));
    return NextResponse.json({ data: { ok, latencyMs: latency, message: ok ? "连接正常 (模拟拨测, demo key 未真实请求上游)" : "上游连接超时 (模拟)" } });
  }

  // 真实拨测: GET {baseUrl}/models
  try {
    const base = ch.baseUrl.replace(/\/$/, "");
    const url = base.endsWith("/models") ? base : `${base}/models`;
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 10000);
    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${ch.apiKey}` },
      signal: ctrl.signal,
    });
    clearTimeout(timer);
    const latency = Date.now() - started;
    const ok = res.ok;
    const text = ok ? "" : `HTTP ${res.status}: ${(await res.text()).slice(0, 200)}`;
    await db.update(channels).set({
      status: ok ? "ok" : "error",
      latencyMs: latency,
      lastCheckAt: new Date(),
      lastError: text,
      updatedAt: new Date(),
    }).where(eq(channels.id, ch.id));
    return NextResponse.json({ data: { ok, latencyMs: latency, message: ok ? "连接正常" : text } });
  } catch (e) {
    const latency = Date.now() - started;
    const msg = e instanceof Error ? e.message : "连接失败";
    await db.update(channels).set({
      status: "error",
      latencyMs: latency,
      lastCheckAt: new Date(),
      lastError: msg,
      updatedAt: new Date(),
    }).where(eq(channels.id, ch.id));
    return NextResponse.json({ data: { ok: false, latencyMs: latency, message: msg } });
  }
}
