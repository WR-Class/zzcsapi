import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { channels } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const rows = await db.select().from(channels).where(eq(channels.id, Number(id)));
  if (!rows[0]) return NextResponse.json({ error: "渠道不存在" }, { status: 404 });
  return NextResponse.json({ data: rows[0] });
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const body = await req.json();
    const patch: Record<string, unknown> = {};
    const fields = ["name", "type", "baseUrl", "apiKey", "group", "weight", "priority", "enabled", "remarks", "config", "status"];
    for (const f of fields) if (body[f] !== undefined) patch[f] = body[f];
    if (body.models !== undefined) {
      patch.models = Array.isArray(body.models) ? body.models : typeof body.models === "string" ? body.models.split(",").map((s: string) => s.trim()).filter(Boolean) : [];
    }
    patch.updatedAt = new Date();
    if (body.name !== undefined && !String(body.name).trim()) return NextResponse.json({ error: "渠道名称不能为空" }, { status: 400 });
    const [row] = await db.update(channels).set(patch).where(eq(channels.id, Number(id))).returning();
    if (!row) return NextResponse.json({ error: "渠道不存在" }, { status: 404 });
    return NextResponse.json({ data: row });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "更新渠道失败" }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    await db.delete(channels).where(eq(channels.id, Number(id)));
    return NextResponse.json({ success: true });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "删除渠道失败" }, { status: 500 });
  }
}
