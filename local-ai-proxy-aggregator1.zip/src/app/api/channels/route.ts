import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { channels } from "@/db/schema";
import { desc, ilike, or, eq, and } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q")?.trim() || "";
    const type = searchParams.get("type") || "";
    const enabled = searchParams.get("enabled") || "";

    const conditions = [];
    if (q) conditions.push(or(ilike(channels.name, `%${q}%`), ilike(channels.baseUrl, `%${q}%`)));
    if (type) conditions.push(eq(channels.type, type));
    if (enabled === "true") conditions.push(eq(channels.enabled, true));
    if (enabled === "false") conditions.push(eq(channels.enabled, false));

    const rows = await db
      .select()
      .from(channels)
      .where(conditions.length ? and(...conditions) : undefined)
      .orderBy(desc(channels.priority), desc(channels.weight), desc(channels.id));

    return NextResponse.json({ data: rows });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "获取渠道失败" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, type = "openai", baseUrl = "", apiKey = "", models = [], group = "default", weight = 10, priority = 0, enabled = true, remarks = "", config = {} } = body;
    if (!name?.trim()) return NextResponse.json({ error: "渠道名称必填" }, { status: 400 });
    const modelsArr = Array.isArray(models) ? models : typeof models === "string" ? models.split(",").map((s: string) => s.trim()).filter(Boolean) : [];
    const [row] = await db.insert(channels).values({
      name: name.trim(),
      type,
      baseUrl: baseUrl.trim(),
      apiKey,
      models: modelsArr,
      group: group || "default",
      weight: Number(weight) || 10,
      priority: Number(priority) || 0,
      enabled: !!enabled,
      remarks,
      config,
      status: "unknown",
    }).returning();
    return NextResponse.json({ data: row });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "创建渠道失败" }, { status: 500 });
  }
}
