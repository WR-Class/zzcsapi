import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { requestLogs } from "@/db/schema";
import { desc, eq, and, ilike, gte, lte, sql } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const page = Math.max(1, Number(searchParams.get("page")) || 1);
    const pageSize = Math.min(100, Math.max(5, Number(searchParams.get("pageSize")) || 20));
    const model = searchParams.get("model") || "";
    const success = searchParams.get("success") || "";
    const q = searchParams.get("q")?.trim() || "";
    const channelId = searchParams.get("channelId") || "";
    const tokenId = searchParams.get("tokenId") || "";

    const conditions = [];
    if (model) conditions.push(eq(requestLogs.model, model));
    if (success === "true") conditions.push(eq(requestLogs.success, true));
    if (success === "false") conditions.push(eq(requestLogs.success, false));
    if (channelId) conditions.push(eq(requestLogs.channelId, Number(channelId)));
    if (tokenId) conditions.push(eq(requestLogs.tokenId, Number(tokenId)));
    if (q) conditions.push(ilike(requestLogs.model, `%${q}%`));

    const where = conditions.length ? and(...conditions) : undefined;
    const [{ count }] = await db.select({ count: sql<number>`count(*)::int` }).from(requestLogs).where(where);
    const rows = await db.select().from(requestLogs).where(where).orderBy(desc(requestLogs.id)).limit(pageSize).offset((page - 1) * pageSize);
    return NextResponse.json({ data: rows, total: count, page, pageSize });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "获取日志失败" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const days = searchParams.get("days");
    if (days) {
      const before = new Date(Date.now() - Number(days) * 24 * 3600 * 1000);
      await db.delete(requestLogs).where(lte(requestLogs.createdAt, before));
    } else {
      await db.delete(requestLogs).where(gte(requestLogs.id, 0));
    }
    return NextResponse.json({ success: true });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "清空日志失败" }, { status: 500 });
  }
}
