import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { channels, models, requestLogs, settings, subscriptions, tokens } from "@/db/schema";
import { sql } from "drizzle-orm";
import { seedChannels, seedModels, seedSettings, seedSubscriptions, seedTokens } from "@/lib/seed-data";

function rand(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const force = body.force === true;
    const { searchParams } = new URL(req.url);
    const forceQ = searchParams.get("force") === "true";

    const [{ count: chCount }] = await db.select({ count: sql<number>`count(*)::int` }).from(channels);
    if (chCount > 0 && !force && !forceQ) {
      return NextResponse.json({ data: { seeded: false, message: "已有数据,无需重复填充 (force=true 可强制)" } });
    }
    if (force || forceQ) {
      await db.delete(requestLogs);
      await db.delete(tokens);
      await db.delete(subscriptions);
      await db.delete(models);
      await db.delete(channels);
      await db.delete(settings);
    }

    const now = new Date();
    const insertedChannels = await db.insert(channels).values(seedChannels.map((c) => ({
      ...c,
      lastCheckAt: new Date(now.getTime() - rand(5, 120) * 60000),
      createdAt: new Date(now.getTime() - rand(10, 60) * 24 * 3600 * 1000),
      updatedAt: new Date(),
    }))).returning();

    await db.insert(subscriptions).values(seedSubscriptions.map((s) => ({
      ...s,
      expiresAt: new Date(now.getTime() + rand(10, 29) * 24 * 3600 * 1000),
      renewsAt: new Date(now.getTime() + rand(5, 28) * 24 * 3600 * 1000),
      lastRefreshAt: new Date(now.getTime() - rand(1, 72) * 3600 * 1000),
      lastUsedAt: new Date(now.getTime() - rand(10, 600) * 60000),
      createdAt: new Date(now.getTime() - rand(10, 50) * 24 * 3600 * 1000),
      updatedAt: new Date(),
    })));

    await db.insert(tokens).values(seedTokens.map((t, i) => ({
      ...t,
      lastUsedAt: new Date(now.getTime() - rand(5, 500) * 60000),
      expiresAt: i === 3 ? new Date(now.getTime() + 7 * 24 * 3600 * 1000) : null,
      createdAt: new Date(now.getTime() - rand(5, 40) * 24 * 3600 * 1000),
      updatedAt: new Date(),
    })));

    await db.insert(models).values(seedModels.map((m) => ({
      ...m,
      totalCalls: rand(50, 3000),
      createdAt: new Date(now.getTime() - rand(5, 40) * 24 * 3600 * 1000),
      updatedAt: new Date(),
    })));

    await db.insert(settings).values(seedSettings);

    // 生成过去7天 ~220 条日志
    const tokenNames = seedTokens.map((t, i) => ({ id: i + 1, name: t.name }));
    const modelIds = seedModels.map((m) => m.modelId);
    const logs = [];
    for (let d = 6; d >= 0; d--) {
      const perDay = d === 0 ? rand(35, 55) : rand(18, 42);
      for (let i = 0; i < perDay; i++) {
        const ch = pick(insertedChannels);
        const tk = pick(tokenNames);
        const model = pick(modelIds);
        const prompt = rand(80, 3200);
        const completion = rand(50, 1800);
        const total = prompt + completion;
        const price = seedModels.find((m) => m.modelId === model);
        const cost = price ? (prompt / 1000) * (price.inputPrice / 1000) * 100 + (completion / 1000) * (price.outputPrice / 1000) * 100 : 0;
        const success = Math.random() > (ch.status === "error" ? 0.35 : 0.05);
        const created = new Date(now.getTime() - d * 24 * 3600 * 1000 - rand(0, 20) * 3600 * 1000 - rand(0, 59) * 60000);
        logs.push({
          tokenId: tk.id,
          tokenName: tk.name,
          channelId: ch.id,
          channelName: ch.name,
          model,
          type: "chat",
          promptTokens: prompt,
          completionTokens: completion,
          totalTokens: total,
          cost: success ? Number((cost / 100).toFixed(5)) : 0,
          latencyMs: success ? rand(280, 3200) : rand(3000, 9000),
          success,
          statusCode: success ? 200 : pick([429, 500, 502, 503]),
          ip: pick(["127.0.0.1", "192.168.1.101", "192.168.1.102", "127.0.0.1"]),
          error: success ? "" : pick([" upstream timeout", "429 rate limited, 已自动重试", "502 bad gateway", "model overloaded"]),
          createdAt: created > now ? now : created,
        });
      }
    }
    // 批量插入
    for (let i = 0; i < logs.length; i += 50) {
      await db.insert(requestLogs).values(logs.slice(i, i + 50));
    }

    return NextResponse.json({ data: { seeded: true, channels: insertedChannels.length, logs: logs.length } });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "填充数据失败: " + (e instanceof Error ? e.message : "") }, { status: 500 });
  }
}

export async function GET() {
  const [{ count }] = await db.select({ count: sql<number>`count(*)::int` }).from(channels);
  return NextResponse.json({ data: { hasData: count > 0, channels: count } });
}
