import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { settings } from "@/db/schema";

export async function GET() {
  try {
    const rows = await db.select().from(settings);
    const obj: Record<string, string> = {};
    for (const r of rows) obj[r.key] = r.value;
    return NextResponse.json({ data: obj });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "获取设置失败" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const entries: Array<[string, string]> = Array.isArray(body)
      ? body
      : Object.entries(body as Record<string, string>);
    for (const [k, v] of entries) {
      await db.insert(settings).values({ key: k, value: String(v ?? "") })
        .onConflictDoUpdate({ target: settings.key, set: { value: String(v ?? ""), updatedAt: new Date() } });
    }
    return NextResponse.json({ success: true });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "保存设置失败" }, { status: 500 });
  }
}
