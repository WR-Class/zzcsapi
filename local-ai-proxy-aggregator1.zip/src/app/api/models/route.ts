import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { models } from "@/db/schema";
import { asc, ilike, eq, and } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q")?.trim() || "";
    const provider = searchParams.get("provider") || "";
    const conditions = [];
    if (q) conditions.push(ilike(models.modelId, `%${q}%`));
    if (provider) conditions.push(eq(models.provider, provider));
    const rows = await db.select().from(models).where(conditions.length ? and(...conditions) : undefined).orderBy(asc(models.provider), asc(models.modelId));
    return NextResponse.json({ data: rows });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "获取模型失败" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const b = await req.json();
    if (!b.modelId?.trim()) return NextResponse.json({ error: "模型 ID 必填" }, { status: 400 });
    const [row] = await db.insert(models).values({
      modelId: b.modelId.trim(),
      displayName: b.displayName?.trim() || b.modelId.trim(),
      provider: b.provider || "openai",
      inputPrice: Number(b.inputPrice) || 0,
      outputPrice: Number(b.outputPrice) || 0,
      enabled: b.enabled !== false,
      channelIds: Array.isArray(b.channelIds) ? b.channelIds.map(Number) : [],
      capabilities: Array.isArray(b.capabilities) ? b.capabilities : [],
      maxTokens: Number(b.maxTokens) || 0,
      remarks: b.remarks || "",
    }).returning();
    return NextResponse.json({ data: row });
  } catch (e: unknown) {
    console.error(e);
    const msg = e instanceof Error && e.message.includes("unique") ? "模型 ID 已存在" : "创建模型失败";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
