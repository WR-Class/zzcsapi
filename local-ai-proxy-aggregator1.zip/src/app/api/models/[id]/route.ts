import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { models } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const b = await req.json();
    const patch: Record<string, unknown> = { updatedAt: new Date() };
    for (const f of ["modelId", "displayName", "provider", "inputPrice", "outputPrice", "enabled", "channelIds", "capabilities", "maxTokens", "remarks", "totalCalls"]) {
      if (b[f] !== undefined) patch[f] = b[f];
    }
    const [row] = await db.update(models).set(patch).where(eq(models.id, Number(id))).returning();
    if (!row) return NextResponse.json({ error: "模型不存在" }, { status: 404 });
    return NextResponse.json({ data: row });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "更新模型失败" }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    await db.delete(models).where(eq(models.id, Number(id)));
    return NextResponse.json({ success: true });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "删除模型失败" }, { status: 500 });
  }
}
