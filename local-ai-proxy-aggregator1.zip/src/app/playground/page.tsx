"use client";
import { useEffect, useState } from "react";
import { Send, FlaskConical, Loader2, RotateCcw, Zap } from "lucide-react";
import { Badge, Btn, Card, PageHeader, Select, Textarea } from "@/components/ui";
import { cn } from "@/lib/utils";

type Msg = { role: "user" | "assistant" | "system"; content: string };

export default function PlaygroundPage() {
  const [tokens, setTokens] = useState<Array<{ id: number; name: string; key: string }>>([]);
  const [models, setModels] = useState<Array<{ modelId: string; displayName: string }>>([]);
  const [tokenKey, setTokenKey] = useState("");
  const [model, setModel] = useState("");
  const [system, setSystem] = useState("你是一个有帮助的 AI 助手。");
  const [input, setInput] = useState("用一句话介绍一下你自己,并说明你是通过本地聚合网关调用的。");
  const [messages, setMessages] = useState<Msg[]>([]);
  const [loading, setLoading] = useState(false);
  const [stream, setStream] = useState(true);
  const [meta, setMeta] = useState<{ channel?: string; mocked?: boolean; latency?: number; usage?: { prompt_tokens: number; completion_tokens: number; total_tokens: number } } | null>(null);

  useEffect(() => {
    Promise.all([
      fetch("/api/tokens").then((r) => r.json()),
      fetch("/api/models").then((r) => r.json()),
    ]).then(([t, m]) => {
      setTokens(t.data || []);
      setModels((m.data || []).filter((x: { enabled: boolean }) => x.enabled));
      if (t.data?.[0]) setTokenKey(t.data[0].key);
      if (m.data?.[0]) setModel(m.data.find((x: { modelId: string }) => x.modelId === "deepseek-chat")?.modelId || m.data[0].modelId);
    });
  }, []);

  const send = async () => {
    if (!input.trim() || !tokenKey || !model || loading) return;
    const userMsg: Msg = { role: "user", content: input.trim() };
    const history = [...messages, userMsg];
    setMessages(history);
    setInput("");
    setLoading(true);
    setMeta(null);
    const started = Date.now();

    try {
      const payload = {
        model,
        messages: [{ role: "system", content: system }, ...history],
        stream,
        temperature: 0.7,
      };
      const res = await fetch("/api/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${tokenKey}` },
        body: JSON.stringify(payload),
      });

      if (stream && res.ok && res.headers.get("content-type")?.includes("text/event-stream")) {
        const reader = res.body!.getReader();
        const decoder = new TextDecoder();
        let acc = "";
        setMessages([...history, { role: "assistant", content: "" }]);
        let buffer = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() || "";
          for (const line of lines) {
            const t = line.trim();
            if (!t.startsWith("data:")) continue;
            const data = t.slice(5).trim();
            if (data === "[DONE]") continue;
            try {
              const json = JSON.parse(data);
              const delta = json.choices?.[0]?.delta?.content || "";
              if (delta) {
                acc += delta;
                setMessages([...history, { role: "assistant", content: acc }]);
              }
            } catch { /* ignore */ }
          }
        }
        setMeta({ latency: Date.now() - started });
      } else {
        const data = await res.json();
        if (!res.ok) {
          setMessages([...history, { role: "assistant", content: `❌ 调用失败: ${data.error?.message || res.statusText}` }]);
        } else {
          const content = data.choices?.[0]?.message?.content || "(空回复)";
          setMessages([...history, { role: "assistant", content }]);
          setMeta({ channel: data._gateway?.channel, mocked: data._gateway?.mocked, latency: Date.now() - started, usage: data.usage });
        }
      }
    } catch (e) {
      setMessages([...history, { role: "assistant", content: `❌ 请求异常: ${e instanceof Error ? e.message : ""}` }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="animate-fade-up">
      <PageHeader
        title="调试 Playground"
        desc="直接走本地网关 /api/v1/chat/completions 发起真实调用,验证渠道路由、令牌鉴权与流式输出"
        actions={<Btn variant="ghost" onClick={() => { setMessages([]); setMeta(null); }}><RotateCcw className="h-4 w-4" />清空对话</Btn>}
      />

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="space-y-4">
          <div>
            <p className="mb-1.5 text-xs font-medium text-t3">分发令牌</p>
            <Select value={tokenKey} onChange={(e) => setTokenKey(e.target.value)} className="w-full">
              {tokens.map((t) => <option key={t.id} value={t.key}>{t.name}</option>)}
            </Select>
          </div>
          <div>
            <p className="mb-1.5 text-xs font-medium text-t3">模型</p>
            <Select value={model} onChange={(e) => setModel(e.target.value)} className="w-full">
              {models.map((m) => <option key={m.modelId} value={m.modelId}>{m.modelId}</option>)}
            </Select>
          </div>
          <div>
            <p className="mb-1.5 text-xs font-medium text-t3">System Prompt</p>
            <Textarea rows={3} value={system} onChange={(e) => setSystem(e.target.value)} />
          </div>
          <label className="flex items-center gap-2 text-sm text-t2">
            <input type="checkbox" checked={stream} onChange={(e) => setStream(e.target.checked)} className="h-4 w-4 accent-indigo-500" />
            流式输出 (SSE)
          </label>
          {meta && (
            <div className="space-y-1.5 rounded-xl border border-line bg-inset p-3 text-xs">
              <p className="font-semibold text-slate-200">本次调用</p>
              {meta.channel && <p className="text-slate-400">命中渠道: <span className="text-slate-200">{meta.channel}</span></p>}
              {meta.mocked && <p><Badge tone="amber">模拟回复 · 渠道为演示 Key</Badge></p>}
              {meta.latency && <p className="text-slate-400">耗时: <span className="text-slate-200">{meta.latency}ms</span></p>}
              {meta.usage && <p className="text-slate-400">Tokens: <span className="font-mono text-slate-200">{meta.usage.total_tokens}</span> ({meta.usage.prompt_tokens}+{meta.usage.completion_tokens})</p>}
            </div>
          )}
          <div className="rounded-xl border border-indigo-500/25 bg-indigo-500/5 p-3 text-[11px] leading-relaxed text-t3">
            <p className="flex items-center gap-1 font-semibold text-accent"><Zap className="h-3.5 w-3.5" />工作原理</p>
            <p className="mt-1">网关按「优先级 → 权重」选择支持该模型的启用渠道,失败自动转移到下一个渠道,全程记录日志与花费。</p>
          </div>
        </Card>

        <Card className="flex min-h-[560px] flex-col lg:col-span-2">
          <div className="flex items-center gap-2 border-b border-line pb-3">
            <FlaskConical className="h-4 w-4 text-accent" />
            <p className="text-sm font-bold text-t1">对话调试</p>
            <span className="ml-auto font-mono text-[11px] text-t4">{model || "-"}</span>
          </div>

          <div className="flex-1 space-y-3 overflow-y-auto py-4" style={{ maxHeight: 480 }}>
            {messages.length === 0 && (
              <div className="flex h-full flex-col items-center justify-center py-16 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-500/10 text-accent"><FlaskConical className="h-6 w-6" /></div>
                <p className="mt-3 text-sm font-semibold text-t2">在下方输入消息开始调试</p>
                <p className="mt-1 max-w-sm text-xs text-t4">演示 Key 渠道会返回模拟回复并记录日志;填入真实上游 Key 后即可透传真实模型。</p>
              </div>
            )}
            {messages.map((m, i) => (
              <div key={i} className={cn("flex", m.role === "user" ? "justify-end" : "justify-start")}>
                <div className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${m.role === "user" ? "bg-indigo-500 text-white" : "border border-line bg-surface2 text-t1"}`}>
                  {m.content}
                  {loading && stream && i === messages.length - 1 && m.role === "assistant" && <span className="animate-pulse-soft text-accent">▍</span>}
                </div>
              </div>
            ))}
            {loading && !stream && (
              <div className="flex justify-start">
                <div className="flex items-center gap-2 rounded-2xl border border-line bg-surface2 px-4 py-2.5 text-sm text-t3">
                  <Loader2 className="h-4 w-4 animate-spin" />正在请求上游...
                </div>
              </div>
            )}
          </div>

          <div className="flex gap-2 border-t border-line pt-3">
            <Textarea rows={2} value={input} onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
              placeholder="输入消息,Enter 发送 / Shift+Enter 换行..." className="resize-none" />
            <Btn onClick={send} disabled={loading || !input.trim()} className="shrink-0 self-end px-4 py-2.5">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}发送
            </Btn>
          </div>
        </Card>
      </div>
    </div>
  );
}
