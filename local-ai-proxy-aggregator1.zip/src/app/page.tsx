"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import {
  Activity, Coins, Cpu, KeyRound, Plug2, RefreshCw, Zap, Database,
  ArrowRight, CheckCircle2, XCircle, Clock,
} from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer,
  BarChart, Bar, PieChart, Pie, Cell,
} from "recharts";
import { Badge, Btn, Card, PageHeader, Skeleton, StatCard, Toast } from "@/components/ui";
import { channelTypeMeta, formatCost, formatLatency, formatNumber, timeAgo } from "@/lib/utils";

type DashboardData = {
  totals: { totalRequests: number; totalTokens: number; totalCost: number; successRate: number; avgLatency: number };
  today: { requests: number; tokens: number; cost: number };
  channels: { total: number; enabled: number; ok: number };
  tokens: { total: number; enabled: number };
  subs: { total: number; active: number };
  modelCount: number;
  daily: Array<{ date: string; requests: number; tokens: number; cost: number; success: number; failed: number }>;
  hourly: Array<{ hour: string; requests: number }>;
  modelDist: Array<{ model: string; count: number; tokens: number; cost: number }>;
  channelList: Array<{ id: number; name: string; type: string; status: string; enabled: boolean; latencyMs: number; successRate: number; totalRequests: number }>;
  recent: Array<{ id: number; model: string; channelName: string; tokenName: string; totalTokens: number; cost: number; latencyMs: number; success: boolean; createdAt: string }>;
};

const COLORS = ["#6366f1", "#22d3ee", "#f472b6", "#a3e635", "#fbbf24", "#fb7185", "#34d399", "#a78bfa"];

const tooltipStyle = {
  background: "var(--c-surface-solid)",
  border: "1px solid var(--c-line)",
  borderRadius: 12,
  fontSize: 12,
  color: "var(--c-t1)",
} as const;

export default function DashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [seeding, setSeeding] = useState(false);
  const [hasData, setHasData] = useState(true);
  const [toast, setToast] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const seedCheck = await fetch("/api/seed").then((r) => r.json());
      setHasData(seedCheck.data?.hasData);
      const res = await fetch("/api/dashboard").then((r) => r.json());
      if (res.data) setData(res.data);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const seed = async () => {
    setSeeding(true);
    try {
      await fetch("/api/seed", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ force: false }) });
      await load();
      setToast("演示数据已载入");
      setTimeout(() => setToast(""), 2500);
    } finally {
      setSeeding(false);
    }
  };

  if (loading) {
    return (
      <div>
        <PageHeader title="总览仪表盘" desc="本地聚合网关运行状态一览" />
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-32" />)}
        </div>
        <div className="mt-4 grid gap-4 lg:grid-cols-3">
          <Skeleton className="h-72 lg:col-span-2" />
          <Skeleton className="h-72" />
        </div>
      </div>
    );
  }

  if (!hasData || (data && data.totals.totalRequests === 0 && data.channels.total === 0)) {
    return (
      <div>
        <PageHeader title="总览仪表盘" desc="本地聚合网关运行状态一览" />
        <div className="glass animate-fade-up rounded-3xl p-10 text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-3xl bg-gradient-to-br from-indigo-500 to-fuchsia-500 shadow-[0_12px_40px_rgba(99,102,241,.4)]">
            <Database className="h-8 w-8 text-white" />
          </div>
          <h2 className="mt-5 text-2xl font-bold text-t1">欢迎使用 LocalHub</h2>
          <p className="mx-auto mt-2 max-w-md text-sm text-t3">
            检测到是首次启动,数据库还是空的。可以一键载入演示数据(8 条渠道、6 个订阅、4 个令牌、12 个模型与 7 天调用日志),立即体验完整功能。
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <Btn onClick={seed} disabled={seeding}><Database className="h-4 w-4" />{seeding ? "正在载入演示数据..." : "一键载入演示数据"}</Btn>
            <Link href="/channels"><Btn variant="ghost">手动添加渠道 <ArrowRight className="h-4 w-4" /></Btn></Link>
          </div>
          <p className="mt-4 text-[11px] text-t4">本地单用户模式 · 无需登录注册 · 所有数据保存在本地 PostgreSQL · 支持深浅色主题切换</p>
        </div>
      </div>
    );
  }

  const t = data!.totals;
  return (
    <div className="animate-fade-up">
      <PageHeader
        title="总览仪表盘"
        desc={`今日 ${data!.today.requests} 次调用 · ${formatNumber(data!.today.tokens)} tokens · 花费 ${formatCost(data!.today.cost)}`}
        actions={
          <>
            <Btn variant="ghost" onClick={load}><RefreshCw className="h-4 w-4" />刷新</Btn>
            <Link href="/playground"><Btn><Zap className="h-4 w-4" />去调试</Btn></Link>
          </>
        }
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="累计请求" value={formatNumber(t.totalRequests)} sub={`成功率 ${t.successRate.toFixed(1)}%`} icon={<Activity className="h-4 w-4 text-accent" />} accent="bg-indigo-500/15" />
        <StatCard label="累计 Tokens" value={formatNumber(t.totalTokens)} sub={`平均延迟 ${formatLatency(t.avgLatency)}`} icon={<Cpu className="h-4 w-4 text-cyan2" />} accent="bg-cyan-500/15" />
        <StatCard label="累计花费" value={formatCost(t.totalCost)} sub={`今日 ${formatCost(data!.today.cost)}`} icon={<Coins className="h-4 w-4 text-warn" />} accent="bg-amber-500/15" />
        <StatCard label="渠道健康" value={`${data!.channels.ok}/${data!.channels.total}`} sub={`${data!.tokens.enabled} 个令牌启用 · ${data!.subs.active} 个订阅活跃`} icon={<Plug2 className="h-4 w-4 text-ok" />} accent="bg-emerald-500/15" />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <p className="text-sm font-bold text-t1">近 7 天调用趋势</p>
              <p className="text-xs text-t4">请求量 / 成功与失败分布</p>
            </div>
            <Badge tone="blue">{data!.modelCount} 个模型接入</Badge>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data!.daily}>
                <defs>
                  <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#6366f1" stopOpacity={0.45} />
                    <stop offset="100%" stopColor="#6366f1" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="date" tick={{ fill: "var(--c-t3)", fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "var(--c-t3)", fontSize: 12 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={tooltipStyle} />
                <Area type="monotone" dataKey="requests" name="请求" stroke="#6366f1" strokeWidth={2.5} fill="url(#g1)" />
                <Area type="monotone" dataKey="failed" name="失败" stroke="#fb7185" strokeWidth={2} fill="transparent" strokeDasharray="4 4" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card>
          <p className="text-sm font-bold text-t1">模型调用分布</p>
          <p className="text-xs text-t4">Top 8 模型占比</p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={data!.modelDist} dataKey="count" nameKey="model" innerRadius={52} outerRadius={84} paddingAngle={2} strokeWidth={0}>
                  {data!.modelDist.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={tooltipStyle} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="max-h-28 space-y-1 overflow-y-auto">
            {data!.modelDist.slice(0, 5).map((m, i) => (
              <div key={m.model} className="flex items-center gap-2 text-xs">
                <span className="h-2 w-2 rounded-full" style={{ background: COLORS[i % COLORS.length] }} />
                <span className="truncate text-t2">{m.model}</span>
                <span className="ml-auto text-t4">{m.count} 次</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <div className="mb-3 flex items-center justify-between">
            <div>
              <p className="text-sm font-bold text-t1">渠道状态</p>
              <p className="text-xs text-t4">按优先级排序 · 点击名称管理</p>
            </div>
            <Link href="/channels" className="inline-flex items-center gap-1 text-xs text-accent hover:opacity-80">全部渠道 <ArrowRight className="h-3.5 w-3.5" /></Link>
          </div>
          <div className="space-y-2">
            {data!.channelList.map((c) => (
              <Link key={c.id} href="/channels" className="flex items-center gap-3 rounded-xl border border-line bg-surface2 px-3 py-2.5 transition hover:border-accent/40">
                <span className={`h-2.5 w-2.5 shrink-0 rounded-full ${!c.enabled ? "bg-t4" : c.status === "ok" ? "bg-ok" : c.status === "error" ? "bg-bad" : "bg-warn"}`} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-t1">{c.name}</p>
                  <p className="text-[11px] text-t4">{formatNumber(c.totalRequests)} 次 · 成功率 {c.successRate.toFixed(1)}% · {formatLatency(c.latencyMs)}</p>
                </div>
                <span className={`hidden rounded-full border px-2 py-0.5 text-[11px] sm:inline ${(channelTypeMeta[c.type] || channelTypeMeta.custom).color}`}>{(channelTypeMeta[c.type] || channelTypeMeta.custom).label}</span>
                {!c.enabled && <Badge tone="slate">停用</Badge>}
              </Link>
            ))}
          </div>
        </Card>

        <Card>
          <div className="mb-3 flex items-center justify-between">
            <div>
              <p className="text-sm font-bold text-t1">最近调用</p>
              <p className="text-xs text-t4">实时网关日志</p>
            </div>
            <Link href="/logs" className="inline-flex items-center gap-1 text-xs text-accent hover:opacity-80">全部日志 <ArrowRight className="h-3.5 w-3.5" /></Link>
          </div>
          <div className="space-y-2">
            {data!.recent.map((l) => (
              <div key={l.id} className="rounded-xl border border-line bg-surface2 px-3 py-2">
                <div className="flex items-center gap-2">
                  {l.success ? <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-ok" /> : <XCircle className="h-3.5 w-3.5 shrink-0 text-bad" />}
                  <p className="truncate font-mono text-xs text-t1">{l.model}</p>
                  <span className="ml-auto flex shrink-0 items-center gap-1 text-[10px] text-t4"><Clock className="h-3 w-3" />{timeAgo(l.createdAt)}</span>
                </div>
                <p className="mt-1 truncate text-[11px] text-t4">{l.channelName} · {formatNumber(l.totalTokens)} tok · {formatCost(l.cost)} · {formatLatency(l.latencyMs)}</p>
              </div>
            ))}
            {data!.recent.length === 0 && <p className="py-8 text-center text-xs text-t4">暂无调用记录</p>}
          </div>
        </Card>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <p className="text-sm font-bold text-t1">今日 24 小时分布</p>
          <p className="mb-2 text-xs text-t4">按小时统计请求量</p>
          <div className="h-40">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data!.hourly}>
                <XAxis dataKey="hour" tick={{ fill: "var(--c-t3)", fontSize: 10 }} axisLine={false} tickLine={false} interval={2} />
                <Tooltip contentStyle={tooltipStyle} />
                <Bar dataKey="requests" name="请求" fill="#22d3ee" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card className="flex flex-col justify-between bg-gradient-to-br from-indigo-600/15 to-fuchsia-600/10">
          <div>
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-500/20"><KeyRound className="h-5 w-5 text-accent" /></div>
            <p className="mt-3 text-sm font-bold text-t1">本地分发已就绪</p>
            <p className="mt-1 text-xs leading-relaxed text-t3">使用分发令牌即可通过 OpenAI 兼容接口调用所有聚合渠道,支持 Cherry Studio、NextChat、Claude Code 等客户端。</p>
          </div>
          <div className="mt-4 flex gap-2">
            <Link href="/tokens" className="flex-1"><Btn className="w-full justify-center">管理令牌</Btn></Link>
            <Link href="/docs" className="flex-1"><Btn variant="ghost" className="w-full justify-center">接入文档</Btn></Link>
          </div>
        </Card>
      </div>

      <Toast msg={toast} />
    </div>
  );
}
