"use client";
import { Fragment, useCallback, useEffect, useState } from "react";
import { Search, Trash2, RefreshCw, ChevronLeft, ChevronRight, CheckCircle2, XCircle } from "lucide-react";
import { Badge, Btn, EmptyState, Input, PageHeader, Select, TableSkeleton, Toast } from "@/components/ui";
import { formatCost, formatDate, formatLatency, formatNumber } from "@/lib/utils";

type Log = {
  id: number; tokenName: string; channelName: string; model: string; type: string;
  promptTokens: number; completionTokens: number; totalTokens: number; cost: number;
  latencyMs: number; success: boolean; statusCode: number; ip: string; error: string; createdAt: string;
};

export default function LogsPage() {
  const [list, setList] = useState<Log[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(20);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [success, setSuccess] = useState("");
  const [toast, setToast] = useState("");
  const [expanded, setExpanded] = useState<number | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), pageSize: String(pageSize) });
      if (q) params.set("q", q);
      if (success) params.set("success", success);
      const res = await fetch(`/api/logs?${params}`).then((r) => r.json());
      setList(res.data || []);
      setTotal(res.total || 0);
    } finally {
      setLoading(false);
    }
  }, [page, pageSize, q, success]);

  useEffect(() => {
    const t = setTimeout(load, 300);
    return () => clearTimeout(t);
  }, [load]);

  useEffect(() => { setPage(1); }, [q, success]);

  const showToast = (m: string) => { setToast(m); setTimeout(() => setToast(""), 2500); };

  const clearOld = async () => {
    if (!confirm("确定清空 30 天前的历史日志吗?")) return;
    await fetch("/api/logs?days=30", { method: "DELETE" });
    showToast("已清理 30 天前日志");
    load();
  };

  const clearAll = async () => {
    if (!confirm("确定清空全部调用日志吗?此操作不可恢复。")) return;
    await fetch("/api/logs", { method: "DELETE" });
    showToast("全部日志已清空");
    load();
  };

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="animate-fade-up">
      <PageHeader
        title="调用日志"
        desc={`共 ${formatNumber(total)} 条记录 · 每次网关调用都会记录模型、渠道、Token 与花费`}
        actions={
          <>
            <Btn variant="ghost" onClick={load}><RefreshCw className="h-4 w-4" />刷新</Btn>
            <Btn variant="ghost" onClick={clearOld}><Trash2 className="h-4 w-4" />清理30天前</Btn>
            <Btn variant="danger" onClick={clearAll}>清空全部</Btn>
          </>
        }
      />

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <div className="relative min-w-52 flex-1 sm:max-w-xs">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-t4" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="搜索模型..." className="pl-9" />
        </div>
        <Select value={success} onChange={(e) => setSuccess(e.target.value)}>
          <option value="">全部状态</option>
          <option value="true">仅成功</option>
          <option value="false">仅失败</option>
        </Select>
      </div>

      {loading ? <TableSkeleton rows={8} /> : list.length === 0 ? (
        <EmptyState title="暂无调用日志" desc="通过网关发起调用后,这里会记录每一次请求的详细信息。去 Playground 发起一次测试调用吧。" />
      ) : (
        <>
          <div className="overflow-x-auto rounded-2xl border border-line">
            <table className="w-full min-w-[900px] text-left text-sm">
              <thead>
                <tr className="border-b border-line bg-surface2 text-xs text-t3">
                  <th className="px-4 py-3 font-medium">状态</th>
                  <th className="px-4 py-3 font-medium">模型</th>
                  <th className="px-4 py-3 font-medium">渠道 / 令牌</th>
                  <th className="px-4 py-3 font-medium">Tokens</th>
                  <th className="px-4 py-3 font-medium">花费</th>
                  <th className="px-4 py-3 font-medium">延迟</th>
                  <th className="px-4 py-3 font-medium">时间</th>
                </tr>
              </thead>
              <tbody>
                {list.map((l) => (
                  <Fragment key={l.id}>
                    <tr onClick={() => setExpanded(expanded === l.id ? null : l.id)}
                      className="cursor-pointer border-b border-line transition hover:bg-surface2">
                      <td className="px-4 py-3">
                        {l.success ? (
                          <span className="inline-flex items-center gap-1 text-xs text-ok"><CheckCircle2 className="h-4 w-4" />{l.statusCode}</span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-xs text-bad"><XCircle className="h-4 w-4" />{l.statusCode}</span>
                        )}
                      </td>
                      <td className="px-4 py-3 font-mono text-xs text-t1">{l.model}</td>
                      <td className="px-4 py-3">
                        <p className="text-xs text-t2">{l.channelName}</p>
                        <p className="text-[11px] text-t4">{l.tokenName}</p>
                      </td>
                      <td className="px-4 py-3 text-xs text-t2">
                        {formatNumber(l.totalTokens)}
                        <span className="ml-1 text-[10px] text-t4">({formatNumber(l.promptTokens)}+{formatNumber(l.completionTokens)})</span>
                      </td>
                      <td className="px-4 py-3 font-mono text-xs text-t2">{formatCost(l.cost)}</td>
                      <td className="px-4 py-3 text-xs text-t3">{formatLatency(l.latencyMs)}</td>
                      <td className="px-4 py-3 text-[11px] text-t4">{formatDate(l.createdAt)}</td>
                    </tr>
                    {expanded === l.id && (
                      <tr className="border-b border-line bg-surface2">
                        <td colSpan={7} className="px-4 py-3">
                          <div className="grid gap-2 text-xs sm:grid-cols-3">
                            <div><span className="text-t4">ID:</span> <span className="text-t2">#{l.id}</span></div>
                            <div><span className="text-t4">类型:</span> <Badge tone="slate">{l.type}</Badge></div>
                            <div><span className="text-t4">来源 IP:</span> <span className="font-mono text-t2">{l.ip}</span></div>
                            {l.error && <div className="sm:col-span-3"><span className="text-t4">错误:</span> <code className="text-bad">{l.error}</code></div>}
                          </div>
                        </td>
                      </tr>
                    )}
                  </Fragment>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-4 flex items-center justify-between text-sm text-t3">
            <p>第 {page} / {totalPages} 页 · 共 {formatNumber(total)} 条</p>
            <div className="flex gap-2">
              <Btn variant="ghost" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page <= 1}><ChevronLeft className="h-4 w-4" />上一页</Btn>
              <Btn variant="ghost" onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page >= totalPages}>下一页<ChevronRight className="h-4 w-4" /></Btn>
            </div>
          </div>
        </>
      )}

      <Toast msg={toast} />
    </div>
  );
}
