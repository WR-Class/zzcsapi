import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import Sidebar from "@/components/Sidebar";

export const metadata: Metadata = {
  title: "LocalHub · 本地AI聚合分发",
  description: "本地单用户 AI 聚合分发控制台:渠道/中转站聚合、订阅账号聚合、令牌分发、OpenAI 兼容网关。参考 CLIProxyAPI / sub2api / NewAPI。",
};

const themeInit = `(function(){try{if(localStorage.getItem("lh-theme")==="light"){document.documentElement.classList.remove("dark");}else{document.documentElement.classList.add("dark");}}catch(e){document.documentElement.classList.add("dark");}})();`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="zh-CN" className="dark">
      <body className="min-h-screen antialiased">
        <script dangerouslySetInnerHTML={{ __html: themeInit }} />
        <div className="pointer-events-none fixed inset-0 -z-10">
          <div className="absolute -top-40 left-1/4 h-96 w-96 rounded-full bg-indigo-500/20 blur-[120px] dark:bg-indigo-600/15" />
          <div className="absolute right-0 top-1/3 h-80 w-80 rounded-full bg-fuchsia-500/15 blur-[120px] dark:bg-fuchsia-600/10" />
          <div className="absolute bottom-0 left-0 h-72 w-72 rounded-full bg-cyan-500/15 blur-[120px] dark:bg-cyan-500/10" />
        </div>
        <Sidebar />
        <main className="min-h-screen lg:pl-64">
          <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">{children}</div>
        </main>
      </body>
    </html>
  );
}
