"use client";
import { useEffect, useState } from "react";
import { Plus, Pencil, Trash2, Boxes, Search } from "lucide-react";
import { Badge, Btn, EmptyState, Field, Input, Modal, PageHeader, Select, TableSkeleton, Textarea, Toggle, Toast } from "@/components/ui";
import { cn, formatNumber } from "@/lib/utils";

type M = {
  id: number; modelId: string; displayName: string; provider: string;
  inputPrice: number; outputPrice: number; enabled: boolean; capabilities: string[];
  maxTokens: number; remarks: string; totalCalls: number;
};

const emptyForm = { modelId: "", displayName: "", provider: "openai", inputPrice: 1, outputPrice: 5, enabled: true, capabilities: [] as string[], maxTokens: 128000, remarks: "" };
const caps = ["vision", "tool", "reasoning", "image", "audio"];

export default function ModelsPage() {
  const [list, setList] = useState<M[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [provider, setProvider] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<M | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState("");

  const load = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (q) params.set("q", q);
      if (provider) params.set("provider", provider);
      const res = await fetch(`/api/models?${params}`).then((r) => r.json());
      setList(res.data || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const t = setTimeout(load, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q, provider]);

  const showToast = (m: string) => { setToast(m); setTimeout(() => setToast(""), 2500); };
  const openCreate = () => { setEditing(null); setForm(emptyForm); setModalOpen(true); };
  const openEdit = (m: M) => {
    setEditing(m);
    setForm({ modelId: m.modelId, displayName: m.displayName, provider: m.provider, inputPrice: m.inputPrice, outputPrice: m.outputPrice, enabled: m.enabled, capabilities: m.capabilities || [], maxTokens: m.maxTokens, remarks: m.remarks || "" });
    setModalOpen(true);
  };

  const save = async () => {
    if (!form.modelId.trim()) return showToast("模型 ID 必填");
    setSaving(true);
    try {
      const url = editing ? `/api/models/${editing.id}` : "/api/models";
      const res = await fetch(url, { method: editing ? "PUT" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) }).then((r) => r.json());
      if (res.error) return showToast(res.error);
      setModalOpen(false);
      showToast(editing ? "模型已更新" : "模型已添加");
      load();
    } finally {
      setSaving(false);
    }
  };

  const toggle = async (m: M) => {
    setList((p) => p.map((x) => (x.id === m.id ? { ...x, enabled: !x.enabled } : x)));
    await fetch(`/api/models/${m.id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ enabled: !m.enabled }) });
  };

  const remove = async (m: M) => {
    if (!confirm(`确定删除模型「${m.modelId}」吗?`)) return;
    setList((p) => p.filter((x) => x.id !== m.id));
    await fetch(`/api/models/${m.id}`, { method: "DELETE" });
    showToast("模型已删除");
  };

  return (
    <div className="animate-fade-up">
      <PageHeader
        title="模型与定价"
        desc={`共 ${list.length} 个模型 · 价格单位: 美元 / 1M tokens · 用于成本核算与网关 /v1/models 列表`}
        actions={<Btn onClick={openCreate}><Plus className="h-4 w-4" />添加模型</Btn>}
      />

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <div className="relative min-w-52 flex-1 sm:max-w-xs">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-t4" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="搜索模型 ID..." className="pl-9" />
        </div>
        <Select value={provider} onChange={(e) => setProvider(e.target.value)}>
          <option value="">全部厂商</option>
          <option value="openai">OpenAI</option>
          <option value="anthropic">Anthropic</option>
          <option value="gemini">Gemini</option>
          <option value="deepseek">DeepSeek</option>
          <option value="qwen">Qwen</option>
          <option value="moonshot">Moonshot</option>
        </Select>
      </div>

      {loading ? <TableSkeleton rows={6} /> : list.length === 0 ? (
        <EmptyState title="还没有模型" desc="录入模型 ID 与定价,网关会按此核算成本并在 /v1/models 中暴露。" action={<Btn onClick={openCreate}><Plus className="h-4 w-4" />添加第一个模型</Btn>} />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-line">
          <table className="w-full min-w-[760px] text-left text-sm">
            <thead>
              <tr className="border-b border-line bg-surface2 text-xs text-t3">
                <th className="px-4 py-3 font-medium">模型</th>
                <th className="px-4 py-3 font-medium">厂商</th>
                <th className="px-4 py-3 font-medium">输入 $/1M</th>
                <th className="px-4 py-3 font-medium">输出 $/1M</th>
                <th className="px-4 py-3 font-medium">能力</th>
                <th className="px-4 py-3 font-medium">调用</th>
                <th className="px-4 py-3 font-medium">状态</th>
                <th className="px-4 py-3 text-right font-medium">操作</th>
              </tr>
            </thead>
            <tbody>
              {list.map((m) => (
                <tr key={m.id} className={cn("border-b border-line transition hover:bg-surface2", !m.enabled && "opacity-55")}>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2.5">
                      <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-cyan-500/15 text-cyan2"><Boxes className="h-4 w-4" /></div>
                      <div>
                        <p className="font-mono text-[13px] font-semibold text-t1">{m.modelId}</p>
                        <p className="text-[11px] text-t4">{m.displayName}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3"><Badge tone="blue">{m.provider}</Badge></td>
                  <td className="px-4 py-3 font-mono text-xs text-t2">${m.inputPrice}</td>
                  <td className="px-4 py-3 font-mono text-xs text-t2">${m.outputPrice}</td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap gap-1">
                      {(m.capabilities || []).map((c) => <span key={c} className="rounded-md bg-surface2 px-1.5 py-0.5 text-[10px] text-t3">{c}</span>)}
                      {(!m.capabilities || m.capabilities.length === 0) && <span className="text-[11px] text-t4">-</span>}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-xs text-t3">{formatNumber(m.totalCalls)}</td>
                  <td className="px-4 py-3"><Toggle checked={m.enabled} onChange={() => toggle(m)} /></td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-1">
                      <button onClick={() => openEdit(m)} className="rounded-lg p-2 text-t4 hover:bg-t1/10 hover:text-t1"><Pencil className="h-4 w-4" /></button>
                      <button onClick={() => remove(m)} className="rounded-lg p-2 text-t4 hover:bg-rose-500/10 hover:text-bad"><Trash2 className="h-4 w-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "编辑模型" : "添加模型"}>
        <div className="grid gap-4">
          <div className="grid grid-cols-2 gap-3">
            <Field label="模型 ID *"><Input value={form.modelId} onChange={(e) => setForm({ ...form, modelId: e.target.value })} placeholder="deepseek-chat" /></Field>
            <Field label="显示名"><Input value={form.displayName} onChange={(e) => setForm({ ...form, displayName: e.target.value })} placeholder="DeepSeek V3.2" /></Field>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <Field label="厂商">
              <Select value={form.provider} onChange={(e) => setForm({ ...form, provider: e.target.value })} className="w-full">
                <option value="openai">openai</option>
                <option value="anthropic">anthropic</option>
                <option value="gemini">gemini</option>
                <option value="deepseek">deepseek</option>
                <option value="qwen">qwen</option>
                <option value="moonshot">moonshot</option>
                <option value="local">local</option>
              </Select>
            </Field>
            <Field label="输入 $/1M"><Input type="number" step="0.01" value={form.inputPrice} onChange={(e) => setForm({ ...form, inputPrice: Number(e.target.value) })} /></Field>
            <Field label="输出 $/1M"><Input type="number" step="0.01" value={form.outputPrice} onChange={(e) => setForm({ ...form, outputPrice: Number(e.target.value) })} /></Field>
          </div>
          <Field label="能力标签">
            <div className="flex flex-wrap gap-2">
              {caps.map((c) => (
                <button key={c} type="button" onClick={() => setForm({ ...form, capabilities: form.capabilities.includes(c) ? form.capabilities.filter((x) => x !== c) : [...form.capabilities, c] })}
                  className={cn("rounded-xl border px-3 py-1.5 text-xs transition", form.capabilities.includes(c) ? "border-accent/50 bg-accent/15 text-accent" : "border-line bg-surface2 text-t3")}>
                  {c}
                </button>
              ))}
            </div>
          </Field>
          <Field label="最大 Tokens"><Input type="number" value={form.maxTokens} onChange={(e) => setForm({ ...form, maxTokens: Number(e.target.value) })} /></Field>
          <Field label="备注"><Textarea rows={2} value={form.remarks} onChange={(e) => setForm({ ...form, remarks: e.target.value })} /></Field>
          <div className="flex items-center gap-2">
            <Toggle checked={form.enabled} onChange={(v) => setForm({ ...form, enabled: v })} />
            <span className="text-sm text-t2">启用该模型</span>
          </div>
        </div>
        <div className="mt-6 flex justify-end gap-2">
          <Btn variant="ghost" onClick={() => setModalOpen(false)}>取消</Btn>
          <Btn onClick={save} disabled={saving}>{saving ? "保存中..." : editing ? "保存修改" : "添加模型"}</Btn>
        </div>
      </Modal>

      <Toast msg={toast} />
    </div>
  );
}
