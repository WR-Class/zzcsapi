"use client";
import { useState } from "react";
import { Copy, Check, BookOpen, Terminal, Braces, Bot, SunMoon } from "lucide-react";
import { Card, PageHeader } from "@/components/ui";

function CodeBlock({ title, code, lang = "bash" }: { title: string; code: string; lang?: string }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };
  return (
    <div className="overflow-hidden rounded-xl border border-white/10 bg-inset">
      <div className="flex items-center justify-between border-b border-white/10 px-4 py-2">
        <span className="text-xs font-medium text-slate-400">{title} <span className="ml-1 rounded bg-white/10 px-1.5 py-0.5 font-mono text-[10px] text-slate-300">{lang}</span></span>
        <button onClick={copy} className="flex items-center gap-1 text-xs text-slate-500 hover:text-slate-200">
          {copied ? <><Check className="h-3.5 w-3.5 text-emerald-400" />已复制</> : <><Copy className="h-3.5 w-3.5" />复制</>}
        </button>
      </div>
      <pre className="overflow-x-auto p-4 font-mono text-xs leading-relaxed text-slate-200">{code}</pre>
    </div>
  );
}

export default function DocsPage() {
  return (
    <div className="animate-fade-up">
      <PageHeader title="接入文档" desc="网关完全兼容 OpenAI API 格式,任何支持自定义 Base URL 的客户端即插即用" />

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2 space-y-4">
          <div className="flex items-center gap-2">
            <Terminal className="h-4 w-4 text-accent" />
            <p className="text-sm font-bold text-t1">1 · cURL 快速调用</p>
          </div>
          <CodeBlock title="聊天补全" code={`curl http://127.0.0.1:3000/api/v1/chat/completions \\
  -H "Content-Type: application/json" \\
  -H "Authorization: Bearer sk-local-你的令牌" \\
  -d '{
    "model": "deepseek-chat",
    "messages": [{"role": "user", "content": "你好,介绍一下你自己"}],
    "stream": false
  }'`} />
          <CodeBlock title="模型列表" code={`curl http://127.0.0.1:3000/api/v1/models \\
  -H "Authorization: Bearer sk-local-你的令牌"`} />

          <div className="flex items-center gap-2 pt-2">
            <Braces className="h-4 w-4 text-cyan2" />
            <p className="text-sm font-bold text-t1">2 · Python (OpenAI SDK)</p>
          </div>
          <CodeBlock title="python" lang="python" code={`from openai import OpenAI

client = OpenAI(
    base_url="http://127.0.0.1:3000/api/v1",
    api_key="sk-local-你的令牌",  # 在「分发令牌」页创建
)

resp = client.chat.completions.create(
    model="deepseek-chat",
    messages=[{"role": "user", "content": "写一首关于本地 AI 网关的短诗"}],
)
print(resp.choices[0].message.content)`} />

          <div className="flex items-center gap-2 pt-2">
            <Bot className="h-4 w-4 text-ok" />
            <p className="text-sm font-bold text-t1">3 · Claude Code / 终端工具接入</p>
          </div>
          <CodeBlock title="环境变量" code={`# 将 Anthropic / OpenAI 请求指向本地网关
export ANTHROPIC_BASE_URL="http://127.0.0.1:3000/api/v1"
export ANTHROPIC_API_KEY="sk-local-ClaudeCode专用令牌"

# OpenAI 生态
export OPENAI_BASE_URL="http://127.0.0.1:3000/api/v1"
export OPENAI_API_KEY="sk-local-你的令牌"`} />
        </Card>

        <div className="space-y-4">
          <Card>
            <div className="flex items-center gap-2">
              <BookOpen className="h-4 w-4 text-warn" />
              <p className="text-sm font-bold text-t1">客户端配置速查</p>
            </div>
            <div className="mt-3 space-y-3 text-xs leading-relaxed text-t3">
              <div className="rounded-xl border border-line bg-surface2 p-3">
                <p className="font-semibold text-t1">Cherry Studio / NextChat</p>
                <p className="mt-1">服务商选 OpenAI,接口地址填 <code className="text-accent">http://127.0.0.1:3000/api/v1</code>,Key 填分发令牌。</p>
              </div>
              <div className="rounded-xl border border-line bg-surface2 p-3">
                <p className="font-semibold text-t1">Claude Code Router</p>
                <p className="mt-1">将 Router 的上游指向本网关,模型名保持 <code className="text-accent">claude-sonnet-4-5</code> 等即可自动路由到 OAuth 聚合渠道。</p>
              </div>
              <div className="rounded-xl border border-line bg-surface2 p-3">
                <p className="font-semibold text-t1">Continue / Cline (VSCode)</p>
                <p className="mt-1">Provider 选 OpenAI Compatible,Base URL 同上,按需选择 deepseek / qwen 等本地映射模型。</p>
              </div>
            </div>
          </Card>

          <Card>
            <p className="text-sm font-bold text-t1">路由与故障转移</p>
            <ol className="mt-2 list-decimal space-y-1.5 pl-5 text-xs leading-relaxed text-t3">
              <li>按模型筛选启用渠道(渠道 models 为空视为支持全部)。</li>
              <li>按 <span className="text-t1">优先级 ↓ → 权重 ↓</span> 排序,依次尝试。</li>
              <li>单个渠道失败自动转移到下一个,全部失败才返回 502。</li>
              <li>每次调用记录日志:Token、渠道、用量、花费、延迟。</li>
              <li>演示 Key 渠道在开启模拟时返回 Mock 结果,便于联调。</li>
            </ol>
          </Card>

          <Card>
            <div className="flex items-center gap-2">
              <SunMoon className="h-4 w-4 text-accent" />
              <p className="text-sm font-bold text-t1">界面主题</p>
            </div>
            <p className="mt-2 text-xs leading-relaxed text-t3">
              控制台支持深色 / 浅色双主题,点击侧边栏顶部的太阳 / 月亮按钮即可切换,选择会自动记住(localStorage),刷新不丢失。
            </p>
          </Card>

          <Card className="border-emerald-500/25 bg-emerald-500/5">
            <p className="text-sm font-bold text-ok">本地安全提示</p>
            <p className="mt-1 text-xs leading-relaxed text-t3">
              本服务默认仅监听本机,所有 Key 与 Token 只存本地 PostgreSQL。如需局域网共享,请通过反向代理加鉴权后再暴露端口。
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
