"use client";
import { useEffect, useState } from "react";
import { Plus, Pencil, Trash2, Copy, Check, KeyRound, RefreshCw, Eye, EyeOff, Search } from "lucide-react";
import { Badge, Btn, EmptyState, Field, Input, Modal, PageHeader, TableSkeleton, Textarea, Toggle, Toast } from "@/components/ui";
import { cn, formatDate, maskKey, timeAgo } from "@/lib/utils";

type Token = {
  id: number; name: string; key: string; quota: number; usedQuota: number;
  modelsAllowed: string[]; group: string; enabled: boolean; expiresAt: string | null;
  lastUsedAt: string | null; requestCount: number; remarks: string; createdAt: string;
};

export default function TokensPage() {
  const [list, setList] = useState<Token[]>([]);
  const [models, setModels] = useState<Array<{ modelId: string }>>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Token | null>(null);
  const [form, setForm] = useState({ name: "", key: "", unlimited: true, quota: 1000000, modelsAllowed: [] as string[], group: "default", enabled: true, expiresAt: "", remarks: "" });
  const [saving, setSaving] = useState(false);
  const [visible, setVisible] = useState<Record<number, boolean>>({});
  const [copied, setCopied] = useState("");
  const [toast, setToast] = useState("");

  const load = async () => {
    setLoading(true);
    try {
      const [t, m] = await Promise.all([
        fetch(`/api/tokens${q ? `?q=${encodeURIComponent(q)}` : ""}`).then((r) => r.json()),
        fetch("/api/models").then((r) => r.json()),
      ]);
      setList(t.data || []);
      setModels(m.data || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const t = setTimeout(load, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  const showToast = (m: string) => { setToast(m); setTimeout(() => setToast(""), 2500); };
  const openCreate = () => {
    setEditing(null);
    setForm({ name: "", key: "", unlimited: true, quota: 1000000, modelsAllowed: [], group: "default", enabled: true, expiresAt: "", remarks: "" });
    setModalOpen(true);
  };
  const openEdit = (t: Token) => {
    setEditing(t);
    setForm({ name: t.name, key: t.key, unlimited: t.quota === -1, quota: t.quota === -1 ? 1000000 : t.quota, modelsAllowed: t.modelsAllowed || [], group: t.group, enabled: t.enabled, expiresAt: t.expiresAt ? new Date(t.expiresAt).toISOString().slice(0, 10) : "", remarks: t.remarks || "" });
    setModalOpen(true);
  };

  const save = async () => {
    if (!form.name.trim()) return showToast("令牌名称必填");
    setSaving(true);
    try {
      const payload = { name: form.name, key: form.key || undefined, unlimited: form.unlimited, quota: form.quota, modelsAllowed: form.modelsAllowed, group: form.group, enabled: form.enabled, expiresAt: form.expiresAt || null, remarks: form.remarks };
      const url = editing ? `/api/tokens/${editing.id}` : "/api/tokens";
      const res = await fetch(url, { method: editing ? "PUT" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) }).then((r) => r.json());
      if (res.error) return showToast(res.error);
      setModalOpen(false);
      showToast(editing ? "令牌已更新" : "令牌已创建");
      load();
    } finally {
      setSaving(false);
    }
  };

  const toggle = async (t: Token) => {
    setList((p) => p.map((x) => (x.id === t.id ? { ...x, enabled: !x.enabled } : x)));
    await fetch(`/api/tokens/${t.id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ enabled: !t.enabled }) });
  };

  const regenerate = async (t: Token) => {
    if (!confirm(`确定重新生成「${t.name}」的密钥吗?旧密钥将立即失效。`)) return;
    const res = await fetch(`/api/tokens/${t.id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ regenerate: true }) }).then((r) => r.json());
    if (res.data) {
      setList((p) => p.map((x) => (x.id === t.id ? res.data : x)));
      showToast("密钥已重新生成");
    }
  };

  const resetUsed = async (t: Token) => {
    await fetch(`/api/tokens/${t.id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ resetUsed: true }) });
    showToast("已用额度已清零");
    load();
  };

  const remove = async (t: Token) => {
    if (!confirm(`确定删除令牌「${t.name}」吗?使用该密钥的客户端将无法调用。`)) return;
    setList((p) => p.filter((x) => x.id !== t.id));
    await fetch(`/api/tokens/${t.id}`, { method: "DELETE" });
    showToast("令牌已删除");
  };

  const copy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(""), 1500);
  };

  return (
    <div className="animate-fade-up">
      <PageHeader
        title="分发令牌"
        desc="参考 NewAPI 令牌体系:为下游客户端(Cherry Studio / NextChat / Claude Code)签发本地 sk-local-* 密钥"
        actions={<Btn onClick={openCreate}><Plus className="h-4 w-4" />创建令牌</Btn>}
      />

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <div className="relative min-w-52 flex-1 sm:max-w-xs">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-t4" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="搜索令牌名称..." className="pl-9" />
        </div>
      </div>

      {loading ? <TableSkeleton rows={5} /> : list.length === 0 ? (
        <EmptyState title="还没有分发令牌" desc="创建本地 API 密钥,下游应用通过 Authorization: Bearer sk-local-... 调用统一网关。" action={<Btn onClick={openCreate}><Plus className="h-4 w-4" />创建第一个令牌</Btn>} />
      ) : (
        <div className="grid gap-3 xl:grid-cols-2">
          {list.map((t) => {
            const pct = t.quota === -1 ? 0 : Math.min(100, (t.usedQuota / Math.max(t.quota, 1)) * 100);
            return (
              <div key={t.id} className={cn("glass card-hover rounded-2xl p-4", !t.enabled && "opacity-60")}>
                <div className="flex items-start gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-500/15 text-warn">
                    <KeyRound className="h-5 w-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-sm font-bold text-t1">{t.name}</p>
                      {t.enabled ? <Badge tone="green">启用中</Badge> : <Badge tone="slate">已停用</Badge>}
                      {t.quota === -1 ? <Badge tone="blue">无限额度</Badge> : pct > 90 ? <Badge tone="red">额度告罄</Badge> : null}
                    </div>
                    <div className="mt-2 flex items-center gap-2 rounded-xl border border-white/10 bg-inset px-3 py-2">
                      <code className="min-w-0 flex-1 truncate font-mono text-xs text-indigo-300">{visible[t.id] ? t.key : maskKey(t.key, 6)}</code>
                      <button onClick={() => setVisible({ ...visible, [t.id]: !visible[t.id] })} className="text-slate-400 hover:text-slate-100">
                        {visible[t.id] ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                      <button onClick={() => copy(t.key, `k-${t.id}`)} className="text-slate-400 hover:text-slate-100">
                        {copied === `k-${t.id}` ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
                      </button>
                    </div>
                    <div className="mt-2">
                      {t.quota === -1 ? (
                        <p className="text-[11px] text-t4">已用 {t.usedQuota.toLocaleString()} 点 · {t.requestCount.toLocaleString()} 次调用 · 上次使用 {timeAgo(t.lastUsedAt)}</p>
                      ) : (
                        <>
                          <div className="flex justify-between text-[11px] text-t4">
                            <span>已用 {t.usedQuota.toLocaleString()} / {t.quota.toLocaleString()} 点</span>
                            <span>{pct.toFixed(1)}%</span>
                          </div>
                          <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-t1/10">
                            <div className={cn("h-full rounded-full", pct > 90 ? "bg-rose-400" : pct > 70 ? "bg-amber-400" : "bg-indigo-400")} style={{ width: `${pct}%` }} />
                          </div>
                        </>
                      )}
                    </div>
                    <div className="mt-1.5 flex flex-wrap items-center gap-1">
                      {t.modelsAllowed?.length ? t.modelsAllowed.slice(0, 4).map((m) => <code key={m} className="rounded-md bg-surface2 px-1.5 py-0.5 font-mono text-[10px] text-t2">{m}</code>) : <span className="text-[11px] text-t4">可访问全部模型</span>}
                      {t.modelsAllowed?.length > 4 && <span className="text-[10px] text-t4">+{t.modelsAllowed.length - 4}</span>}
                    </div>
                    <p className="mt-1.5 text-[11px] text-t4">分组 {t.group} · {t.requestCount.toLocaleString()} 次调用 · 到期 {t.expiresAt ? formatDate(t.expiresAt) : "永不过期"}</p>
                  </div>
                  <Toggle checked={t.enabled} onChange={() => toggle(t)} />
                </div>
                <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-line pt-3">
                  <Btn variant="ghost" onClick={() => openEdit(t)}><Pencil className="h-3.5 w-3.5" />编辑</Btn>
                  <Btn variant="ghost" onClick={() => regenerate(t)}><RefreshCw className="h-3.5 w-3.5" />重新生成</Btn>
                  {t.quota !== -1 && <Btn variant="ghost" onClick={() => resetUsed(t)}>清零已用</Btn>}
                  <button onClick={() => remove(t)} className="ml-auto inline-flex items-center gap-1 rounded-xl px-2.5 py-2 text-xs text-t4 transition hover:bg-rose-500/10 hover:text-bad">
                    <Trash2 className="h-3.5 w-3.5" />删除
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "编辑令牌" : "创建分发令牌"}>
        <div className="grid gap-4">
          <Field label="令牌名称 *"><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="如: Cherry Studio 专用" /></Field>
          <Field label="自定义密钥 (留空自动生成)" hint="建议使用 sk-local- 前缀"><Input value={form.key} onChange={(e) => setForm({ ...form, key: e.target.value })} placeholder="sk-local-..." /></Field>
          <div className="flex items-center gap-2">
            <Toggle checked={form.unlimited} onChange={(v) => setForm({ ...form, unlimited: v })} />
            <span className="text-sm text-t2">无限额度</span>
          </div>
          {!form.unlimited && (
            <Field label="总额度 (点数)"><Input type="number" value={form.quota} onChange={(e) => setForm({ ...form, quota: Number(e.target.value) })} /></Field>
          )}
          <div className="grid grid-cols-2 gap-3">
            <Field label="分组"><Input value={form.group} onChange={(e) => setForm({ ...form, group: e.target.value })} placeholder="default" /></Field>
            <Field label="到期时间 (留空=永久)"><Input type="date" value={form.expiresAt} onChange={(e) => setForm({ ...form, expiresAt: e.target.value })} /></Field>
          </div>
          <Field label="允许模型 (不选=全部)" hint="按住 Ctrl/⌘ 多选">
            <select multiple value={form.modelsAllowed} onChange={(e) => setForm({ ...form, modelsAllowed: Array.from(e.target.selectedOptions).map((o) => o.value) })}
              className="max-h-32 w-full rounded-xl border border-line bg-surface2 px-3 py-2 text-sm text-t1 outline-none focus:border-accent/60 [&>option]:bg-surface-solid">
              {models.map((m) => <option key={m.modelId} value={m.modelId}>{m.modelId}</option>)}
            </select>
          </Field>
          <Field label="备注"><Textarea rows={2} value={form.remarks} onChange={(e) => setForm({ ...form, remarks: e.target.value })} placeholder="用途说明..." /></Field>
          <div className="flex items-center gap-2">
            <Toggle checked={form.enabled} onChange={(v) => setForm({ ...form, enabled: v })} />
            <span className="text-sm text-t2">启用该令牌</span>
          </div>
        </div>
        <div className="mt-6 flex justify-end gap-2">
          <Btn variant="ghost" onClick={() => setModalOpen(false)}>取消</Btn>
          <Btn onClick={save} disabled={saving}>{saving ? "保存中..." : editing ? "保存修改" : "创建令牌"}</Btn>
        </div>
      </Modal>

      <Toast msg={toast} />
    </div>
  );
}
