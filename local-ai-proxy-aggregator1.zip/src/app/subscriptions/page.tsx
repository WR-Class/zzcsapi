"use client";
import { useEffect, useState } from "react";
import { Plus, Pencil, Trash2, RefreshCw, CreditCard, Search } from "lucide-react";
import { Badge, Btn, EmptyState, Field, Input, Modal, PageHeader, Select, TableSkeleton, Textarea, Toggle, Toast } from "@/components/ui";
import { cn, formatDate, providerMeta, timeAgo } from "@/lib/utils";

type Sub = {
  id: number; name: string; provider: string; email: string; authType: string;
  accessToken: string; refreshToken: string; expiresAt: string | null;
  quotaTotal: number; quotaUsed: number; status: string; enabled: boolean;
  lastRefreshAt: string | null; lastUsedAt: string | null; plan: string; renewsAt: string | null; remarks: string;
};

const emptyForm = { name: "", provider: "claude-pro", email: "", authType: "oauth", accessToken: "", refreshToken: "", quotaTotal: 1000000, quotaUsed: 0, status: "active", enabled: true, plan: "Pro", remarks: "" };

const statusTone: Record<string, "green" | "red" | "amber" | "slate"> = { active: "green", expired: "red", exhausted: "amber", error: "red", refresh_needed: "amber" };
const statusLabel: Record<string, string> = { active: "正常", expired: "已过期", exhausted: "额度用尽", error: "异常", refresh_needed: "待刷新" };

export default function SubscriptionsPage() {
  const [list, setList] = useState<Sub[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Sub | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [refreshing, setRefreshing] = useState<number | null>(null);
  const [toast, setToast] = useState("");

  const load = async (query = q) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/subscriptions${query ? `?q=${encodeURIComponent(query)}` : ""}`).then((r) => r.json());
      setList(res.data || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const t = setTimeout(() => load(), 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  const showToast = (m: string) => { setToast(m); setTimeout(() => setToast(""), 2500); };
  const openCreate = () => { setEditing(null); setForm(emptyForm); setModalOpen(true); };
  const openEdit = (s: Sub) => {
    setEditing(s);
    setForm({ name: s.name, provider: s.provider, email: s.email, authType: s.authType, accessToken: s.accessToken, refreshToken: s.refreshToken, quotaTotal: s.quotaTotal, quotaUsed: s.quotaUsed, status: s.status, enabled: s.enabled, plan: s.plan, remarks: s.remarks || "" });
    setModalOpen(true);
  };

  const save = async () => {
    if (!form.name.trim()) return showToast("订阅名称必填");
    setSaving(true);
    try {
      const url = editing ? `/api/subscriptions/${editing.id}` : "/api/subscriptions";
      const res = await fetch(url, { method: editing ? "PUT" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) }).then((r) => r.json());
      if (res.error) return showToast(res.error);
      setModalOpen(false);
      showToast(editing ? "订阅已更新" : "订阅已添加");
      load();
    } finally {
      setSaving(false);
    }
  };

  const toggle = async (s: Sub) => {
    setList((p) => p.map((x) => (x.id === s.id ? { ...x, enabled: !x.enabled } : x)));
    await fetch(`/api/subscriptions/${s.id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ enabled: !s.enabled }) });
  };

  const refresh = async (s: Sub) => {
    setRefreshing(s.id);
    try {
      await fetch(`/api/subscriptions/${s.id}/refresh`, { method: "POST" });
      showToast(`「${s.name}」Token 已刷新`);
      load();
    } finally {
      setRefreshing(null);
    }
  };

  const remove = async (s: Sub) => {
    if (!confirm(`确定删除订阅「${s.name}」吗?`)) return;
    setList((p) => p.filter((x) => x.id !== s.id));
    await fetch(`/api/subscriptions/${s.id}`, { method: "DELETE" });
    showToast("订阅已删除");
  };

  return (
    <div className="animate-fade-up">
      <PageHeader
        title="订阅账号聚合"
        desc="参考 CLIProxyAPI / sub2api:聚合 Claude Pro、ChatGPT Plus、Gemini CLI 等 OAuth 订阅,统一轮询分发"
        actions={<Btn onClick={openCreate}><Plus className="h-4 w-4" />添加订阅</Btn>}
      />

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <div className="relative min-w-52 flex-1 sm:max-w-xs">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-t4" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="搜索订阅 / 邮箱..." className="pl-9" />
        </div>
        <div className="flex gap-2 text-xs text-t3">
          <Badge tone="green">{list.filter((s) => s.status === "active").length} 正常</Badge>
          <Badge tone="amber">{list.filter((s) => s.status !== "active").length} 需关注</Badge>
        </div>
      </div>

      {loading ? <TableSkeleton rows={5} /> : list.length === 0 ? (
        <EmptyState title="还没有订阅账号" desc="把你的 Claude / GPT / Gemini 订阅 OAuth Token 录入进来,网关会自动轮询、刷新与故障转移。" action={<Btn onClick={openCreate}><Plus className="h-4 w-4" />添加第一个订阅</Btn>} />
      ) : (
        <div className="grid gap-3 xl:grid-cols-2">
          {list.map((s) => {
            const pct = s.quotaTotal > 0 ? Math.min(100, (s.quotaUsed / s.quotaTotal) * 100) : 0;
            return (
              <div key={s.id} className={cn("glass card-hover rounded-2xl p-4", !s.enabled && "opacity-60")}>
                <div className="flex items-start gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-violet-500/15 text-accent">
                    <CreditCard className="h-5 w-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-sm font-bold text-t1">{s.name}</p>
                      <span className={cn("rounded-full border px-2 py-0.5 text-[11px]", (providerMeta[s.provider] || providerMeta.other).color)}>{(providerMeta[s.provider] || providerMeta.other).label}</span>
                      <Badge tone={statusTone[s.status] || "slate"}>{statusLabel[s.status] || s.status}</Badge>
                      {!s.enabled && <Badge tone="slate">停用</Badge>}
                    </div>
                    <p className="mt-1 truncate text-[11px] text-t4">{s.email || "未绑定邮箱"} · {s.plan} · {s.authType.toUpperCase()} · 到期 {formatDate(s.expiresAt)} · 上次刷新 {timeAgo(s.lastRefreshAt)}</p>
                    <div className="mt-2">
                      <div className="flex justify-between text-[11px] text-t4">
                        <span>额度使用 {s.quotaUsed.toLocaleString()} / {s.quotaTotal > 0 ? s.quotaTotal.toLocaleString() : "∞"}</span>
                        <span>{pct.toFixed(1)}%</span>
                      </div>
                      <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-t1/10">
                        <div className={cn("h-full rounded-full transition-all", pct > 90 ? "bg-rose-400" : pct > 70 ? "bg-amber-400" : "bg-emerald-400")} style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                    {s.remarks && <p className="mt-1.5 truncate text-[11px] text-t4">📝 {s.remarks}</p>}
                  </div>
                  <Toggle checked={s.enabled} onChange={() => toggle(s)} />
                </div>
                <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-line pt-3">
                  <Btn variant="ghost" onClick={() => refresh(s)} disabled={refreshing === s.id}>
                    <RefreshCw className={cn("h-3.5 w-3.5", refreshing === s.id && "animate-spin")} />{refreshing === s.id ? "刷新中..." : "刷新 Token"}
                  </Btn>
                  <Btn variant="ghost" onClick={() => openEdit(s)}><Pencil className="h-3.5 w-3.5" />编辑</Btn>
                  <button onClick={() => remove(s)} className="ml-auto inline-flex items-center gap-1 rounded-xl px-2.5 py-2 text-xs text-t4 transition hover:bg-rose-500/10 hover:text-bad">
                    <Trash2 className="h-3.5 w-3.5" />删除
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "编辑订阅" : "添加订阅账号"} wide>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="订阅名称 *"><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="如: Claude Pro 主号" /></Field>
          <Field label="订阅平台">
            <Select value={form.provider} onChange={(e) => setForm({ ...form, provider: e.target.value })} className="w-full">
              {Object.entries(providerMeta).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </Select>
          </Field>
          <Field label="账号邮箱"><Input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="account@example.com" /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="认证方式">
              <Select value={form.authType} onChange={(e) => setForm({ ...form, authType: e.target.value })} className="w-full">
                <option value="oauth">OAuth</option>
                <option value="apikey">API Key</option>
                <option value="cookie">Cookie</option>
                <option value="token">Token</option>
              </Select>
            </Field>
            <Field label="套餐"><Input value={form.plan} onChange={(e) => setForm({ ...form, plan: e.target.value })} placeholder="Pro" /></Field>
          </div>
          <Field label="Access Token"><Input value={form.accessToken} onChange={(e) => setForm({ ...form, accessToken: e.target.value })} placeholder="oauth access token" type="password" /></Field>
          <Field label="Refresh Token"><Input value={form.refreshToken} onChange={(e) => setForm({ ...form, refreshToken: e.target.value })} placeholder="oauth refresh token" type="password" /></Field>
          <Field label="总额度"><Input type="number" value={form.quotaTotal} onChange={(e) => setForm({ ...form, quotaTotal: Number(e.target.value) })} /></Field>
          <Field label="已用额度"><Input type="number" value={form.quotaUsed} onChange={(e) => setForm({ ...form, quotaUsed: Number(e.target.value) })} /></Field>
          <div className="sm:col-span-2">
            <Field label="备注"><Textarea rows={2} value={form.remarks} onChange={(e) => setForm({ ...form, remarks: e.target.value })} placeholder="轮询策略、重置周期等..." /></Field>
          </div>
          <div className="flex items-center gap-2 sm:col-span-2">
            <Toggle checked={form.enabled} onChange={(v) => setForm({ ...form, enabled: v })} />
            <span className="text-sm text-t2">启用该订阅</span>
          </div>
        </div>
        <div className="mt-6 flex justify-end gap-2">
          <Btn variant="ghost" onClick={() => setModalOpen(false)}>取消</Btn>
          <Btn onClick={save} disabled={saving}>{saving ? "保存中..." : editing ? "保存修改" : "添加订阅"}</Btn>
        </div>
      </Modal>

      <Toast msg={toast} />
    </div>
  );
}
