"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Plus, Search, Plug2, Trash2, Pencil, FlaskConical, Copy, Check, Power } from "lucide-react";
import { Badge, Btn, EmptyState, Field, Input, Modal, PageHeader, Select, TableSkeleton, Textarea, Toggle, Toast } from "@/components/ui";
import { channelTypeMeta, cn, formatLatency, formatNumber, maskKey, timeAgo } from "@/lib/utils";

type Channel = {
  id: number; name: string; type: string; baseUrl: string; apiKey: string; models: string[];
  group: string; weight: number; priority: number; enabled: boolean; status: string;
  latencyMs: number; successRate: number; totalRequests: number; totalTokens: number;
  lastCheckAt: string | null; lastError: string; remarks: string; createdAt: string;
};

const emptyForm = { name: "", type: "openai", baseUrl: "", apiKey: "", models: "", group: "default", weight: 10, priority: 0, enabled: true, remarks: "" };

export default function ChannelsPage() {
  const [list, setList] = useState<Channel[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Channel | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [testingId, setTestingId] = useState<number | null>(null);
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const [copied, setCopied] = useState("");
  const [toast, setToast] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (q) params.set("q", q);
      if (typeFilter) params.set("type", typeFilter);
      const res = await fetch(`/api/channels?${params}`).then((r) => r.json());
      setList(res.data || []);
    } finally {
      setLoading(false);
    }
  }, [q, typeFilter]);

  useEffect(() => {
    const t = setTimeout(load, 300);
    return () => clearTimeout(t);
  }, [load]);

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(""), 2500); };

  const openCreate = () => { setEditing(null); setForm(emptyForm); setModalOpen(true); };
  const openEdit = (c: Channel) => {
    setEditing(c);
    setForm({ name: c.name, type: c.type, baseUrl: c.baseUrl, apiKey: c.apiKey, models: c.models.join(", "), group: c.group, weight: c.weight, priority: c.priority, enabled: c.enabled, remarks: c.remarks || "" });
    setModalOpen(true);
  };

  const save = async () => {
    if (!form.name.trim()) return showToast("渠道名称必填");
    setSaving(true);
    try {
      const payload = { ...form, models: form.models.split(",").map((s) => s.trim()).filter(Boolean) };
      const url = editing ? `/api/channels/${editing.id}` : "/api/channels";
      const res = await fetch(url, { method: editing ? "PUT" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) }).then((r) => r.json());
      if (res.error) return showToast(res.error);
      setModalOpen(false);
      showToast(editing ? "渠道已更新" : "渠道已创建");
      load();
    } finally {
      setSaving(false);
    }
  };

  const toggle = async (c: Channel) => {
    setList((prev) => prev.map((x) => (x.id === c.id ? { ...x, enabled: !x.enabled } : x)));
    const res = await fetch(`/api/channels/${c.id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ enabled: !c.enabled }) }).then((r) => r.json());
    if (res.error) { showToast(res.error); load(); }
  };

  const test = async (c: Channel) => {
    setTestingId(c.id);
    try {
      const res = await fetch(`/api/channels/${c.id}/test`, { method: "POST" }).then((r) => r.json());
      showToast(res.data?.ok ? `连接正常 · ${res.data.latencyMs}ms` : `连接失败: ${res.data?.message || "未知"}`);
      load();
    } finally {
      setTestingId(null);
    }
  };

  const remove = async (c: Channel) => {
    if (!confirm(`确定删除渠道「${c.name}」吗?`)) return;
    setDeletingId(c.id);
    setList((prev) => prev.filter((x) => x.id !== c.id));
    await fetch(`/api/channels/${c.id}`, { method: "DELETE" });
    setDeletingId(null);
    showToast("渠道已删除");
  };

  const copy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    setTimeout(() => setCopied(""), 1500);
  };

  const enabledList = useMemo(() => list.filter((c) => c.enabled), [list]);
  const disabledList = useMemo(() => list.filter((c) => !c.enabled), [list]);
  const stats = useMemo(() => ({
    total: list.length,
    ok: enabledList.filter((c) => c.status === "ok").length,
    req: list.reduce((a, c) => a + c.totalRequests, 0),
  }), [list, enabledList]);

  const renderCard = (c: Channel) => (
    <div key={c.id} className="glass card-hover rounded-2xl p-4">
      <div className="flex items-start gap-3">
        <div className={cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-xl", !c.enabled ? "bg-slate-500/15 text-t3" : c.status === "ok" ? "bg-emerald-500/15 text-ok" : c.status === "error" ? "bg-rose-500/15 text-bad" : "bg-amber-500/15 text-warn")}>
          <Plug2 className="h-5 w-5" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <p className="truncate text-sm font-bold text-t1">{c.name}</p>
            <span className={cn("rounded-full border px-2 py-0.5 text-[11px]", (channelTypeMeta[c.type] || channelTypeMeta.custom).color)}>{(channelTypeMeta[c.type] || channelTypeMeta.custom).label}</span>
            {!c.enabled ? <Badge tone="slate">已停用</Badge> : c.status === "ok" ? <Badge tone="green">健康</Badge> : c.status === "error" ? <Badge tone="red">异常</Badge> : <Badge tone="amber">未检测</Badge>}
          </div>
          <p className="mt-1 truncate font-mono text-[11px] text-t4">{c.baseUrl || "未配置地址"} · {maskKey(c.apiKey)}</p>
          <div className="mt-2 flex flex-wrap gap-1">
            {c.models.slice(0, 5).map((m) => <code key={m} className="rounded-md bg-surface2 px-1.5 py-0.5 font-mono text-[10px] text-t2">{m}</code>)}
            {c.models.length > 5 && <code className="rounded-md bg-surface2 px-1.5 py-0.5 text-[10px] text-t4">+{c.models.length - 5}</code>}
            {c.models.length === 0 && <span className="text-[11px] text-t4">支持全部模型(自动路由)</span>}
          </div>
          <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-t4">
            <span>优先级 {c.priority} · 权重 {c.weight} · 分组 {c.group}</span>
            <span>{formatNumber(c.totalRequests)} 次 · {formatLatency(c.latencyMs)} · 成功率 {c.successRate.toFixed(1)}%</span>
            <span>检测于 {timeAgo(c.lastCheckAt)}</span>
          </div>
          {c.lastError && <p className="mt-1 truncate text-[11px] text-bad">⚠ {c.lastError}</p>}
        </div>
        <Toggle checked={c.enabled} onChange={() => toggle(c)} />
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-line pt-3">
        <Btn variant="ghost" onClick={() => test(c)} disabled={testingId === c.id || !c.enabled}>
          <FlaskConical className="h-3.5 w-3.5" />{testingId === c.id ? "检测中..." : "连通性测试"}
        </Btn>
        <Btn variant="ghost" onClick={() => openEdit(c)}><Pencil className="h-3.5 w-3.5" />编辑</Btn>
        <Btn variant="ghost" onClick={() => copy(c.baseUrl, `base-${c.id}`)}>{copied === `base-${c.id}` ? <Check className="h-3.5 w-3.5 text-ok" /> : <Copy className="h-3.5 w-3.5" />}复制地址</Btn>
        <button onClick={() => remove(c)} disabled={deletingId === c.id} className="ml-auto inline-flex items-center gap-1 rounded-xl px-2.5 py-2 text-xs text-t4 transition hover:bg-rose-500/10 hover:text-bad">
          <Trash2 className="h-3.5 w-3.5" />删除
        </button>
      </div>
    </div>
  );

  const sectionEmpty = (text: string) => (
    <p className="rounded-xl border border-dashed border-line bg-surface2/50 px-4 py-8 text-center text-xs text-t4">{text}</p>
  );

  return (
    <div className="animate-fade-up">
      <PageHeader
        title="渠道 / 中转站聚合"
        desc={`共 ${stats.total} 个渠道 · 启用 ${enabledList.length}(健康 ${stats.ok}) · 停用 ${disabledList.length} · 累计 ${formatNumber(stats.req)} 次调用`}
        actions={<Btn onClick={openCreate}><Plus className="h-4 w-4" />添加渠道</Btn>}
      />

      <div className="mb-5 flex flex-wrap items-center gap-2">
        <div className="relative min-w-52 flex-1 sm:max-w-xs">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-t4" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="搜索渠道名称 / 地址..." className="pl-9" />
        </div>
        <Select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)}>
          <option value="">全部类型</option>
          {Object.entries(channelTypeMeta).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </Select>
      </div>

      {loading ? (
        <TableSkeleton rows={6} />
      ) : list.length === 0 ? (
        <EmptyState title="还没有渠道" desc="添加上游渠道(官方 API / 中转站 / 本地 CLIProxyAPI 聚合)后,即可通过统一网关分发调用。" action={<Btn onClick={openCreate}><Plus className="h-4 w-4" />添加第一个渠道</Btn>} />
      ) : (
        <div className="space-y-8">
          {/* ===== 启用中的渠道 ===== */}
          <section>
            <div className="mb-3 flex items-center gap-2.5">
              <span className="dot-live h-2 w-2 rounded-full bg-ok text-ok" />
              <h2 className="text-sm font-bold text-t1">启用中的渠道</h2>
              <span className="rounded-full bg-emerald-500/15 px-2 py-0.5 text-[11px] font-medium text-ok">{enabledList.length}</span>
              <span className="text-xs text-t4">参与网关路由与故障转移</span>
            </div>
            {enabledList.length > 0 ? (
              <div className="grid gap-3 xl:grid-cols-2">{enabledList.map(renderCard)}</div>
            ) : (
              sectionEmpty("当前没有启用中的渠道 — 在下方「已停用的渠道」中打开开关即可恢复参与路由")
            )}
          </section>

          {/* ===== 已停用的渠道 ===== */}
          <section>
            <div className="mb-3 flex items-center gap-2.5">
              <span className="h-2 w-2 rounded-full bg-t4" />
              <h2 className="text-sm font-bold text-t1">已停用的渠道</h2>
              <span className="rounded-full bg-surface2 px-2 py-0.5 text-[11px] font-medium text-t3">{disabledList.length}</span>
              <span className="text-xs text-t4">不参与路由,配置保留</span>
            </div>
            {disabledList.length > 0 ? (
              <div className="grid gap-3 xl:grid-cols-2">{disabledList.map(renderCard)}</div>
            ) : (
              sectionEmpty("没有已停用的渠道,全部渠道均在线")
            )}
          </section>
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "编辑渠道" : "添加渠道"} wide>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="渠道名称 *"><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="如:DeepSeek 官方 / 中转站A" /></Field>
          <Field label="渠道类型">
            <Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value, baseUrl: form.baseUrl || channelTypeMeta[e.target.value]?.placeholder || "" })} className="w-full">
              {Object.entries(channelTypeMeta).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </Select>
          </Field>
          <Field label="上游地址 (Base URL)" hint="OpenAI 兼容格式,以 /v1 结尾">
            <Input value={form.baseUrl} onChange={(e) => setForm({ ...form, baseUrl: e.target.value })} placeholder={channelTypeMeta[form.type]?.placeholder} />
          </Field>
          <Field label="API Key / Token" hint="本地保存,不会外传">
            <Input value={form.apiKey} onChange={(e) => setForm({ ...form, apiKey: e.target.value })} placeholder="sk-..." type="password" />
          </Field>
          <div className="sm:col-span-2">
            <Field label="支持模型 (逗号分隔,留空=全部)" hint="如: deepseek-chat, deepseek-reasoner">
              <Input value={form.models} onChange={(e) => setForm({ ...form, models: e.target.value })} placeholder="deepseek-chat, deepseek-reasoner" />
            </Field>
          </div>
          <Field label="分组"><Input value={form.group} onChange={(e) => setForm({ ...form, group: e.target.value })} placeholder="default" /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="优先级(越大越先用)"><Input type="number" value={form.priority} onChange={(e) => setForm({ ...form, priority: Number(e.target.value) })} /></Field>
            <Field label="权重(负载均衡)"><Input type="number" value={form.weight} onChange={(e) => setForm({ ...form, weight: Number(e.target.value) })} /></Field>
          </div>
          <div className="sm:col-span-2">
            <Field label="备注"><Textarea rows={2} value={form.remarks} onChange={(e) => setForm({ ...form, remarks: e.target.value })} placeholder="用途、限速、价格等备注..." /></Field>
          </div>
          <div className="flex items-center gap-2 sm:col-span-2">
            <Toggle checked={form.enabled} onChange={(v) => setForm({ ...form, enabled: v })} />
            <span className="text-sm text-t2">启用该渠道(停用后会移入下方「已停用」分组)</span>
          </div>
        </div>
        <div className="mt-6 flex justify-end gap-2">
          <Btn variant="ghost" onClick={() => setModalOpen(false)}>取消</Btn>
          <Btn onClick={save} disabled={saving}>{saving ? "保存中..." : editing ? "保存修改" : "创建渠道"}</Btn>
        </div>
      </Modal>

      <Toast msg={toast} />
    </div>
  );
}
