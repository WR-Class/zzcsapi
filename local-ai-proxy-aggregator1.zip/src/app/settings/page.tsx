"use client";
import { useEffect, useState } from "react";
import { Save, Database, Trash2, RefreshCw } from "lucide-react";
import { Btn, Card, Field, Input, PageHeader, Toggle, Toast } from "@/components/ui";

export default function SettingsPage() {
  const [form, setForm] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState("");
  const [seeding, setSeeding] = useState(false);

  useEffect(() => {
    fetch("/api/settings").then((r) => r.json()).then((res) => {
      setForm({
        site_name: "LocalHub · 本地AI聚合分发",
        default_group: "default",
        check_interval: "300",
        retry_times: "3",
        request_timeout: "60",
        enable_mock: "true",
        log_retention_days: "30",
        port: "3000",
        ...(res.data || {}),
      });
      setLoading(false);
    });
  }, []);

  const showToast = (m: string) => { setToast(m); setTimeout(() => setToast(""), 2500); };

  const save = async () => {
    setSaving(true);
    try {
      await fetch("/api/settings", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
      showToast("设置已保存");
    } finally {
      setSaving(false);
    }
  };

  const reseed = async () => {
    if (!confirm("将清空现有数据并重新载入演示数据,确定吗?")) return;
    setSeeding(true);
    try {
      await fetch("/api/seed?force=true", { method: "POST" });
      showToast("演示数据已重置");
    } finally {
      setSeeding(false);
    }
  };

  const clearLogs = async () => {
    if (!confirm("确定清空全部日志吗?")) return;
    await fetch("/api/logs", { method: "DELETE" });
    showToast("日志已清空");
  };

  if (loading) return <div className="animate-pulse text-sm text-t3">加载设置中...</div>;

  return (
    <div className="animate-fade-up">
      <PageHeader title="系统设置" desc="本地单用户模式 · 无需登录 · 所有配置保存在本地数据库 · 右上角可切换深浅色主题" actions={<Btn onClick={save} disabled={saving}><Save className="h-4 w-4" />{saving ? "保存中..." : "保存设置"}</Btn>} />

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <p className="mb-4 text-sm font-bold text-t1">网关配置</p>
          <div className="grid gap-4">
            <Field label="站点名称"><Input value={form.site_name || ""} onChange={(e) => setForm({ ...form, site_name: e.target.value })} /></Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="默认分组"><Input value={form.default_group || ""} onChange={(e) => setForm({ ...form, default_group: e.target.value })} /></Field>
              <Field label="监听端口"><Input value={form.port || ""} onChange={(e) => setForm({ ...form, port: e.target.value })} /></Field>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <Field label="重试次数"><Input type="number" value={form.retry_times || ""} onChange={(e) => setForm({ ...form, retry_times: e.target.value })} /></Field>
              <Field label="超时(秒)"><Input type="number" value={form.request_timeout || ""} onChange={(e) => setForm({ ...form, request_timeout: e.target.value })} /></Field>
              <Field label="日志保留(天)"><Input type="number" value={form.log_retention_days || ""} onChange={(e) => setForm({ ...form, log_retention_days: e.target.value })} /></Field>
            </div>
            <Field label="渠道健康检测间隔(秒)"><Input type="number" value={form.check_interval || ""} onChange={(e) => setForm({ ...form, check_interval: e.target.value })} /></Field>
            <div className="flex items-center gap-3 rounded-xl border border-line bg-surface2 p-3">
              <Toggle checked={form.enable_mock === "true"} onChange={(v) => setForm({ ...form, enable_mock: v ? "true" : "false" })} />
              <div>
                <p className="text-sm font-medium text-t1">演示 Key 模拟回复</p>
                <p className="text-[11px] text-t4">开启后,使用 sk-demo-* 的渠道会返回模拟结果而非真实请求,方便无 Key 体验全流程</p>
              </div>
            </div>
          </div>
        </Card>

        <div className="space-y-4">
          <Card>
            <p className="mb-2 text-sm font-bold text-t1">网关接入信息</p>
            <div className="space-y-2 text-xs">
              <div className="rounded-xl border border-white/10 bg-inset p-3">
                <p className="text-slate-400">Base URL (OpenAI 兼容)</p>
                <code className="mt-1 block font-mono text-[13px] text-indigo-300">http://127.0.0.1:{form.port || 3000}/api/v1</code>
              </div>
              <div className="rounded-xl border border-white/10 bg-inset p-3">
                <p className="text-slate-400">健康检查</p>
                <code className="mt-1 block font-mono text-[13px] text-emerald-300">GET /api/health → {"{ ok: true }"}</code>
              </div>
              <div className="rounded-xl border border-white/10 bg-inset p-3">
                <p className="text-slate-400">鉴权方式</p>
                <code className="mt-1 block font-mono text-[13px] text-amber-300">Authorization: Bearer sk-local-***</code>
              </div>
            </div>
          </Card>

          <Card>
            <p className="mb-2 text-sm font-bold text-t1">数据管理</p>
            <p className="mb-3 text-xs text-t4">演示数据包含渠道、订阅、令牌、模型与 7 天日志,可随时重置。</p>
            <div className="flex flex-wrap gap-2">
              <Btn variant="outline" onClick={reseed} disabled={seeding}><Database className="h-4 w-4" />{seeding ? "重置中..." : "重置演示数据"}</Btn>
              <Btn variant="ghost" onClick={clearLogs}><Trash2 className="h-4 w-4" />清空日志</Btn>
              <Btn variant="ghost" onClick={() => window.location.reload()}><RefreshCw className="h-4 w-4" />刷新页面</Btn>
            </div>
          </Card>

          <Card className="border-indigo-500/25 bg-gradient-to-br from-indigo-600/10 to-transparent">
            <p className="text-sm font-bold text-t1">设计参考</p>
            <ul className="mt-2 space-y-1 text-xs leading-relaxed text-t3">
              <li><span className="text-t1">CLIProxyAPI</span> — CLI 订阅 OAuth 聚合、Token 自动刷新与轮询</li>
              <li><span className="text-t1">sub2api</span> — 多订阅账号统一纳管与额度池</li>
              <li><span className="text-t1">NewAPI / OneAPI</span> — 渠道管理、令牌分发、日志计费体系</li>
            </ul>
            <p className="mt-2 text-[11px] text-t4">本应用为本地单用户简化版:去登录注册、开箱即用、数据不出本机、支持深浅色主题。</p>
          </Card>
        </div>
      </div>

      <Toast msg={toast} />
    </div>
  );
}
