"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import {
  LayoutDashboard, Plug2, KeyRound, CreditCard, Boxes, ScrollText,
  FlaskConical, Settings, BookOpen, Zap, Menu, X, ShieldCheck,
} from "lucide-react";
import { cn } from "@/lib/utils";
import ThemeToggle from "./ThemeToggle";

const nav = [
  { href: "/", label: "总览仪表盘", icon: LayoutDashboard },
  { href: "/channels", label: "渠道 / 中转站", icon: Plug2 },
  { href: "/subscriptions", label: "订阅账号聚合", icon: CreditCard },
  { href: "/tokens", label: "分发令牌", icon: KeyRound },
  { href: "/models", label: "模型与定价", icon: Boxes },
  { href: "/logs", label: "调用日志", icon: ScrollText },
  { href: "/playground", label: "调试 Playground", icon: FlaskConical },
  { href: "/docs", label: "接入文档", icon: BookOpen },
  { href: "/settings", label: "系统设置", icon: Settings },
];

export default function Sidebar() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  const panel = (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2 px-1 py-1">
        <Link href="/" className="flex items-center gap-3" onClick={() => setOpen(false)}>
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-500 shadow-[0_8px_24px_rgba(99,102,241,.4)]">
            <Zap className="h-5 w-5 text-white" />
          </div>
          <div>
            <p className="text-sm font-bold leading-tight text-t1">LocalHub</p>
            <p className="text-[11px] leading-tight text-t3">本地AI聚合分发</p>
          </div>
        </Link>
        <div className="ml-auto shrink-0">
          <ThemeToggle />
        </div>
      </div>

      <div className="mt-4 flex items-center gap-2 rounded-xl border border-emerald-500/25 bg-emerald-500/10 px-3 py-2">
        <ShieldCheck className="h-4 w-4 shrink-0 text-ok" />
        <div className="min-w-0">
          <p className="truncate text-[11px] font-semibold text-ok">本地单用户模式</p>
          <p className="truncate text-[10px] text-ok/70">无需登录 · 数据存本地库</p>
        </div>
        <span className="dot-live ml-auto h-2 w-2 shrink-0 rounded-full bg-ok text-ok" />
      </div>

      <nav className="mt-4 flex-1 space-y-1 overflow-y-auto">
        {nav.map((n) => {
          const active = n.href === "/" ? pathname === "/" : pathname.startsWith(n.href);
          return (
            <Link key={n.href} href={n.href} onClick={() => setOpen(false)}
              className={cn(
                "group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition",
                active ? "bg-accent/15 text-t1 shadow-[inset_0_0_0_1px_rgba(99,102,241,.4)]" : "text-t3 hover:bg-surface2 hover:text-t1"
              )}>
              <n.icon className={cn("h-[18px] w-[18px]", active ? "text-accent" : "text-t4 group-hover:text-t2")} />
              {n.label}
              {active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-accent" />}
            </Link>
          );
        })}
      </nav>

      <div className="mt-4 rounded-xl border border-line bg-surface2 p-3">
        <p className="text-[11px] font-semibold text-t2">OpenAI 兼容网关</p>
        <code className="mt-1 block truncate rounded-lg bg-inset px-2 py-1.5 font-mono text-[10px] text-indigo-300">/api/v1/chat/completions</code>
        <p className="mt-1.5 text-[10px] leading-relaxed text-t4">参考 CLIProxyAPI · sub2api · NewAPI 设计,聚合订阅与中转站统一分发。</p>
      </div>
    </div>
  );

  return (
    <>
      {/* mobile top bar */}
      <div className="sticky top-0 z-40 flex items-center gap-3 border-b border-line bg-side px-4 py-3 backdrop-blur lg:hidden">
        <button onClick={() => setOpen(!open)} className="rounded-lg border border-line bg-surface2 p-2 text-t2">
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-fuchsia-500">
            <Zap className="h-4 w-4 text-white" />
          </div>
          <span className="text-sm font-bold text-t1">LocalHub 本地聚合分发</span>
        </div>
        <div className="ml-auto shrink-0">
          <ThemeToggle />
        </div>
      </div>
      {/* desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 hidden w-64 border-r border-line bg-side p-4 backdrop-blur lg:block">
        {panel}
      </aside>
      {/* mobile drawer */}
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/60" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-72 border-r border-line bg-side p-4">{panel}</aside>
        </div>
      )}
    </>
  );
}
