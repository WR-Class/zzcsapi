"use client";
import { ReactNode, useEffect } from "react";
import { Inbox, Loader2, X } from "lucide-react";
import { cn } from "@/lib/utils";

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("glass rounded-2xl p-5", className)}>{children}</div>;
}

export function PageHeader({ title, desc, actions }: { title: string; desc?: string; actions?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-t1">{title}</h1>
        {desc && <p className="mt-1 text-sm text-t3">{desc}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

export function Btn({ children, onClick, variant = "primary", disabled, className, type = "button" }: {
  children: ReactNode; onClick?: () => void; variant?: "primary" | "ghost" | "danger" | "outline" | "success"; disabled?: boolean; className?: string; type?: "button" | "submit";
}) {
  const styles = {
    primary: "bg-indigo-500 hover:bg-indigo-400 text-white shadow-[0_8px_24px_rgba(99,102,241,.35)]",
    ghost: "bg-surface2 hover:bg-t1/10 text-t1 border border-line",
    danger: "bg-rose-500/15 hover:bg-rose-500/25 text-bad border border-rose-500/30",
    outline: "border border-accent/40 text-accent hover:bg-accent/10",
    success: "bg-emerald-500/15 hover:bg-emerald-500/25 text-ok border border-emerald-500/30",
  } as const;
  return (
    <button type={type} onClick={onClick} disabled={disabled}
      className={cn("inline-flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-sm font-medium transition disabled:cursor-not-allowed disabled:opacity-50", styles[variant], className)}>
      {disabled && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
      {children}
    </button>
  );
}

export function Input({ className, ...props }: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={cn("w-full rounded-xl border border-line bg-surface2 px-3 py-2 text-sm text-t1 placeholder:text-t4 outline-none focus:border-accent/60 focus:ring-2 focus:ring-accent/20", className)} />;
}

export function Select({ className, children, ...props }: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={cn("rounded-xl border border-line bg-surface2 px-3 py-2 text-sm text-t1 outline-none focus:border-accent/60 [&>option]:bg-surface-solid", className)}>{children}</select>;
}

export function Textarea({ className, ...props }: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={cn("w-full rounded-xl border border-line bg-surface2 px-3 py-2 text-sm text-t1 placeholder:text-t4 outline-none focus:border-accent/60 focus:ring-2 focus:ring-accent/20", className)} />;
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium text-t3">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-[11px] text-t4">{hint}</span>}
    </label>
  );
}

export function Badge({ children, tone = "slate", className }: { children: ReactNode; tone?: "slate" | "green" | "red" | "amber" | "blue" | "violet" | "custom"; className?: string }) {
  const tones = {
    slate: "bg-surface2 text-t2 border-line",
    green: "bg-emerald-500/15 text-ok border-emerald-500/30",
    red: "bg-rose-500/15 text-bad border-rose-500/30",
    amber: "bg-amber-500/15 text-warn border-amber-500/30",
    blue: "bg-sky-500/15 text-cyan2 border-sky-500/30",
    violet: "bg-violet-500/15 text-accent border-violet-500/30",
    custom: "",
  } as const;
  return <span className={cn("inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs font-medium", tones[tone], className)}>{children}</span>;
}

export function EmptyState({ title, desc, action }: { title: string; desc?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-line bg-surface2/60 px-6 py-14 text-center">
      <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-500/10 text-accent">
        <Inbox className="h-6 w-6" />
      </div>
      <p className="text-sm font-semibold text-t1">{title}</p>
      {desc && <p className="mt-1 max-w-sm text-xs text-t3">{desc}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("shimmer rounded-xl", className)} />;
}

export function TableSkeleton({ rows = 5 }: { rows?: number }) {
  return (
    <div className="space-y-2">
      {Array.from({ length: rows }).map((_, i) => (
        <Skeleton key={i} className="h-14 w-full" />
      ))}
    </div>
  );
}

export function Modal({ open, onClose, title, children, wide }: { open: boolean; onClose: () => void; title: string; children: ReactNode; wide?: boolean }) {
  useEffect(() => {
    const fn = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    if (open) window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 p-0 backdrop-blur-sm sm:items-center sm:p-6" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className={cn("animate-fade-up max-h-[92vh] w-full overflow-y-auto rounded-t-3xl border border-line bg-surface-solid p-6 shadow-2xl sm:rounded-3xl", wide ? "sm:max-w-3xl" : "sm:max-w-lg")}>
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-lg font-bold text-t1">{title}</h3>
          <button onClick={onClose} className="rounded-lg p-1.5 text-t3 hover:bg-t1/10 hover:text-t1"><X className="h-5 w-5" /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button type="button" onClick={() => onChange(!checked)}
      className={cn("relative h-6 w-11 shrink-0 rounded-full transition", checked ? "bg-indigo-500" : "bg-t1/15")}>
      <span className={cn("absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all", checked ? "left-[22px]" : "left-0.5")} />
    </button>
  );
}

export function StatCard({ label, value, sub, icon, accent }: { label: string; value: string; sub?: string; icon: ReactNode; accent: string }) {
  return (
    <div className="glass card-hover rounded-2xl p-5">
      <div className="flex items-center justify-between">
        <p className="text-xs font-medium text-t3">{label}</p>
        <div className={cn("flex h-9 w-9 items-center justify-center rounded-xl", accent)}>{icon}</div>
      </div>
      <p className="mt-2 text-2xl font-bold tracking-tight text-t1">{value}</p>
      {sub && <p className="mt-1 text-xs text-t4">{sub}</p>}
    </div>
  );
}

export function Toast({ msg }: { msg: string }) {
  if (!msg) return null;
  return <div className="toast fixed bottom-6 left-1/2 z-[60] -translate-x-1/2 rounded-xl px-4 py-2.5 text-sm shadow-2xl">{msg}</div>;
}
