import {
  pgTable,
  serial,
  text,
  varchar,
  integer,
  bigint,
  boolean,
  timestamp,
  doublePrecision,
  jsonb,
} from "drizzle-orm/pg-core";

// 渠道 / 中转站聚合 (NewAPI channels + CLIProxyAPI upstream)
export const channels = pgTable("channels", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 128 }).notNull(),
  // openai | anthropic | gemini | deepseek | qwen | moonshot | ollama | oneapi | newapi | claude-oauth | codex | gemini-cli | azure | custom
  type: varchar("type", { length: 64 }).notNull().default("openai"),
  baseUrl: varchar("base_url", { length: 512 }).notNull().default(""),
  apiKey: text("api_key").notNull().default(""),
  // 逗号分隔或数组
  models: text("models").array().notNull().default([]),
  // 分组: default / vip / cheap ...
  group: varchar("group", { length: 64 }).notNull().default("default"),
  weight: integer("weight").notNull().default(10),
  priority: integer("priority").notNull().default(0),
  enabled: boolean("enabled").notNull().default(true),
  status: varchar("status", { length: 32 }).notNull().default("unknown"), // ok | error | unknown | checking
  latencyMs: integer("latency_ms").notNull().default(0),
  successRate: doublePrecision("success_rate").notNull().default(100),
  totalRequests: integer("total_requests").notNull().default(0),
  totalTokens: bigint("total_tokens", { mode: "number" }).notNull().default(0),
  lastCheckAt: timestamp("last_check_at"),
  lastError: text("last_error").default(""),
  remarks: text("remarks").default(""),
  config: jsonb("config").$type<Record<string, unknown>>().default({}),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// 订阅账号 (CLIProxyAPI / sub2api 风格: OAuth 订阅聚合)
export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 128 }).notNull(),
  // claude-pro | claude-code | codex | chatgpt-plus | gemini-cli | cursor | copilot | kimi | other
  provider: varchar("provider", { length: 64 }).notNull().default("claude-pro"),
  email: varchar("email", { length: 256 }).notNull().default(""),
  authType: varchar("auth_type", { length: 64 }).notNull().default("oauth"), // oauth | apikey | cookie | token
  accessToken: text("access_token").notNull().default(""),
  refreshToken: text("refresh_token").notNull().default(""),
  expiresAt: timestamp("expires_at"),
  quotaTotal: bigint("quota_total", { mode: "number" }).notNull().default(0),
  quotaUsed: bigint("quota_used", { mode: "number" }).notNull().default(0),
  status: varchar("status", { length: 32 }).notNull().default("active"), // active | expired | exhausted | error | refresh_needed
  enabled: boolean("enabled").notNull().default(true),
  lastRefreshAt: timestamp("last_refresh_at"),
  lastUsedAt: timestamp("last_used_at"),
  // 绑定的本地渠道
  channelId: integer("channel_id"),
  plan: varchar("plan", { length: 64 }).notNull().default("Pro"),
  renewsAt: timestamp("renews_at"),
  remarks: text("remarks").default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// 本地分发令牌 (下游客户端使用的 sk-xxx)
export const tokens = pgTable("tokens", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 128 }).notNull(),
  key: varchar("key", { length: 128 }).notNull().unique(),
  // 额度(点数, 1点=$0.001), -1 = 无限
  quota: bigint("quota", { mode: "number" }).notNull().default(-1),
  usedQuota: bigint("used_quota", { mode: "number" }).notNull().default(0),
  modelsAllowed: text("models_allowed").array().notNull().default([]), // 空 = 全部
  group: varchar("group", { length: 64 }).notNull().default("default"),
  enabled: boolean("enabled").notNull().default(true),
  expiresAt: timestamp("expires_at"),
  lastUsedAt: timestamp("last_used_at"),
  requestCount: integer("request_count").notNull().default(0),
  remarks: text("remarks").default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// 模型库 / 定价映射
export const models = pgTable("models", {
  id: serial("id").primaryKey(),
  modelId: varchar("model_id", { length: 128 }).notNull().unique(),
  displayName: varchar("display_name", { length: 128 }).notNull(),
  provider: varchar("provider", { length: 64 }).notNull().default("openai"),
  // 每 1K tokens 价格(美元)
  inputPrice: doublePrecision("input_price").notNull().default(0),
  outputPrice: doublePrecision("output_price").notNull().default(0),
  enabled: boolean("enabled").notNull().default(true),
  // 可用渠道 id 列表, 空 = 自动路由
  channelIds: integer("channel_ids").array().notNull().default([]),
  // vision | tool | reasoning | image | audio
  capabilities: text("capabilities").array().notNull().default([]),
  maxTokens: integer("max_tokens").notNull().default(0),
  remarks: text("remarks").default(""),
  totalCalls: integer("total_calls").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// 调用日志
export const requestLogs = pgTable("request_logs", {
  id: serial("id").primaryKey(),
  tokenId: integer("token_id"),
  tokenName: varchar("token_name", { length: 128 }).notNull().default("-"),
  channelId: integer("channel_id"),
  channelName: varchar("channel_name", { length: 128 }).notNull().default("-"),
  model: varchar("model", { length: 128 }).notNull().default(""),
  type: varchar("type", { length: 32 }).notNull().default("chat"), // chat | image | audio | embedding | rerank
  promptTokens: integer("prompt_tokens").notNull().default(0),
  completionTokens: integer("completion_tokens").notNull().default(0),
  totalTokens: integer("total_tokens").notNull().default(0),
  cost: doublePrecision("cost").notNull().default(0),
  latencyMs: integer("latency_ms").notNull().default(0),
  success: boolean("success").notNull().default(true),
  statusCode: integer("status_code").notNull().default(200),
  ip: varchar("ip", { length: 64 }).notNull().default("127.0.0.1"),
  error: text("error").default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// 系统设置 KV
export const settings = pgTable("settings", {
  key: varchar("key", { length: 128 }).primaryKey(),
  value: text("value").notNull().default(""),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export type Channel = typeof channels.$inferSelect;
export type NewChannel = typeof channels.$inferInsert;
export type Subscription = typeof subscriptions.$inferSelect;
export type Token = typeof tokens.$inferSelect;
export type AIModel = typeof models.$inferSelect;
export type RequestLog = typeof requestLogs.$inferSelect;
