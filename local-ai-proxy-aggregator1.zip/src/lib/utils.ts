export function cn(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

export function genLocalKey(prefix = "sk-local-") {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let s = "";
  const arr = new Uint8Array(32);
  if (typeof crypto !== "undefined" && crypto.getRandomValues) {
    crypto.getRandomValues(arr);
    for (let i = 0; i < 32; i++) s += chars[arr[i] % chars.length];
  } else {
    for (let i = 0; i < 32; i++) s += chars[Math.floor(Math.random() * chars.length)];
  }
  return prefix + s;
}

export function maskKey(key: string, visible = 4) {
  if (!key) return "-";
  if (key.length <= visible * 2 + 3) return key.slice(0, 3) + "****";
  return key.slice(0, 7) + "****" + key.slice(-visible);
}

export function timeAgo(d: string | Date | null | undefined) {
  if (!d) return "-";
  const t = new Date(d).getTime();
  if (Number.isNaN(t)) return "-";
  const diff = Date.now() - t;
  const s = Math.floor(diff / 1000);
  if (s < 60) return `${Math.max(s, 1)} 秒前`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m} 分钟前`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} 小时前`;
  const day = Math.floor(h / 24);
  if (day < 30) return `${day} 天前`;
  return new Date(d).toLocaleDateString("zh-CN");
}

export function formatDate(d: string | Date | null | undefined) {
  if (!d) return "-";
  const dt = new Date(d);
  if (Number.isNaN(dt.getTime())) return "-";
  return dt.toLocaleString("zh-CN", { hour12: false });
}

export function formatNumber(n: number | null | undefined) {
  if (n == null || Number.isNaN(n)) return "0";
  if (Math.abs(n) >= 1_000_000) return (n / 1_000_000).toFixed(2) + "M";
  if (Math.abs(n) >= 10_000) return (n / 1000).toFixed(1) + "K";
  return n.toLocaleString("zh-CN");
}

export function formatCost(n: number | null | undefined) {
  if (n == null || Number.isNaN(n)) return "$0.00";
  if (n === 0) return "$0.00";
  if (n < 0.01) return `$${n.toFixed(4)}`;
  return `$${n.toFixed(2)}`;
}

export function formatLatency(ms: number | null | undefined) {
  if (ms == null) return "-";
  if (ms < 1000) return `${ms}ms`;
  return `${(ms / 1000).toFixed(2)}s`;
}

export const channelTypeMeta: Record<string, { label: string; color: string; placeholder: string }> = {
  openai: { label: "OpenAI", color: "bg-emerald-500/15 text-ok border-emerald-500/30", placeholder: "https://api.openai.com/v1" },
  anthropic: { label: "Anthropic", color: "bg-orange-500/15 text-orange-500 border-orange-500/30 dark:text-orange-300", placeholder: "https://api.anthropic.com/v1" },
  gemini: { label: "Gemini", color: "bg-sky-500/15 text-cyan2 border-sky-500/30", placeholder: "https://generativelanguage.googleapis.com/v1beta" },
  deepseek: { label: "DeepSeek", color: "bg-indigo-500/15 text-accent border-indigo-500/30", placeholder: "https://api.deepseek.com/v1" },
  qwen: { label: "通义千问", color: "bg-violet-500/15 text-accent border-violet-500/30", placeholder: "https://dashscope.aliyuncs.com/compatible-mode/v1" },
  moonshot: { label: "Moonshot", color: "bg-amber-500/15 text-warn border-amber-500/30", placeholder: "https://api.moonshot.cn/v1" },
  ollama: { label: "Ollama 本地", color: "bg-slate-500/15 text-t2 border-line", placeholder: "http://127.0.0.1:11434/v1" },
  oneapi: { label: "OneAPI 中转", color: "bg-rose-500/15 text-bad border-rose-500/30", placeholder: "https://your-oneapi.com/v1" },
  newapi: { label: "NewAPI 中转", color: "bg-fuchsia-500/15 text-fuchsia-500 border-fuchsia-500/30 dark:text-fuchsia-300", placeholder: "https://your-newapi.com/v1" },
  "claude-oauth": { label: "Claude OAuth", color: "bg-orange-500/15 text-orange-500 border-orange-500/30 dark:text-orange-200", placeholder: "https://api.anthropic.com/v1 (OAuth)" },
  codex: { label: "Codex 订阅", color: "bg-teal-500/15 text-teal-600 border-teal-500/30 dark:text-teal-300", placeholder: "https://chatgpt.com/backend-api" },
  "gemini-cli": { label: "Gemini CLI", color: "bg-blue-500/15 text-blue-500 border-blue-500/30 dark:text-blue-300", placeholder: "https://cloudcode-pa.googleapis.com/v1internal" },
  azure: { label: "Azure OpenAI", color: "bg-cyan-500/15 text-cyan2 border-cyan-500/30", placeholder: "https://{resource}.openai.azure.com/openai/deployments" },
  custom: { label: "自定义兼容", color: "bg-slate-500/15 text-t2 border-line", placeholder: "https://api.example.com/v1" },
};

export const providerMeta: Record<string, { label: string; color: string }> = {
  "claude-pro": { label: "Claude Pro", color: "bg-orange-500/15 text-orange-500 border-orange-500/30 dark:text-orange-300" },
  "claude-code": { label: "Claude Code", color: "bg-amber-500/15 text-warn border-amber-500/30" },
  codex: { label: "Codex / ChatGPT", color: "bg-emerald-500/15 text-ok border-emerald-500/30" },
  "chatgpt-plus": { label: "ChatGPT Plus", color: "bg-teal-500/15 text-teal-600 border-teal-500/30 dark:text-teal-300" },
  "gemini-cli": { label: "Gemini CLI", color: "bg-sky-500/15 text-cyan2 border-sky-500/30" },
  cursor: { label: "Cursor", color: "bg-indigo-500/15 text-accent border-indigo-500/30" },
  copilot: { label: "Copilot", color: "bg-slate-500/15 text-t2 border-line" },
  kimi: { label: "Kimi 会员", color: "bg-amber-500/15 text-warn border-amber-500/30" },
  other: { label: "其他订阅", color: "bg-slate-500/15 text-t2 border-line" },
};
